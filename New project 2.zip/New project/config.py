"""Configuracion central de rutas y tema visual."""

import sys
from pathlib import Path

if getattr(sys, "frozen", False):
    APP_DIR = Path(sys.executable).resolve().parent
else:
    APP_DIR = Path(__file__).resolve().parent

DB_PATH = APP_DIR / "inventario.db"
IMAGE_DIR = APP_DIR / "imagenes"
LOGO_PATH = APP_DIR / "logo.png"
PDF_ICON_PATH = APP_DIR / "pdf_icon.png"
CSV_ICON_PATH = APP_DIR / "csv_icon.png"
USUARIO_PATH = APP_DIR / "usuario.txt"

COLOR_FONDO = "#eaf8ff"
COLOR_BLANCO = "#ffffff"
COLOR_CELESTE = "#0ea5e9"
COLOR_CELESTE_OSCURO = "#0284c7"
COLOR_CELESTE_SUAVE = "#dff3ff"
COLOR_ROJO = "#ef4444"
COLOR_ROJO_OSCURO = "#dc2626"
COLOR_TEXTO = "#1f2937"
COLOR_TEXTO_SUAVE = "#64748b"
COLOR_TEXTO_BOTON = "#ffffff"
COLOR_BORDE = "#cfe8f6"
COLOR_INPUT = "#f8fdff"
COLOR_FILA_HOVER = "#f2fbff"

TEMAS_VISUALES = {
    "claro": {
        "COLOR_FONDO": "#eaf8ff",
        "COLOR_BLANCO": "#ffffff",
        "COLOR_CELESTE": "#0ea5e9",
        "COLOR_CELESTE_OSCURO": "#0284c7",
        "COLOR_CELESTE_SUAVE": "#dff3ff",
        "COLOR_ROJO": "#ef4444",
        "COLOR_ROJO_OSCURO": "#dc2626",
        "COLOR_TEXTO": "#1f2937",
        "COLOR_TEXTO_SUAVE": "#64748b",
        "COLOR_TEXTO_BOTON": "#ffffff",
        "COLOR_BORDE": "#cfe8f6",
        "COLOR_INPUT": "#f8fdff",
        "COLOR_FILA_HOVER": "#f2fbff",
    },
    "oscuro": {
        "COLOR_FONDO": "#071522",
        "COLOR_BLANCO": "#0f2333",
        "COLOR_CELESTE": "#0ea5e9",
        "COLOR_CELESTE_OSCURO": "#38bdf8",
        "COLOR_CELESTE_SUAVE": "#12344a",
        "COLOR_ROJO": "#ef4444",
        "COLOR_ROJO_OSCURO": "#f87171",
        "COLOR_TEXTO": "#e5eef8",
        "COLOR_TEXTO_SUAVE": "#9fb2c7",
        "COLOR_TEXTO_BOTON": "#ffffff",
        "COLOR_BORDE": "#24516a",
        "COLOR_INPUT": "#0b1f2f",
        "COLOR_FILA_HOVER": "#143047",
    },
}


def _aplicar_paleta_visual(nombre_tema):
    paleta = TEMAS_VISUALES.get(nombre_tema, TEMAS_VISUALES["claro"])
    globals().update(paleta)


def _color_rgb(color):
    color = color.strip()
    if len(color) == 7 and color.startswith("#"):
        return tuple(int(color[i:i + 2], 16) for i in (1, 3, 5))
    return (255, 255, 255)


def _mezclar_color(inicio, fin, progreso):
    progreso = max(0, min(1, progreso))
    rgb_inicio = _color_rgb(inicio)
    rgb_fin = _color_rgb(fin)
    mezcla = tuple(
        int(rgb_inicio[indice] + (rgb_fin[indice] - rgb_inicio[indice]) * progreso)
        for indice in range(3)
    )
    return "#{:02x}{:02x}{:02x}".format(*mezcla)


def aplicar_paleta_a(modulo_globals, nombre_tema="claro"):
    """Actualiza los colores globales de un modulo que usa esta paleta."""
    paleta = TEMAS_VISUALES.get(nombre_tema, TEMAS_VISUALES["claro"])
    modulo_globals.update(paleta)
    return paleta
