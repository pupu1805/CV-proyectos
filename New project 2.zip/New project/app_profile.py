"""Login, perfil de usuario y cambio de contrasena."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppProfileMixin:
    def _pedir_usuario(self):
        usuario_recordado = ""

        if USUARIO_PATH.exists():
            usuario_recordado = USUARIO_PATH.read_text(encoding="utf-8").strip()

        self.withdraw()

        ventana = tk.Toplevel(self)
        ventana.title("Iniciar sesión")
        ventana.geometry("430x360")
        ventana.resizable(False, False)
        ventana.configure(bg=COLOR_FONDO)
        ventana.grab_set()

        ventana.update_idletasks()
        ancho = 430
        alto = 360
        x = (ventana.winfo_screenwidth() // 2) - (ancho // 2)
        y = (ventana.winfo_screenheight() // 2) - (alto // 2)
        ventana.geometry(f"{ancho}x{alto}+{x}+{y}")

        modo = tk.StringVar(value="login")
        usuario_var = tk.StringVar(value=usuario_recordado)
        password_var = tk.StringVar()
        confirmar_var = tk.StringVar()
        resultado = {"usuario": ""}

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=18)
        contenedor.pack(fill="both", expand=True, padx=18, pady=18)
        contenedor.columnconfigure(0, weight=1)

        titulo_var = tk.StringVar(value="Iniciar sesión")

        ttk.Label(
            contenedor,
            textvariable=titulo_var,
            style="CardTitle.TLabel",
        ).grid(row=0, column=0, sticky="w", pady=(0, 14))

        ttk.Label(contenedor, text="Usuario:", style="Card.TLabel").grid(row=1, column=0, sticky="w")
        usuario_entry = ttk.Entry(contenedor, textvariable=usuario_var)
        usuario_entry.grid(row=2, column=0, sticky="ew", pady=(5, 10))

        ttk.Label(contenedor, text="Contraseña:", style="Card.TLabel").grid(row=3, column=0, sticky="w")
        password_entry = ttk.Entry(contenedor, textvariable=password_var, show="*")
        password_entry.grid(row=4, column=0, sticky="ew", pady=(5, 10))

        confirmar_label = ttk.Label(contenedor, text="Confirmar contraseña:", style="Card.TLabel")
        confirmar_entry = ttk.Entry(contenedor, textvariable=confirmar_var, show="*")

        mensaje_var = tk.StringVar(value="")
        mensaje_label = tk.Label(
            contenedor,
            textvariable=mensaje_var,
            bg=COLOR_BLANCO,
            fg=COLOR_ROJO,
            font=("Segoe UI", 9, "bold"),
            wraplength=360,
            justify="left",
        )
        mensaje_label.grid(row=7, column=0, sticky="w", pady=(8, 0))

        def cambiar_modo():
            mensaje_var.set("")
            password_var.set("")
            confirmar_var.set("")

            if modo.get() == "login":
                modo.set("registro")
                titulo_var.set("Registrar usuario")
                boton_principal.text = "Registrar"
                boton_principal._draw(boton_principal.current_fill)
                boton_cambio.text = "Ya tengo cuenta"
                boton_cambio._draw(boton_cambio.current_fill)

                confirmar_label.grid(row=5, column=0, sticky="w")
                confirmar_entry.grid(row=6, column=0, sticky="ew", pady=(5, 4))
            else:
                modo.set("login")
                titulo_var.set("Iniciar sesión")
                boton_principal.text = "Ingresar"
                boton_principal._draw(boton_principal.current_fill)
                boton_cambio.text = "Crear cuenta"
                boton_cambio._draw(boton_cambio.current_fill)

                confirmar_label.grid_remove()
                confirmar_entry.grid_remove()

        def aceptar():
            usuario = " ".join(usuario_var.get().split())
            password = password_var.get()

            if not usuario:
                mensaje_var.set("Ingrese su usuario.")
                usuario_entry.focus_set()
                return

            if not password:
                mensaje_var.set("Ingrese su contraseña.")
                password_entry.focus_set()
                return

            if modo.get() == "login":
                perfil = self.db.validar_login(usuario, password)

                if not perfil:
                    mensaje_var.set("Usuario o contraseña incorrectos.")
                    return

                USUARIO_PATH.write_text(perfil[1], encoding="utf-8")
                resultado["usuario"] = perfil[1]
                ventana.destroy()
                return

            confirmar = confirmar_var.get()

            if password != confirmar:
                mensaje_var.set("Las contraseñas no coinciden.")
                confirmar_entry.focus_set()
                return

            try:
                perfil = self.db.registrar_usuario_login(usuario, password)
            except ValueError as error:
                mensaje_var.set(str(error))
                return
            except sqlite3.Error as error:
                mensaje_var.set(f"No se pudo registrar el usuario: {error}")
                return

            USUARIO_PATH.write_text(perfil[1], encoding="utf-8")
            resultado["usuario"] = perfil[1]
            ventana.destroy()

        acciones = ttk.Frame(contenedor, style="Card.TFrame")
        acciones.grid(row=8, column=0, sticky="w", pady=(16, 0))

        boton_principal = self._crear_boton(
            acciones,
            text="Ingresar",
            command=aceptar,
            width=130,
            bg=COLOR_BLANCO,
        )
        boton_principal.grid(row=0, column=0, padx=(0, 8))

        boton_cambio = self._crear_boton(
            acciones,
            text="Crear cuenta",
            command=cambiar_modo,
            variant="secondary",
            width=145,
            bg=COLOR_BLANCO,
        )
        boton_cambio.grid(row=0, column=1)

        ventana.protocol("WM_DELETE_WINDOW", self.destroy)
        ventana.bind("<Return>", lambda _event: aceptar())

        if usuario_recordado:
            password_entry.focus_set()
        else:
            usuario_entry.focus_set()

        self.wait_window(ventana)

        try:
            if not self.winfo_exists():
                return "Usuario sin identificar"
        except tk.TclError:
            return "Usuario sin identificar"

        self.deiconify()
        self.lift()
        self.focus_force()

        return resultado["usuario"] or "Usuario sin identificar"

    def _iniciales_usuario(self, nombre):
        partes = [parte for parte in (nombre or "").split() if parte]
        if not partes:
            return "US"
        if len(partes) == 1:
            return partes[0][:2].upper()
        return (partes[0][0] + partes[1][0]).upper()

    def _cargar_perfil_usuario(self, nombre_usuario):
        nombre_limpio = " ".join((nombre_usuario or "").split())
        if not nombre_limpio:
            nombre_limpio = "Usuario sin identificar"

        try:
            perfil = self.db.obtener_usuario_por_nombre(nombre_limpio)
        except sqlite3.Error:
            perfil = None

        if not perfil:
            self.usuario_actual_id = None
            self.usuario_actual = nombre_limpio
            self.usuario_cargo = ""
            self.usuario_imagen = ""
            self.usuario_avatar_ref = None
            return

        self.usuario_actual_id, self.usuario_actual, self.usuario_cargo, self.usuario_imagen = perfil
        self.usuario_cargo = (self.usuario_cargo or "").strip()
        self.usuario_imagen = self.usuario_imagen or ""
        self.usuario_avatar_ref = None

        try:
            USUARIO_PATH.write_text(self.usuario_actual, encoding="utf-8")
        except OSError:
            pass

    def _crear_panel_usuario_inicio(self, parent, envolver=True, compacto=False):
        if envolver:
            tarjeta_base = RoundedCard(
                parent,
                bg=COLOR_FONDO,
                fill=COLOR_BLANCO,
                outline=COLOR_BORDE,
                radius=20,
                padding=14,
                min_width=290,
                min_height=148,
            )
            tarjeta_base.grid(row=0, column=0, sticky="nw", padx=(0, 20))
            tarjeta = tarjeta_base.contenido
        else:
            tarjeta = parent

        tarjeta.columnconfigure(1, weight=1)
        avatar_size = 56 if compacto else 72

        avatar = self._cargar_avatar_usuario(size=avatar_size)
        if avatar:
            avatar_widget = tk.Label(
                tarjeta,
                image=avatar,
                bg=COLOR_BLANCO,
                cursor="hand2",
                borderwidth=1,
                relief="solid",
            )
            avatar_widget.image = avatar
        else:
            avatar_widget = tk.Canvas(
                tarjeta,
                width=avatar_size,
                height=avatar_size,
                bg=COLOR_BLANCO,
                highlightthickness=0,
                bd=0,
                cursor="hand2",
            )
            avatar_widget.create_oval(
                2,
                2,
                avatar_size - 2,
                avatar_size - 2,
                fill=COLOR_CELESTE_SUAVE,
                outline=COLOR_BORDE,
                width=1,
            )
            avatar_widget.create_text(
                avatar_size / 2,
                avatar_size / 2,
                text=self._iniciales_usuario(self.usuario_actual),
                fill=COLOR_CELESTE_OSCURO,
                font=("Segoe UI", 14 if compacto else 15, "bold"),
            )
        avatar_widget.grid(row=0, column=0, rowspan=3, sticky="nw", padx=(0, 12))
        avatar_widget.bind("<Button-1>", lambda _event: self._editar_perfil_usuario())

        nombre_label = tk.Label(
            tarjeta,
            text=self.usuario_actual,
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 10 if compacto else 14, "bold"),
        )
        nombre_label.grid(row=0, column=1, sticky="w", pady=(0 if compacto else 2, 3))

        cargo_mostrar = self.usuario_cargo if self.usuario_cargo else "Cargo sin definir"
        cargo_label = tk.Label(
            tarjeta,
            text=cargo_mostrar,
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 9 if compacto else 9),
        )
        cargo_label.grid(row=1, column=1, sticky="w", pady=(0, 8 if compacto else 10))

        acciones = ttk.Frame(tarjeta, style="Card.TFrame")
        acciones.grid(row=2, column=1, sticky="w")

        self._crear_boton(
            acciones,
            text="Editar perfil",
            command=self._editar_perfil_usuario,
            width=112 if compacto else 125,
            height=36 if compacto else 42,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Cambiar usuario",
            command=self._cambiar_usuario,
            width=126 if compacto else 140,
            height=36 if compacto else 42,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, sticky="w")

    def _editar_perfil_usuario(self):
        if not self.usuario_actual_id:
            return

        ventana = tk.Toplevel(self)
        ventana.title("Editar perfil de usuario")
        ventana.geometry("620x520")
        ventana.resizable(False, False)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.grab_set()
        self._deshabilitar_tema()

        def cerrar_ventana_editar():
            self._habilitar_tema()
            ventana.destroy()
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=14)
        contenedor.pack(fill="both", expand=True, padx=14, pady=14)
        contenedor.columnconfigure(0, weight=1)

        ttk.Label(
            contenedor,
            text="Perfil de usuario",
            style="CardTitle.TLabel",
        ).grid(row=0, column=0, sticky="w", pady=(0, 10))

        ttk.Label(contenedor, text="Nombre:", style="Card.TLabel").grid(row=1, column=0, sticky="w")
        nombre_var = tk.StringVar(value=self.usuario_actual)
        nombre_entry = ttk.Entry(contenedor, textvariable=nombre_var)
        nombre_entry.grid(row=2, column=0, sticky="ew", pady=(5, 8))

        ttk.Label(contenedor, text="Cargo:", style="Card.TLabel").grid(row=3, column=0, sticky="w")
        cargo_var = tk.StringVar(value=self.usuario_cargo)
        cargo_entry = ttk.Entry(contenedor, textvariable=cargo_var)
        cargo_entry.grid(row=4, column=0, sticky="ew", pady=(5, 8))

        ttk.Label(contenedor, text="Foto:", style="Card.TLabel").grid(row=5, column=0, sticky="w")

        preview_label = tk.Label(
            contenedor,
            text="Sin foto",
            bg=COLOR_INPUT,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10, "bold"),
            relief="solid",
            borderwidth=1,
            anchor="center",
            padx=8,
            pady=8,
        )
        preview_label.grid(row=6, column=0, sticky="w", pady=(6, 10))

        imagen_data = {"valor": self.usuario_imagen or ""}
        preview_ref = {"imagen": None}

        def render_preview():
            ruta = self._resolver_ruta_imagen(imagen_data["valor"])
            if not ruta or not ruta.exists():
                preview_ref["imagen"] = None
                preview_label.configure(image="", text="Sin foto")
                preview_label.image = None
                return

            try:
                preview = self._cargar_preview_imagen(ruta, 240, 220)
            except Exception:
                preview = None

            if preview is None:
                preview_ref["imagen"] = None
                preview_label.configure(image="", text="No se pudo mostrar")
                preview_label.image = None
                return

            preview_ref["imagen"] = preview
            preview_label.configure(image=preview, text="")
            preview_label.image = preview

        def subir_imagen_usuario():
            nueva = self._seleccionar_imagen_categoria()
            if not nueva:
                return
            imagen_data["valor"] = nueva
            render_preview()

        def quitar_imagen_usuario():
            imagen_data["valor"] = ""
            render_preview()

        def abrir_cambio_contrasena():
            self._cambiar_contrasena_usuario(ventana)

        def guardar_perfil():
            nombre_nuevo = " ".join(nombre_var.get().split())
            cargo_nuevo = " ".join(cargo_var.get().split())

            if len(nombre_nuevo) < 2:
                messagebox.showwarning("Nombre invalido", "El nombre debe tener al menos 2 caracteres.")
                nombre_entry.focus_set()
                return
            if len(nombre_nuevo) > 60:
                messagebox.showwarning("Nombre invalido", "El nombre no puede superar 60 caracteres.")
                nombre_entry.focus_set()
                return
            if len(cargo_nuevo) > 60:
                messagebox.showwarning("Cargo invalido", "El cargo no puede superar 60 caracteres.")
                cargo_entry.focus_set()
                return

            perfil_existente = self.db.obtener_usuario_por_nombre(nombre_nuevo)
            if perfil_existente and perfil_existente[0] != self.usuario_actual_id:
                self._cargar_perfil_usuario(perfil_existente[1])
                self.db.registrar_historial(
                    self.usuario_actual,
                    "CAMBIO",
                    "USUARIO",
                    f"Cargo perfil existente: {self.usuario_actual}",
                )
                _cerrar_ventana()
                self._mostrar_inicio()
                return

            try:
                self.db.actualizar_usuario(
                    self.usuario_actual_id,
                    nombre_nuevo,
                    cargo_nuevo,
                    imagen_data["valor"] or "",
                )
            except sqlite3.IntegrityError:
                messagebox.showwarning("Usuario duplicado", "Ese nombre de usuario ya existe.")
                return

            self._cargar_perfil_usuario(nombre_nuevo)
            self.db.registrar_historial(
                self.usuario_actual,
                "EDITO",
                "USUARIO",
                f"Actualizo perfil (cargo: {self.usuario_cargo or 'sin cargo'})",
            )

            _cerrar_ventana()
            self._mostrar_inicio()

        acciones = ttk.Frame(contenedor, style="Card.TFrame")
        acciones.grid(row=7, column=0, sticky="w", pady=(0, 0))

        self._crear_boton(
            acciones,
            text="Subir/Cambiar",
            command=subir_imagen_usuario,
            width=112,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 6))

        self._crear_boton(
            acciones,
            text="Quitar imagen",
            command=quitar_imagen_usuario,
            variant="danger",
            width=110,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, padx=(0, 6))

        self._crear_boton(
            acciones,
            text="Contraseña",
            command=abrir_cambio_contrasena,
            variant="secondary",
            width=102,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=2, padx=(0, 6))

        self._crear_boton(
            acciones,
            text="Guardar",
            command=guardar_perfil,
            width=84,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=3, padx=(0, 6))

        self._crear_boton(
            acciones,
            text="Cerrar",
            command=_cerrar_ventana,
            variant="light",
            width=76,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=4)

        render_preview()
        self._vincular_atajos_ventana(ventana, guardar=guardar_perfil, cerrar=_cerrar_ventana)
        nombre_entry.focus_set()

    def _cambiar_contrasena_usuario(self, parent=None):
        if not self.usuario_actual_id:
            return

        ventana = tk.Toplevel(parent or self)
        ventana.title("Actualizar contraseña")
        ventana.geometry("430x330")
        ventana.resizable(False, False)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(parent or self)
        ventana.grab_set()
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        contenedor_base = RoundedCard(
            ventana,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=22,
            padding=16,
            fill_height=True,
        )
        contenedor_base.pack(fill="both", expand=True, padx=16, pady=16)
        contenedor = contenedor_base.contenido
        contenedor.columnconfigure(0, weight=1)

        tk.Label(
            contenedor,
            text="Actualizar contraseña",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 16, "bold"),
        ).grid(row=0, column=0, sticky="w", pady=(0, 4))

        tk.Label(
            contenedor,
            text="Cambia tu clave de acceso al sistema.",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, sticky="w", pady=(0, 14))

        actual_var = tk.StringVar()
        nueva_var = tk.StringVar()
        confirmar_var = tk.StringVar()
        mensaje_var = tk.StringVar()

        ttk.Label(contenedor, text="Contraseña actual:", style="Card.TLabel").grid(row=2, column=0, sticky="w")
        actual_entry = ttk.Entry(contenedor, textvariable=actual_var, show="*")
        actual_entry.grid(row=3, column=0, sticky="ew", pady=(5, 10))

        ttk.Label(contenedor, text="Nueva contraseña:", style="Card.TLabel").grid(row=4, column=0, sticky="w")
        nueva_entry = ttk.Entry(contenedor, textvariable=nueva_var, show="*")
        nueva_entry.grid(row=5, column=0, sticky="ew", pady=(5, 10))

        ttk.Label(contenedor, text="Confirmar nueva contraseña:", style="Card.TLabel").grid(row=6, column=0, sticky="w")
        confirmar_entry = ttk.Entry(contenedor, textvariable=confirmar_var, show="*")
        confirmar_entry.grid(row=7, column=0, sticky="ew", pady=(5, 6))

        mensaje = tk.Label(
            contenedor,
            textvariable=mensaje_var,
            bg=COLOR_BLANCO,
            fg=COLOR_ROJO,
            font=("Segoe UI", 9, "bold"),
            wraplength=360,
            justify="left",
        )
        mensaje.grid(row=8, column=0, sticky="w", pady=(0, 10))

        def actualizar():
            actual = actual_var.get()
            nueva = nueva_var.get()
            confirmar = confirmar_var.get()

            if not actual:
                mensaje_var.set("Ingrese la contraseña actual.")
                actual_entry.focus_set()
                return
            if len(nueva) < 4:
                mensaje_var.set("La nueva contraseña debe tener al menos 4 caracteres.")
                nueva_entry.focus_set()
                return
            if nueva != confirmar:
                mensaje_var.set("Las contraseñas nuevas no coinciden.")
                confirmar_entry.focus_set()
                return

            try:
                self.db.actualizar_password_usuario(self.usuario_actual_id, actual, nueva)
            except ValueError as error:
                mensaje_var.set(str(error))
                return
            except sqlite3.Error as error:
                mensaje_var.set(f"No se pudo actualizar: {error}")
                return

            self.db.registrar_historial(
                self.usuario_actual,
                "EDITO",
                "USUARIO",
                "Actualizo su contraseña",
            )
            messagebox.showinfo("Contraseña actualizada", "La contraseña se actualizó correctamente.")
            _cerrar_ventana()

        acciones = ttk.Frame(contenedor, style="Card.TFrame")
        acciones.grid(row=9, column=0, sticky="w")

        self._crear_boton(
            acciones,
            text="Actualizar",
            command=actualizar,
            width=120,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Cancelar",
            command=_cerrar_ventana,
            variant="secondary",
            width=110,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1)

        ventana.bind("<Return>", lambda _event: actualizar())
        self._vincular_atajos_ventana(ventana, guardar=actualizar, cerrar=_cerrar_ventana)
        actual_entry.focus_set()

    def _cambiar_usuario(self):
        if USUARIO_PATH.exists():
            USUARIO_PATH.unlink()

        nuevo_usuario = self._pedir_usuario()
        self._cargar_perfil_usuario(nuevo_usuario)

        self.db.registrar_historial(
            self.usuario_actual,
            "CAMBIÓ",
            "USUARIO",
            f"Inició sesión como: {self.usuario_actual}"
        )

        def _hacer_cambio():
            self._mostrar_bienvenida(self.usuario_actual, self._mostrar_inicio)

        self._fade_out(_hacer_cambio, pasos=8, delay=10)

