"""Compatibilidad: permite seguir ejecutando `python inventario_app.py`."""

from main import main


if __name__ == "__main__":
    main()
