"""Sincroniza la paleta visual entre los modulos de la interfaz."""

import config

_THEME_MODULES = []


def registrar_modulos_tema(*modules):
    for module in modules:
        if module not in _THEME_MODULES:
            _THEME_MODULES.append(module)


def aplicar_paleta_visual(nombre_tema):
    paleta = config.aplicar_paleta_a(config.__dict__, nombre_tema)
    for module in _THEME_MODULES:
        config.aplicar_paleta_a(module.__dict__, nombre_tema)
    return paleta
