"""Punto de entrada ligero para ejecutar la aplicacion."""

from app import main


if __name__ == "__main__":
    main()
