"""Importacion, exportacion y respaldos."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppExportsMixin:
    def _copiar_imagen_para_exportacion(self, referencia, carpeta_destino, cache):
        referencia = (referencia or "").strip()
        if not referencia:
            return ""

        if referencia in cache:
            return cache[referencia]

        ruta = self._resolver_ruta_imagen(referencia)
        if not ruta or not ruta.exists() or not ruta.is_file():
            cache[referencia] = referencia
            return referencia

        carpeta_destino.mkdir(parents=True, exist_ok=True)
        destino = carpeta_destino / ruta.name
        if destino.exists() and destino.resolve() != ruta.resolve():
            destino = carpeta_destino / f"{ruta.stem}_{uuid.uuid4().hex[:8]}{ruta.suffix}"

        try:
            if destino.resolve() != ruta.resolve():
                shutil.copy2(ruta, destino)
            relativo = f"{carpeta_destino.name}/{destino.name}"
            cache[referencia] = relativo
            return relativo
        except OSError:
            cache[referencia] = referencia
            return referencia

    def _preparar_filas_csv_con_imagenes(self, filas, ruta_csv):
        ruta_csv = Path(ruta_csv)
        carpeta_imagenes = ruta_csv.with_suffix("")
        carpeta_imagenes = ruta_csv.parent / f"{carpeta_imagenes.name}_imagenes"
        cache = {}
        filas_preparadas = []

        for categoria, categoria_imagen, nombre, contenido, imagen in filas:
            filas_preparadas.append(
                (
                    categoria,
                    self._copiar_imagen_para_exportacion(categoria_imagen, carpeta_imagenes, cache),
                    nombre,
                    contenido,
                    self._copiar_imagen_para_exportacion(imagen, carpeta_imagenes, cache),
                )
            )

        return filas_preparadas

    def _texto_csv(self, columnas, filas):
        salida = io.StringIO()
        escritor = csv.writer(salida)
        escritor.writerow(columnas)
        escritor.writerows(filas)
        return salida.getvalue()

    def _imagen_para_respaldo(self, referencia, imagenes):
        referencia = (referencia or "").strip()
        if not referencia:
            return ""

        ruta = self._resolver_ruta_imagen(referencia)
        if not ruta or not ruta.exists() or not ruta.is_file():
            return referencia

        arcname = f"imagenes/{ruta.name}"
        if arcname in imagenes and imagenes[arcname] != ruta:
            arcname = f"imagenes/{ruta.stem}_{uuid.uuid4().hex[:8]}{ruta.suffix}"

        imagenes[arcname] = ruta
        return arcname

    def _exportar_respaldo_completo(self):
        ruta = filedialog.asksaveasfilename(
            title="Guardar respaldo completo",
            defaultextension=".zip",
            filetypes=[("Respaldo ZIP", "*.zip")],
            initialfile=f"respaldo_inventario_{datetime.now().strftime('%Y%m%d_%H%M')}.zip",
        )
        if not ruta:
            return

        datos = self.db.obtener_respaldo_completo()
        imagenes = {}
        categorias = [
            (cat_id, nombre, self._imagen_para_respaldo(imagen, imagenes))
            for cat_id, nombre, imagen in datos["categorias"]
        ]
        productos = [
            (prod_id, categoria_id, nombre, contenido, self._imagen_para_respaldo(imagen, imagenes))
            for prod_id, categoria_id, nombre, contenido, imagen in datos["productos"]
        ]
        usuarios = [
            (usuario_id, nombre, cargo, self._imagen_para_respaldo(imagen, imagenes), password_hash, password_salt)
            for usuario_id, nombre, cargo, imagen, password_hash, password_salt in datos["usuarios"]
        ]

        try:
            with zipfile.ZipFile(ruta, "w", compression=zipfile.ZIP_DEFLATED) as respaldo:
                respaldo.writestr(
                    "categorias.csv",
                    self._texto_csv(["id", "nombre", "imagen"], categorias),
                )
                respaldo.writestr(
                    "productos.csv",
                    self._texto_csv(["id", "categoria_id", "nombre", "contenido", "imagen"], productos),
                )
                respaldo.writestr(
                    "prestamos.csv",
                    self._texto_csv(
                        [
                            "id",
                            "producto_id",
                            "objeto",
                            "cantidad",
                            "solicitante",
                            "fecha_prestamo",
                            "fecha_devolucion",
                            "fecha_registro",
                        ],
                        datos["prestamos"],
                    ),
                )
                respaldo.writestr(
                    "historial.csv",
                    self._texto_csv(["id", "usuario", "accion", "entidad", "detalle", "fecha"], datos["historial"]),
                )
                respaldo.writestr(
                    "usuarios.csv",
                    self._texto_csv(
                        ["id", "nombre", "cargo", "imagen", "password_hash", "password_salt"],
                        usuarios,
                    ),
                )
                respaldo.writestr(
                    "README.txt",
                    "Respaldo completo del Sistema de Inventario. Importe este ZIP desde la aplicación.\n",
                )
                for arcname, ruta_imagen in imagenes.items():
                    respaldo.write(ruta_imagen, arcname)
        except OSError as error:
            messagebox.showerror("Error", f"No se pudo guardar el respaldo:\n{error}")
            return

        self.db.registrar_historial(
            self.usuario_actual,
            "EXPORTÓ",
            "RESPALDO",
            f"Generó respaldo completo: {Path(ruta).name}",
        )
        messagebox.showinfo("Respaldo generado", "El respaldo completo se guardó correctamente.")

    def _leer_csv_respaldo(self, respaldo, nombre_archivo, columnas, enteros=()):
        if nombre_archivo not in respaldo.namelist():
            raise ValueError(f"Falta el archivo {nombre_archivo} dentro del respaldo.")

        with respaldo.open(nombre_archivo, "r") as archivo_binario:
            archivo_texto = io.TextIOWrapper(archivo_binario, encoding="utf-8-sig", newline="")
            lector = csv.DictReader(archivo_texto)
            filas = []
            for fila in lector:
                valores = []
                for columna in columnas:
                    valor = fila.get(columna, "")
                    if columna in enteros:
                        valor = int(valor or 0)
                    valores.append(valor)
                filas.append(tuple(valores))
            return filas

    def _extraer_imagenes_respaldo(self, respaldo):
        destino_base = IMAGE_DIR.resolve()
        destino_base.mkdir(exist_ok=True)

        for nombre in respaldo.namelist():
            if not nombre.startswith("imagenes/") or nombre.endswith("/"):
                continue

            destino = (APP_DIR / nombre).resolve()
            if destino_base not in destino.parents and destino != destino_base:
                continue

            destino.parent.mkdir(parents=True, exist_ok=True)
            with respaldo.open(nombre, "r") as origen, open(destino, "wb") as salida:
                shutil.copyfileobj(origen, salida)

    def _importar_respaldo_completo(self):
        archivo = filedialog.askopenfilename(
            title="Importar respaldo completo",
            filetypes=[("Respaldo ZIP", "*.zip"), ("Todos los archivos", "*.*")],
        )
        if not archivo:
            return

        confirmar = messagebox.askyesno(
            "Importar respaldo",
            "Esto reemplazará categorías, opciones, préstamos, historial y usuarios con el contenido del respaldo. ¿Desea continuar?",
        )
        if not confirmar:
            return

        try:
            with zipfile.ZipFile(archivo, "r") as respaldo:
                self._extraer_imagenes_respaldo(respaldo)
                datos = {
                    "categorias": self._leer_csv_respaldo(
                        respaldo,
                        "categorias.csv",
                        ["id", "nombre", "imagen"],
                        enteros={"id"},
                    ),
                    "productos": self._leer_csv_respaldo(
                        respaldo,
                        "productos.csv",
                        ["id", "categoria_id", "nombre", "contenido", "imagen"],
                        enteros={"id", "categoria_id"},
                    ),
                    "prestamos": self._leer_csv_respaldo(
                        respaldo,
                        "prestamos.csv",
                        [
                            "id",
                            "producto_id",
                            "objeto",
                            "cantidad",
                            "solicitante",
                            "fecha_prestamo",
                            "fecha_devolucion",
                            "fecha_registro",
                        ],
                        enteros={"id", "producto_id"},
                    ),
                    "historial": self._leer_csv_respaldo(
                        respaldo,
                        "historial.csv",
                        ["id", "usuario", "accion", "entidad", "detalle", "fecha"],
                        enteros={"id"},
                    ),
                    "usuarios": self._leer_csv_respaldo(
                        respaldo,
                        "usuarios.csv",
                        ["id", "nombre", "cargo", "imagen", "password_hash", "password_salt"],
                        enteros={"id"},
                    ),
                }
                self.db.importar_respaldo_completo(datos)
        except (OSError, zipfile.BadZipFile, ValueError, sqlite3.Error) as error:
            messagebox.showerror("No se pudo importar", f"No se pudo importar el respaldo:\n{error}")
            return

        if not self.db.obtener_usuario_por_nombre(self.usuario_actual):
            self.db.obtener_o_crear_usuario(self.usuario_actual)
        self._cargar_perfil_usuario(self.usuario_actual)
        self.db.registrar_historial(
            self.usuario_actual,
            "IMPORTÓ",
            "RESPALDO",
            f"Importó respaldo completo: {Path(archivo).name}",
        )
        self._mostrar_inicio()
        messagebox.showinfo("Respaldo importado", "El respaldo completo se importó correctamente.")

    def _exportar_pdf_todo(self):
        ruta = filedialog.asksaveasfilename(
            title="Guardar PDF del inventario completo",
            defaultextension=".pdf",
            filetypes=[("Archivo PDF", "*.pdf")],
            initialfile="inventario_completo.pdf",
        )

        if not ruta:
            return

        datos = self.db.obtener_todo_inventario()

        if not datos:
            messagebox.showwarning("Sin datos", "No hay información para exportar.")
            return

        try:
            self._generar_pdf(ruta, "Inventario completo", datos)
            messagebox.showinfo("PDF generado", "El PDF se generó correctamente.")
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{error}")

    def _exportar_pdf_categoria(self):
        if not self.categoria_actual_id:
            messagebox.showwarning("Sin ubicación", "Abra una ubicación antes de exportar.")
            return

        ruta = filedialog.asksaveasfilename(
            title="Guardar PDF de la categoría",
            defaultextension=".pdf",
            filetypes=[("Archivo PDF", "*.pdf")],
            initialfile=f"{self.categoria_actual_nombre}.pdf",
        )

        if not ruta:
            return

        productos = self.db.obtener_productos_categoria_pdf(self.categoria_actual_id)

        if not productos:
            messagebox.showwarning("Sin datos", "Esta ubicación no tiene mobiliario para exportar.")
            return

        datos = [(self.categoria_actual_nombre, productos)]

        try:
            self._generar_pdf(ruta, f"Ubicación: {self.categoria_actual_nombre}", datos)
            messagebox.showinfo("PDF generado", "El PDF se generó correctamente.")
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el PDF:\n{error}")

    def _exportar_csv_todo(self):
        ruta = filedialog.asksaveasfilename(
            title="Guardar CSV del inventario completo",
            defaultextension=".csv",
            filetypes=[("Archivo CSV", "*.csv")],
            initialfile="inventario_completo.csv",
        )

        if not ruta:
            return

        self._exportar_csv_inventario(ruta, titulo="Inventario completo")

    def _exportar_csv_categoria(self):
        if not self.categoria_actual_id:
            messagebox.showwarning("Sin ubicación", "Abra una ubicación antes de exportar.")
            return

        ruta = filedialog.asksaveasfilename(
            title="Guardar CSV de la categoría",
            defaultextension=".csv",
            filetypes=[("Archivo CSV", "*.csv")],
            initialfile=f"{self.categoria_actual_nombre}.csv",
        )

        if not ruta:
            return

        self._exportar_csv_inventario(
            ruta,
            titulo=f"Ubicación: {self.categoria_actual_nombre}",
            categoria_id=self.categoria_actual_id,
        )

    def _exportar_csv_inventario(self, ruta, titulo, categoria_id=None):
        filas = self.db.obtener_inventario_csv(categoria_id)
        if not filas:
            messagebox.showwarning("Sin datos", "No hay información para exportar.")
            return

        try:
            filas = self._preparar_filas_csv_con_imagenes(filas, ruta)
            with open(ruta, "w", encoding="utf-8-sig", newline="") as archivo:
                escritor = csv.writer(archivo)
                escritor.writerow(["categoria", "categoria_imagen", "nombre", "contenido", "imagen"])
                escritor.writerows(filas)
        except OSError as error:
            messagebox.showerror("Error", f"No se pudo guardar el CSV:\n{error}")
            return

        messagebox.showinfo(
            "CSV generado",
            (
                f"{titulo} se exportó correctamente.\n\n"
                "Este archivo puede importarse desde el botón Importar CSV."
            ),
        )

    def _generar_pdf(self, ruta, titulo, datos):
        from reportlab.lib import colors
        from reportlab.lib.enums import TA_CENTER, TA_LEFT
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
        from reportlab.lib.units import cm
        from reportlab.platypus import (
            SimpleDocTemplate,
            Paragraph,
            Spacer,
            Table,
            TableStyle,
            Image as PdfImage,
        )
        from xml.sax.saxutils import escape as xml_escape

        doc = SimpleDocTemplate(
            ruta,
            pagesize=A4,
            rightMargin=1.6 * cm,
            leftMargin=1.6 * cm,
            topMargin=1.5 * cm,
            bottomMargin=1.5 * cm,
        )

        estilos = getSampleStyleSheet()

        estilo_titulo = ParagraphStyle(
            "TituloPrincipal",
            parent=estilos["Title"],
            fontName="Helvetica-Bold",
            fontSize=22,
            leading=26,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#1f2937"),
            spaceAfter=10,
        )

        estilo_fecha = ParagraphStyle(
            "Fecha",
            parent=estilos["Normal"],
            fontSize=9,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#64748b"),
            spaceAfter=18,
        )

        estilo_categoria = ParagraphStyle(
            "Categoria",
            parent=estilos["Heading2"],
            fontName="Helvetica-Bold",
            fontSize=15,
            leading=18,
            textColor=colors.white,
            backColor=colors.HexColor("#0ea5e9"),
            borderPadding=8,
            spaceBefore=12,
            spaceAfter=10,
        )

        estilo_producto = ParagraphStyle(
            "Producto",
            parent=estilos["Heading3"],
            fontName="Helvetica-Bold",
            fontSize=12,
            leading=15,
            textColor=colors.HexColor("#1f2937"),
            spaceBefore=8,
            spaceAfter=4,
        )

        estilo_texto = ParagraphStyle(
            "Texto",
            parent=estilos["Normal"],
            fontSize=10,
            leading=14,
            alignment=TA_LEFT,
            textColor=colors.HexColor("#334155"),
        )

        estilo_muted = ParagraphStyle(
            "Muted",
            parent=estilos["Normal"],
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#64748b"),
        )

        elementos = []

        if LOGO_PATH.exists():
            try:
                logo = PdfImage(str(LOGO_PATH), width=3.4 * cm, height=2.2 * cm)
                logo.hAlign = "CENTER"
                elementos.append(logo)
                elementos.append(Spacer(1, 8))
            except Exception:
                pass

        elementos.append(Paragraph(xml_escape(titulo), estilo_titulo))
        elementos.append(
            Paragraph(
                f"Generado el {datetime.now().strftime('%d/%m/%Y %H:%M')}",
                estilo_fecha,
            )
        )

        total_categorias = len(datos)
        total_productos = sum(len(productos) for _categoria, productos in datos)

        resumen = Table(
            [
                ["Categorías", "Productos"],
                [str(total_categorias), str(total_productos)],
            ],
            colWidths=[7 * cm, 7 * cm],
        )
        resumen.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dff3ff")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.HexColor("#1f2937")),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTSIZE", (0, 0), (-1, 0), 10),
                    ("FONTSIZE", (0, 1), (-1, 1), 14),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                    ("TOPPADDING", (0, 0), (-1, -1), 8),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cfe8f6")),
                    ("BACKGROUND", (0, 1), (-1, 1), colors.white),
                ]
            )
        )

        elementos.append(resumen)
        elementos.append(Spacer(1, 16))

        for indice_categoria, (categoria_nombre, productos) in enumerate(datos):
            elementos.append(Paragraph(xml_escape(categoria_nombre), estilo_categoria))

            if not productos:
                elementos.append(Paragraph("Sin productos registrados.", estilo_muted))
                continue

            for indice_producto, (nombre, contenido, imagen) in enumerate(productos, start=1):
                elementos.append(
                    Paragraph(f"{indice_producto}. {xml_escape(nombre)}", estilo_producto)
                )

                texto_formateado = self._formatear_contenido_con_indice(contenido)
                texto_html = xml_escape(texto_formateado).replace("\n", "<br/>")
                elementos.append(Paragraph(texto_html, estilo_texto))

                if imagen:
                    elementos.append(
                        Paragraph("Este producto tiene una imagen asociada.", estilo_muted)
                    )

                elementos.append(Spacer(1, 8))

            if indice_categoria < len(datos) - 1:
                elementos.append(Spacer(1, 8))

        doc.build(elementos)

    def _importar_csv(self):
        archivo = filedialog.askopenfilename(
            title="Importar archivo CSV",
            filetypes=[
                ("Archivo CSV", "*.csv"),
                ("Todos los archivos", "*.*"),
            ],
        )
        if not archivo:
            return
        ruta_csv = Path(archivo)
        if not ruta_csv.exists() or not ruta_csv.is_file():
            messagebox.showwarning("Archivo invalido", "Seleccione un archivo CSV valido.")
            return

        if ruta_csv.suffix.lower() != ".csv":
            messagebox.showwarning("Formato invalido", "Seleccione un archivo con extension .csv")
            return

        categoria_por_defecto = self.categoria_actual_nombre if self.categoria_actual_id else None

        try:
            insertados, actualizados, omitidos = self.db.importar_productos_csv(
                archivo,
                categoria_por_defecto=categoria_por_defecto,
            )
        except UnicodeDecodeError:
            messagebox.showwarning(
                "No se pudo importar",
                "El archivo no parece estar guardado en UTF-8. Guardelo como CSV UTF-8 desde Excel e intente de nuevo.",
            )
            return
        except ValueError as error:
            messagebox.showwarning("No se pudo importar", str(error))
            return
        except OSError:
            messagebox.showwarning("No se pudo importar", "No se pudo abrir el archivo seleccionado.")
            return
        except sqlite3.Error as error:
            messagebox.showwarning("Error de base de datos", f"SQLite no pudo importar el archivo:\n{error}")
            return

        self.productos_seleccionados.clear()
        self.producto_editando_id = None

        if self.categoria_actual_id:
            self._limpiar_formulario()
            self._cargar_productos()
        else:
            self._mostrar_inicio()

        messagebox.showinfo(
            "Importacion completada",
            f"Productos nuevos: {insertados}\n"
            f"Productos actualizados: {actualizados}\n"
            f"Filas omitidas: {omitidos}",
        )

