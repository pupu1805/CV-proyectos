"""Pantallas principales, historial, papelera y transiciones visuales."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppViewsMixin:
    def _limpiar_pantalla(self):
        for widget in self.contenedor.winfo_children():
            widget.destroy()
        self.after(10, self._reposicionar_toggle_tema)

    def _poner_letras_ueas(self, parent):
        letras_frame = tk.Frame(parent, bg=COLOR_FONDO)

        letras_frame.place(
        relx=0.98,
        rely=0.25,
        anchor="ne"
        )

        for i, letra in enumerate(["U", "E", "A", "S"]):
            tk.Label(
                letras_frame,
                text=letra,
                bg=COLOR_FONDO,
                fg=COLOR_ROJO,
                font=("Segoe UI", 90, "bold"),
            ).grid(row=i, column=0, pady=5)

    def _ver_papelera(self):
        ventana = tk.Toplevel(self)
        ventana.title("Papelera")
        ventana.geometry("820x500")
        ventana.minsize(680, 420)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(0, weight=1)
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        panel_base = RoundedCard(
            ventana,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=18,
            fill_height=True,
        )
        panel_base.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)

        frame = panel_base.contenido
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(1, weight=1)

        encabezado = ttk.Frame(frame, style="Card.TFrame")
        encabezado.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        encabezado.columnconfigure(0, weight=1)

        tk.Label(
            encabezado,
            text="Papelera",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 22, "bold"),
        ).grid(row=0, column=0, sticky="w")

        tk.Label(
            encabezado,
            text="Restaura elementos eliminados o bórralos definitivamente",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10),
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))

        acciones = ttk.Frame(encabezado, style="Card.TFrame")
        acciones.grid(row=0, column=1, rowspan=2, sticky="e")

        tabla_base = RoundedCard(
            frame,
            bg=COLOR_BLANCO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=20,
            padding=10,
            fill_height=True,
        )
        tabla_base.grid(row=1, column=0, sticky="nsew")
        tabla_frame = tabla_base.contenido
        tabla_frame.columnconfigure(0, weight=1)
        tabla_frame.rowconfigure(0, weight=1)

        columnas = ("tipo", "nombre", "detalle", "fecha")
        tabla = ttk.Treeview(
            tabla_frame,
            columns=columnas,
            show="headings",
            selectmode="extended",
            height=12,
            style="History.Treeview",
        )
        tabla_scroll = ttk.Scrollbar(
            tabla_frame,
            orient="vertical",
            command=tabla.yview,
            style="Category.Vertical.TScrollbar",
        )
        tabla.configure(yscrollcommand=tabla_scroll.set)

        tabla.heading("tipo", text="Tipo")
        tabla.heading("nombre", text="Nombre")
        tabla.heading("detalle", text="Detalle")
        tabla.heading("fecha", text="Enviado")
        tabla.column("tipo", width=110, anchor="center")
        tabla.column("nombre", width=220, anchor="w")
        tabla.column("detalle", width=280, anchor="w")
        tabla.column("fecha", width=150, anchor="center")
        tabla.tag_configure("fila_par", background=COLOR_BLANCO)
        tabla.tag_configure("fila_impar", background=COLOR_INPUT)
        tabla.grid(row=0, column=0, sticky="nsew")
        tabla_scroll.grid(row=0, column=1, sticky="ns", padx=(8, 0))

        elementos = {}

        def refrescar_vista_principal():
            if self.vista_actual == "inventario" and self.categoria_actual_id:
                self.productos_seleccionados.clear()
                self._limpiar_formulario()
                self._cargar_productos()
            else:
                self._mostrar_inicio()
            ventana.lift()
            ventana.focus_force()

        def cargar_papelera():
            elementos.clear()
            for item in tabla.get_children():
                tabla.delete(item)

            categorias, productos = self.db.obtener_papelera()
            fila = 0
            for categoria_id, nombre, eliminado_en, total_productos in categorias:
                item_id = tabla.insert(
                    "",
                    "end",
                    values=("Categoría", nombre, f"{total_productos} opciones asociadas", eliminado_en),
                    tags=("fila_par" if fila % 2 == 0 else "fila_impar",),
                )
                elementos[item_id] = ("categoria", categoria_id, nombre)
                fila += 1

            for producto_id, nombre, categoria_nombre, eliminado_en in productos:
                item_id = tabla.insert(
                    "",
                    "end",
                    values=("Opción", nombre, f"Categoría: {categoria_nombre or 'sin categoría'}", eliminado_en),
                    tags=("fila_par" if fila % 2 == 0 else "fila_impar",),
                )
                elementos[item_id] = ("producto", producto_id, nombre)
                fila += 1

            if fila == 0:
                tabla.insert("", "end", values=("", "Papelera vacía", "", ""), tags=("fila_par",))

        def seleccion_actual():
            seleccion = [elementos[item_id] for item_id in tabla.selection() if item_id in elementos]
            if not seleccion:
                messagebox.showwarning(
                    "Sin selección",
                    "Seleccione uno o varios elementos de la papelera.",
                    parent=ventana,
                )
            return seleccion

        def restaurar():
            seleccion = seleccion_actual()
            if not seleccion:
                return

            for tipo, elemento_id, nombre in seleccion:
                if tipo == "categoria":
                    self.db.restaurar_categoria(elemento_id)
                    entidad = "CATEGORÍA"
                else:
                    self.db.restaurar_producto(elemento_id)
                    entidad = "OPCIÓN"
                self.db.registrar_historial(
                    self.usuario_actual,
                    "RESTAURÓ",
                    entidad,
                    f"Restauró desde papelera: {nombre}",
                )

            cargar_papelera()
            refrescar_vista_principal()

        def eliminar_definitivo():
            seleccion = seleccion_actual()
            if not seleccion:
                return

            confirmar = messagebox.askyesno(
                "Eliminar definitivamente",
                f"Esta acción no se puede deshacer. ¿Desea eliminar definitivamente {len(seleccion)} elemento(s)?",
                parent=ventana,
            )
            if not confirmar:
                return

            productos = [elemento_id for tipo, elemento_id, _nombre in seleccion if tipo == "producto"]
            categorias = [(elemento_id, nombre) for tipo, elemento_id, nombre in seleccion if tipo == "categoria"]

            if productos:
                self.db.eliminar_productos_definitivo(productos)
            for categoria_id, _nombre in categorias:
                self.db.eliminar_categoria_definitivo(categoria_id)

            for tipo, _elemento_id, nombre in seleccion:
                self.db.registrar_historial(
                    self.usuario_actual,
                    "ELIMINÓ DEFINITIVO",
                    "CATEGORÍA" if tipo == "categoria" else "OPCIÓN",
                    f"Eliminó definitivamente: {nombre}",
                )

            cargar_papelera()
            refrescar_vista_principal()

        self._crear_boton(
            acciones,
            text="Restaurar",
            command=restaurar,
            width=112,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Eliminar definitivo",
            command=eliminar_definitivo,
            variant="danger",
            width=162,
            height=36,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1)

        self._vincular_atajos_ventana(ventana, cerrar=_cerrar_ventana)
        cargar_papelera()

    def _mostrar_inicio(self):
        self.vista_actual = "inicio"
        self._limpiar_pantalla()
        self.categoria_actual_id = None
        self.categoria_actual_nombre = ""
        self.producto_editando_id = None
        self.productos_seleccionados.clear()
        self.categoria_imagen_refs = []
        self.categorias = self.db.obtener_categorias_con_totales()

        pagina = ttk.Frame(self.contenedor, style="App.TFrame", padding=24)
        pagina.grid(row=0, column=0, sticky="nsew")
        self.contenedor.columnconfigure(0, weight=1)
        self.contenedor.rowconfigure(0, weight=1)
        pagina.columnconfigure(0, weight=1)
        pagina.rowconfigure(1, weight=0)
        pagina.rowconfigure(2, weight=1)

        encabezado = RoundedCard(
            pagina,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=12, 
            min_height=112,
        )
        encabezado.grid(row=0, column=0, sticky="ew", pady=(0, 24))

        panel_superior = encabezado.contenido
        panel_superior.columnconfigure(0, minsize=350)
        panel_superior.columnconfigure(1, weight=1)
        panel_superior.columnconfigure(2, weight=0)

        panel_usuario_borde = RoundedCard(
            panel_superior,
            bg=COLOR_BLANCO,
            fill=COLOR_BLANCO,
            outline="#9bdcff",
            radius=20,
            padding=10,
            min_width=350,
            min_height=92,
        )
        panel_usuario_borde.grid(row=0, column=0, sticky="w", padx=(0, 22))
        self._crear_panel_usuario_inicio(panel_usuario_borde.contenido, envolver=False, compacto=True)

        bloque_central = ttk.Frame(panel_superior, style="Card.TFrame")
        bloque_central.grid(row=0, column=1, sticky="w")
        bloque_central.columnconfigure(0, weight=1)

        marca_frame = ttk.Frame(bloque_central, style="Card.TFrame")
        marca_frame.grid(row=0, column=0, sticky="w")
        marca_frame.columnconfigure(1, weight=1)

        logo = self._poner_logo(marca_frame, bg=COLOR_BLANCO, max_ancho=88, max_alto=56)
        if logo:
            logo.grid(row=0, column=0, rowspan=2, sticky="w", padx=(0, 16))

        tk.Label(
            marca_frame,
            text="Sistema de Inventario",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 22, "bold"),
        ).grid(row=0, column=1, sticky="w", pady=(0, 2))

        tk.Label(
            marca_frame,
            text="Gestión de ubicaciones, mobiliario y reportes",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10),
        ).grid(row=1, column=1, sticky="w")

        acciones_panel = ttk.Frame(panel_superior, style="Card.TFrame")
        acciones_panel.grid(row=0, column=2, sticky="e", padx=(24, 0))

        acciones_superior = ttk.Frame(acciones_panel, style="Card.TFrame")
        acciones_superior.grid(row=0, column=0, sticky="e")

        acciones_inferior = ttk.Frame(acciones_panel, style="Card.TFrame")
        acciones_inferior.grid(row=1, column=0, sticky="w", pady=(10, 0))

        self._crear_boton(
            acciones_superior,
            text="Importar CSV",
            command=self._importar_csv,
            width=140,
            height=40,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 10))

        self._crear_boton(
            acciones_superior,
            text="Agregar ubicación",
            command=self._agregar_categoria,
            width=165,
            height=40,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, padx=(0, 10))

        self._crear_boton_imagen(
            acciones_superior,
            image_path=CSV_ICON_PATH,
            command=self._exportar_csv_todo,
            size=46,
            bg=COLOR_BLANCO,
            fallback_text="CSV",
        ).grid(row=0, column=2, padx=(0, 10))

        self._crear_boton_imagen(
            acciones_superior,
            image_path=PDF_ICON_PATH,
            command=self._exportar_pdf_todo,
            size=46,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=3, padx=(0, 10))
        
        self._crear_boton(
            acciones_inferior,
            text="Ver historial",
            command=self._ver_historial,
            variant="secondary",
            width=138,
            height=34,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones_inferior,
            text="Respaldar",
            command=self._exportar_respaldo_completo,
            variant="secondary",
            width=122,
            height=34,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones_inferior,
            text="Importar respaldo",
            command=self._importar_respaldo_completo,
            variant="secondary",
            width=168,
            height=34,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=2, sticky="w")

        barra_busqueda = RoundedCard(
            pagina,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=20,
            padding=12,
            min_height=58,
        )
        barra_busqueda.grid(row=1, column=0, sticky="ew", pady=(0, 16))

        contenido_busqueda = barra_busqueda.contenido
        contenido_busqueda.columnconfigure(1, weight=1)

        ttk.Label(
            contenido_busqueda,
            text="Buscar ubicación o mobiliario:",
            style="Card.TLabel",
        ).grid(row=0, column=0, sticky="w", padx=(0, 10))

        self.busqueda_categorias_var = tk.StringVar()
        entrada_categorias = ttk.Entry(contenido_busqueda, textvariable=self.busqueda_categorias_var)
        entrada_categorias.grid(row=0, column=1, sticky="ew")

        resumen_categorias_var = tk.StringVar(value=f"{len(self.categorias)} categorias")
        ttk.Label(
            contenido_busqueda,
            textvariable=resumen_categorias_var,
            style="Muted.TLabel",
        ).grid(row=0, column=2, sticky="e", padx=(10, 0))

        usar_scroll_categorias = len(self.categorias) >= 10
        if usar_scroll_categorias:
            tarjetas_scroll = ScrollFrame(
                pagina,
                canvas_bg=COLOR_FONDO,
                content_style="App.TFrame",
                scrollbar_style="Category.Vertical.TScrollbar",
                auto_hide=False,
            )
            tarjetas_scroll.grid(row=2, column=0, sticky="nsew")
            tarjetas = tarjetas_scroll.contenido
        else:
            tarjetas = ttk.Frame(pagina, style="App.TFrame")
            tarjetas.grid(row=2, column=0, sticky="nsew")

        tarjetas.columnconfigure((0, 1, 2), weight=0)

        def renderizar_categorias(texto_busqueda=""):
            for widget in tarjetas.winfo_children():
                widget.destroy()

            patron = texto_busqueda.strip().lower()
            coincidencias_productos = (
                self.db.buscar_categorias_por_producto(texto_busqueda)
                if patron
                else {}
            )
            categorias_filtradas = [
                categoria for categoria in self.categorias
                if not patron
                or patron in categoria[1].lower()
                or categoria[0] in coincidencias_productos
            ]

            if patron:
                resumen_categorias_var.set(
                    f"{len(categorias_filtradas)} de {len(self.categorias)} categorias"
                )
            else:
                resumen_categorias_var.set(f"{len(self.categorias)} categorias")

            if not categorias_filtradas:
                mensaje = "No se encontraron categorias." if patron else "No hay categorias creadas."
                ttk.Label(tarjetas, text=mensaje, style="TLabel").grid(row=0, column=0, sticky="w")
                if usar_scroll_categorias:
                    tarjetas_scroll._actualizar_scroll()
                return

            for indice, (categoria_id, nombre, imagen_categoria, total_productos, prestamos_pendientes) in enumerate(categorias_filtradas):
                fila = indice // 3
                columna = indice % 3
                tarjeta_base = RoundedCard(
                    tarjetas,
                    bg=COLOR_FONDO,
                    fill=COLOR_BLANCO,
                    outline="#fca5a5" if prestamos_pendientes else COLOR_BORDE,
                    radius=24,
                    padding=18,
                    min_width=360,
                    min_height=175,
                )
                tarjeta_base.grid(row=fila, column=columna, sticky="nw", padx=9, pady=9)
                tarjeta = tarjeta_base.contenido
                tarjeta.columnconfigure(0, weight=1)
                tarjeta.columnconfigure(1, weight=0)

                panel_derecho = ttk.Frame(tarjeta, style="Card.TFrame")
                panel_derecho.grid(row=0, column=1, rowspan=4, sticky="ne", padx=(12, 0), pady=(0, 6))

                imagen_label = self._crear_imagen_categoria_expandible(panel_derecho, imagen_categoria)
                if imagen_label:
                    imagen_label.grid(
                        row=0,
                        column=0,
                        sticky="ne",
                    )

                ttk.Label(
                    tarjeta,
                    text=nombre,
                    style="CardTitle.TLabel"
                ).grid(row=0, column=0, sticky="w", pady=(0, 8))

                detalle_categoria = f"{total_productos} opciones registradas"
                if prestamos_pendientes:
                    detalle_categoria += f" · {prestamos_pendientes} préstamos pendientes"

                tk.Label(
                    tarjeta,
                    text=detalle_categoria,
                    bg=COLOR_BLANCO,
                    fg=COLOR_ROJO if prestamos_pendientes else COLOR_TEXTO_SUAVE,
                    font=("Segoe UI", 9, "bold" if prestamos_pendientes else "normal"),
                ).grid(row=1, column=0, sticky="w", pady=(0, 6))

                barra_fondo = tk.Frame(tarjeta, bg="#dbeafe", height=8)
                barra_fondo.grid(row=2, column=0, sticky="ew", pady=(0, 10))
                barra_fondo.columnconfigure(0, weight=1)

                ancho_barra = min(100, total_productos * 15)

                barra = tk.Frame(
                    barra_fondo,
                    bg=COLOR_CELESTE,
                    height=8,
                    width=ancho_barra
                )
                barra.place(x=0, y=0, height=8, width=ancho_barra)

                coincide_en_mobiliario = patron and categoria_id in coincidencias_productos
                if coincide_en_mobiliario:
                    detalles_encontrados = coincidencias_productos.get(categoria_id, [])
                    texto_coincidencia = "Coincidencia en: " + " | ".join(detalles_encontrados)
                else:
                    texto_coincidencia = "Abrir lista y objetos"

                tk.Label(
                    tarjeta,
                    text=texto_coincidencia,
                    bg=COLOR_BLANCO,
                    fg=COLOR_TEXTO_SUAVE,
                    font=("Segoe UI", 9),
                    wraplength=270,
                    justify="left",
                    anchor="w",
                ).grid(row=3, column=0, sticky="w", pady=(0, 14))

                acciones = ttk.Frame(tarjeta, style="Card.TFrame")
                acciones.grid(row=4, column=0, columnspan=2, sticky="ew")

                self._crear_boton(
                    acciones,
                    text="Abrir",
                    command=lambda cat_id=categoria_id, cat_nombre=nombre: self.transicion(
                        lambda: self._abrir_categoria(cat_id, cat_nombre),
                        "izquierda",
                    ),
                    width=130,
                    bg=COLOR_BLANCO,
                ).grid(row=0, column=0, sticky="w", padx=(0, 8))

                self._crear_boton(
                    acciones,
                    text="Eliminar",
                    command=lambda cat_id=categoria_id, cat_nombre=nombre: self._eliminar_categoria(cat_id, cat_nombre),
                    variant="danger",
                    width=130,
                    bg=COLOR_BLANCO,
                ).grid(row=0, column=1, sticky="w")

                self._crear_boton_lapiz(
                    acciones,
                    command=lambda cat_id=categoria_id, cat_nombre=nombre, cat_imagen=imagen_categoria: self._editar_categoria(
                        cat_id,
                        cat_nombre,
                        cat_imagen,
                    ),
                    bg=COLOR_BLANCO,
                ).grid(row=0, column=2, sticky="w", padx=(8, 0))

            if usar_scroll_categorias:
                tarjetas_scroll._actualizar_scroll()

        def programar_render_categorias(*_args):
            if self._categoria_search_after_id is not None:
                self.after_cancel(self._categoria_search_after_id)
            self._categoria_search_after_id = self.after(
                140,
                lambda: renderizar_categorias(self.busqueda_categorias_var.get()),
            )

        entrada_categorias.bind("<Escape>", lambda _event: self.busqueda_categorias_var.set(""))
        self.busqueda_categorias_var.trace_add("write", programar_render_categorias)

        def _ir_a_busqueda(_event=None):
            entrada_categorias.focus_set()
            entrada_categorias.select_range(0, tk.END)
            return "break"

        self.bind("<Control-f>", _ir_a_busqueda)
        pagina.bind("<Destroy>", lambda _e: self.unbind("<Control-f>"))

        self._poner_letras_ueas(pagina)

        renderizar_categorias()

    def _ver_historial(self, estado=None, geometry=None):
        if estado is None and self._historial_abierto():
            self.historial_ventana.lift()
            self.historial_ventana.focus_force()
            return

        estado = estado or self.historial_estado or {}
        ventana = tk.Toplevel(self)
        self.historial_ventana = ventana
        ventana.title("Historial de acciones")
        ventana.geometry(geometry or "900x520")
        ventana.minsize(760, 420)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(0, weight=1)
        
        self._deshabilitar_tema()

        def cerrar_historial():
            self.historial_estado = self._obtener_estado_historial()
            self.historial_vars = {}
            self.historial_ventana = None
            ventana.destroy()
            self._habilitar_tema()

        ventana.protocol("WM_DELETE_WINDOW", cerrar_historial)
        self._vincular_atajos_ventana(ventana, cerrar=cerrar_historial)

        panel_base = RoundedCard(
            ventana,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=18,
            fill_height=True,
        )
        panel_base.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)

        frame = panel_base.contenido
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(2, weight=1)

        encabezado = ttk.Frame(frame, style="Card.TFrame")
        encabezado.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        encabezado.columnconfigure(0, weight=1)

        tk.Label(
            encabezado,
            text="Historial de acciones",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 22, "bold"),
        ).grid(row=0, column=0, sticky="w")

        tk.Label(
            encabezado,
            text="Consulta los movimientos registrados en el sistema",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10),
        ).grid(row=1, column=0, sticky="w", pady=(4, 0))

        self._crear_boton(
            encabezado,
            text="Cerrar",
            command=cerrar_historial,
            variant="secondary",
            width=110,
            height=38,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, rowspan=2, sticky="e")

        barra_base = RoundedCard(
            frame,
            bg=COLOR_BLANCO,
            fill=COLOR_INPUT,
            outline=COLOR_BORDE,
            radius=18,
            padding=12,
            min_height=150,
        )
        barra_base.grid(row=1, column=0, sticky="ew", pady=(0, 14))

        barra_busqueda = barra_base.contenido
        barra_busqueda.configure(bg=COLOR_INPUT)
        barra_busqueda.columnconfigure(1, weight=1)
        barra_busqueda.columnconfigure(5, weight=1)

        ttk.Label(
            barra_busqueda,
            text="Buscar:",
            style="ImageTitle.TLabel",
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        busqueda_var = tk.StringVar(value=estado.get("busqueda", ""))
        entrada_busqueda = ttk.Entry(barra_busqueda, textvariable=busqueda_var)
        entrada_busqueda.grid(row=0, column=1, sticky="ew")

        resumen_var = tk.StringVar(value="0 resultados")
        ttk.Label(
            barra_busqueda,
            textvariable=resumen_var,
            style="GalleryMuted.TLabel",
        ).grid(row=0, column=2, sticky="e", padx=(10, 0))

        historial = self.db.obtener_historial()
        usuarios_historial = sorted({usuario for usuario, _accion, _entidad, _detalle, _fecha in historial})
        acciones_historial = sorted({accion for _usuario, accion, _entidad, _detalle, _fecha in historial})

        usuario_inicial = estado.get("usuario", "Todos")
        accion_inicial = estado.get("accion", "Todas")
        if usuario_inicial != "Todos" and usuario_inicial not in usuarios_historial:
            usuario_inicial = "Todos"
        if accion_inicial != "Todas" and accion_inicial not in acciones_historial:
            accion_inicial = "Todas"

        usuario_filtro_var = tk.StringVar(value=usuario_inicial)
        accion_filtro_var = tk.StringVar(value=accion_inicial)
        fecha_filtro_var = tk.StringVar(value=estado.get("fecha", ""))
        rango_filtro_var = tk.StringVar(value=estado.get("rango", ""))
        self.historial_vars = {
            "busqueda": busqueda_var,
            "usuario": usuario_filtro_var,
            "accion": accion_filtro_var,
            "fecha": fecha_filtro_var,
            "rango": rango_filtro_var,
        }

        ttk.Label(
            barra_busqueda,
            text="Usuario:",
            style="ImageTitle.TLabel",
        ).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(12, 0))

        usuario_combo = ttk.Combobox(
            barra_busqueda,
            textvariable=usuario_filtro_var,
            values=["Todos"] + usuarios_historial,
            state="readonly",
            width=18,
        )
        usuario_combo.grid(row=1, column=1, sticky="w", pady=(12, 0))

        ttk.Label(
            barra_busqueda,
            text="Acción:",
            style="ImageTitle.TLabel",
        ).grid(row=1, column=2, sticky="e", padx=(12, 8), pady=(12, 0))

        accion_combo = ttk.Combobox(
            barra_busqueda,
            textvariable=accion_filtro_var,
            values=["Todas"] + acciones_historial,
            state="readonly",
            width=16,
        )
        accion_combo.grid(row=1, column=3, sticky="w", pady=(12, 0))

        ttk.Label(
            barra_busqueda,
            text="Fecha:",
            style="ImageTitle.TLabel",
        ).grid(row=1, column=4, sticky="e", padx=(12, 8), pady=(12, 0))

        fecha_entry = ttk.Entry(barra_busqueda, textvariable=fecha_filtro_var, width=14)
        fecha_entry.grid(row=1, column=5, sticky="w", pady=(12, 0))

        self._crear_boton(
            barra_busqueda,
            text="Limpiar",
            command=lambda: limpiar_filtros(),
            variant="secondary",
            width=92,
            height=34,
            bg=COLOR_INPUT,
        ).grid(row=1, column=6, sticky="e", padx=(10, 0), pady=(12, 0))

        ttk.Label(
            barra_busqueda,
            text="Rápido:",
            style="ImageTitle.TLabel",
        ).grid(row=2, column=0, sticky="w", padx=(0, 8), pady=(12, 0))

        self._crear_boton(
            barra_busqueda,
            text="Hoy",
            command=lambda: aplicar_rango("Hoy"),
            variant="secondary",
            width=72,
            height=30,
            bg=COLOR_INPUT,
        ).grid(row=2, column=1, sticky="w", pady=(12, 0))

        self._crear_boton(
            barra_busqueda,
            text="Semana",
            command=lambda: aplicar_rango("Semana"),
            variant="secondary",
            width=88,
            height=30,
            bg=COLOR_INPUT,
        ).grid(row=2, column=2, sticky="w", padx=(8, 0), pady=(12, 0))

        self._crear_boton(
            barra_busqueda,
            text="Mes",
            command=lambda: aplicar_rango("Mes"),
            variant="secondary",
            width=72,
            height=30,
            bg=COLOR_INPUT,
        ).grid(row=2, column=3, sticky="w", padx=(8, 0), pady=(12, 0))

        columnas = ("fecha", "usuario", "accion", "entidad", "detalle")

        tabla_base = RoundedCard(
            frame,
            bg=COLOR_BLANCO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=20,
            padding=10,
            fill_height=True,
        )
        tabla_base.grid(row=2, column=0, sticky="nsew")
        tabla_frame = tabla_base.contenido
        tabla_frame.columnconfigure(0, weight=1)
        tabla_frame.rowconfigure(0, weight=1)

        tabla = ttk.Treeview(
            tabla_frame,
            columns=columnas,
            show="headings",
            height=12,
            style="History.Treeview",
        )
        tabla_scroll = ttk.Scrollbar(
            tabla_frame,
            orient="vertical",
            command=tabla.yview,
            style="Category.Vertical.TScrollbar",
        )
        tabla.configure(yscrollcommand=tabla_scroll.set)

        tabla.heading("fecha", text="Fecha")
        tabla.heading("usuario", text="Usuario")
        tabla.heading("accion", text="Acción")
        tabla.heading("entidad", text="Entidad")
        tabla.heading("detalle", text="Detalle")

        tabla.column("fecha", width=145, anchor="center")
        tabla.column("usuario", width=145, anchor="w")
        tabla.column("accion", width=110, anchor="center")
        tabla.column("entidad", width=120, anchor="center")
        tabla.column("detalle", width=330, anchor="w")

        tabla.tag_configure("fila_par", background=COLOR_BLANCO)
        tabla.tag_configure("fila_impar", background=COLOR_INPUT)

        tabla.grid(row=0, column=0, sticky="nsew")
        tabla_scroll.grid(row=0, column=1, sticky="ns", padx=(8, 0))

        def fecha_en_rango(fecha, rango):
            if not rango:
                return True

            try:
                fecha_dt = datetime.strptime(fecha, "%d/%m/%Y %H:%M:%S")
            except ValueError:
                return False

            ahora = datetime.now()
            if rango == "Hoy":
                return fecha_dt.date() == ahora.date()
            if rango == "Semana":
                return fecha_dt >= ahora - timedelta(days=7)
            if rango == "Mes":
                return fecha_dt.year == ahora.year and fecha_dt.month == ahora.month
            return True

        def aplicar_rango(rango):
            rango_filtro_var.set(rango)
            fecha_filtro_var.set("")
            actualizar_tabla()

        def actualizar_tabla(_event=None):
            texto = busqueda_var.get().strip().lower()
            usuario_filtrado = usuario_filtro_var.get()
            accion_filtrada = accion_filtro_var.get()
            fecha_filtrada = fecha_filtro_var.get().strip().lower()
            rango_filtrado = rango_filtro_var.get()

            for item in tabla.get_children():
                tabla.delete(item)

            mostrados = 0
            for usuario, accion, entidad, detalle, fecha in historial:
                bolsa = f"{fecha} {usuario} {accion} {entidad} {detalle}".lower()
                if texto and texto not in bolsa:
                    continue
                if usuario_filtrado != "Todos" and usuario != usuario_filtrado:
                    continue
                if accion_filtrada != "Todas" and accion != accion_filtrada:
                    continue
                if fecha_filtrada and fecha_filtrada not in fecha.lower():
                    continue
                if rango_filtrado and not fecha_en_rango(fecha, rango_filtrado):
                    continue

                tabla.insert(
                    "",
                    "end",
                    values=(fecha, usuario, accion, entidad, detalle),
                    tags=("fila_par" if mostrados % 2 == 0 else "fila_impar",),
                )
                mostrados += 1

            total = len(historial)
            hay_filtros = (
                bool(texto)
                or usuario_filtrado != "Todos"
                or accion_filtrada != "Todas"
                or bool(fecha_filtrada)
                or bool(rango_filtrado)
            )
            if hay_filtros:
                resumen_var.set(f"{mostrados} de {total} resultados")
            else:
                resumen_var.set(f"{total} resultados")

        def limpiar_filtros():
            busqueda_var.set("")
            usuario_filtro_var.set("Todos")
            accion_filtro_var.set("Todas")
            fecha_filtro_var.set("")
            rango_filtro_var.set("")
            actualizar_tabla()

        entrada_busqueda.bind("<KeyRelease>", actualizar_tabla)
        entrada_busqueda.bind("<Escape>", lambda _event: busqueda_var.set(""))
        busqueda_var.trace_add("write", lambda *_: actualizar_tabla())
        usuario_combo.bind("<<ComboboxSelected>>", actualizar_tabla)
        accion_combo.bind("<<ComboboxSelected>>", actualizar_tabla)
        fecha_entry.bind("<KeyRelease>", actualizar_tabla)
        fecha_entry.bind("<Escape>", lambda _event: fecha_filtro_var.set(""))
        fecha_filtro_var.trace_add("write", lambda *_: actualizar_tabla())
        rango_filtro_var.trace_add("write", lambda *_: actualizar_tabla())
        entrada_busqueda.focus_set()
        actualizar_tabla()

    def _fade_in(self, alpha=0.0, pasos=18, delay=18):
        """Sube la opacidad de la ventana de 0 a 1 suavemente."""
        alpha = min(alpha + 1.0 / pasos, 1.0)
        self.attributes("-alpha", alpha)
        if alpha < 1.0:
            self.after(delay, lambda: self._fade_in(alpha, pasos, delay))

    def _fade_out(self, callback, alpha=1.0, pasos=14, delay=16):
        """Baja la opacidad a 0 y luego ejecuta callback."""
        alpha = max(alpha - 1.0 / pasos, 0.0)
        self.attributes("-alpha", alpha)
        if alpha > 0.0:
            self.after(delay, lambda: self._fade_out(callback, alpha, pasos, delay))
        else:
            callback()

    def _mostrar_bienvenida(self, nombre, callback):
        """Flash de bienvenida centrado antes de mostrar el inicio."""
        overlay = tk.Frame(self, bg=COLOR_FONDO)
        overlay.place(relx=0, rely=0, relwidth=1, relheight=1)
        overlay.lift()

        tk.Label(
            overlay,
            text=f"Bienvenido,",
            bg=COLOR_FONDO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 16),
        ).place(relx=0.5, rely=0.42, anchor="center")

        tk.Label(
            overlay,
            text=nombre,
            bg=COLOR_FONDO,
            fg=COLOR_CELESTE,
            font=("Segoe UI", 32, "bold"),
        ).place(relx=0.5, rely=0.52, anchor="center")

        def cerrar_overlay():
            overlay.destroy()
            callback()
            self._fade_in()

        self.after(self.duracion_bienvenida_ms, cerrar_overlay)

