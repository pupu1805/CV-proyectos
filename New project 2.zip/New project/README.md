# Sistema de Inventario

Aplicacion de inventario en Python con Tkinter y SQLite. El codigo fue separado en modulos para que sea mas facil de mantener, mover a otra computadora y empaquetar.

## Estructura

```text
New project/
├── main.py              # Entrada recomendada
├── inventario_app.py    # Entrada compatible con la version anterior
├── app.py               # Clase principal y arranque de interfaz
├── app_core.py          # Tema, estilos, atajos y controles base
├── app_profile.py       # Login, perfil y contrasena
├── app_categories.py    # Categorias e imagenes de ubicaciones
├── app_views.py         # Inicio, historial, papelera y transiciones
├── app_inventory.py     # Checklist, formulario e imagenes de productos
├── app_loans.py         # Prestamos y devoluciones
├── app_exports.py       # CSV, PDF y respaldos ZIP
├── config.py            # Rutas, colores y tema
├── theme_runtime.py     # Sincronizacion del tema entre modulos
├── database.py          # Base de datos SQLite y operaciones de inventario
├── widgets.py           # Botones, tarjetas, scrolls y controles visuales
├── requirements.txt     # Dependencias externas
├── inventario.db        # Base de datos local
├── logo.png
├── pdf_icon.png
├── csv_icon.png
└── imagenes/
```

## Como ejecutarlo

1. Instale Python 3.12 o superior.
2. Instale las dependencias externas:

```bash
python -m pip install -r requirements.txt
```

3. Ejecute la aplicacion:

```bash
python main.py
```

Tambien funciona la forma antigua:

```bash
python inventario_app.py
```

## Notas para moverlo a otra computadora

- Copie la carpeta completa `New project`.
- No copie entornos virtuales ni carpetas `__pycache__`; se regeneran automaticamente.
- La base `inventario.db` guarda los datos del inventario.
- Las imagenes usadas por categorias y productos viven en `imagenes/`.

## Funciones principales

- Login y registro de usuarios.
- Categorias/ubicaciones con imagen.
- Mobiliario con contenido por cantidades e imagen propia.
- Busqueda, seleccion multiple y vista de detalles.
- Prestamos y devoluciones por objeto y cantidad.
- Papelera con restauracion o eliminacion definitiva.
- Exportacion a CSV, PDF y respaldo completo ZIP.
- Importacion desde CSV y respaldo completo.
- Tema claro/oscuro.
