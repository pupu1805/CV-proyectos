"""Registro y consulta de prestamos/devoluciones."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppLoansMixin:
    def _registrar_prestamo_producto(self):
        if not self.categoria_actual_id:
            messagebox.showwarning(
                "Sin categoría",
                "Seleccione primero una categoría para registrar el préstamo.",
            )
            return

        productos = self.db.buscar_productos(self.categoria_actual_id, "")
        if not productos:
            messagebox.showwarning(
                "Sin opciones",
                "No hay opciones disponibles en esta categoría para prestar.",
            )
            return

        seleccion = {"producto": None, "objeto": ""}
        productos_por_nombre = {}
        nombres = []
        for pid, nombre, contenido, _imagen in productos:
            nombre_unico = nombre
            contador = 2
            while nombre_unico in productos_por_nombre:
                nombre_unico = f"{nombre} ({contador})"
                contador += 1
            filas_contenido = self._parsear_contenido_a_filas(contenido)
            objetos = []
            for fila in filas_contenido:
                descripcion = fila["descripcion"]
                cantidad = int(fila["cantidad"])
                if cantidad > 1:
                    objetos.append(f"{descripcion} (x{cantidad})")
                else:
                    objetos.append(descripcion)
            productos_por_nombre[nombre_unico] = (pid, nombre, contenido, objetos)
            nombres.append(nombre_unico)

        ventana_sel = tk.Toplevel(self)
        ventana_sel.title("Seleccionar mobiliario para préstamo")
        ventana_sel.geometry("760x430")
        ventana_sel.minsize(660, 360)
        ventana_sel.configure(bg=COLOR_FONDO)
        ventana_sel.transient(self)
        ventana_sel.grab_set()
        ventana_sel.columnconfigure(0, weight=1)
        ventana_sel.rowconfigure(0, weight=1)
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana_sel.destroy()
            self._habilitar_tema()

        panel = RoundedCard(
            ventana_sel,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=20,
            padding=16,
            fill_height=True,
        )
        panel.grid(row=0, column=0, sticky="nsew", padx=16, pady=16)
        frame_sel = panel.contenido
        frame_sel.columnconfigure(0, weight=1)
        frame_sel.rowconfigure(3, weight=1)

        tk.Label(
            frame_sel,
            text="Registrar préstamo",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 16, "bold"),
        ).grid(row=0, column=0, sticky="w")

        filtro = ttk.Frame(frame_sel, style="Card.TFrame")
        filtro.grid(row=1, column=0, sticky="ew", pady=(12, 10))
        filtro.columnconfigure(1, weight=1)

        tk.Label(
            filtro,
            text="Mobiliario:",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 10, "bold"),
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        mobiliario_var = tk.StringVar(value=nombres[0])
        combo_mobiliario = ttk.Combobox(
            filtro,
            textvariable=mobiliario_var,
            values=nombres,
            state="readonly",
        )
        combo_mobiliario.grid(row=0, column=1, sticky="ew")
        #tumtumtumtumsahurrrr
        tk.Label(
            filtro,
            text="Objeto:",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 10, "bold"),
        ).grid(row=1, column=0, sticky="w", padx=(0, 8), pady=(8, 0))

        objeto_var = tk.StringVar(value="")
        combo_objetos = ttk.Combobox(
            filtro,
            textvariable=objeto_var,
            values=[],
            state="readonly",
        )
        combo_objetos.grid(row=1, column=1, sticky="ew", pady=(8, 0))

        tk.Label(
            frame_sel,
            text="Objetos del mobiliario:",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 9, "bold"),
        ).grid(row=2, column=0, sticky="w", pady=(0, 4))

        contenido_texto = tk.Text(
            frame_sel,
            height=10,
            bg=COLOR_INPUT,
            fg=COLOR_TEXTO,
            relief="flat",
            bd=0,
            wrap="word",
            font=("Segoe UI", 10),
        )
        contenido_texto.grid(row=3, column=0, sticky="nsew")

        def actualizar_contenido_sel():
            clave = mobiliario_var.get().strip()
            datos = productos_por_nombre.get(clave)
            contenido = datos[2] if datos else ""
            objetos = datos[3] if datos else []

            if objetos:
                combo_objetos.config(values=objetos, state="readonly")
                objeto_var.set(objetos[0])
            else:
                combo_objetos.config(values=["(Sin objetos registrados)"], state="disabled")
                objeto_var.set("")

            contenido_texto.config(state="normal")
            contenido_texto.delete("1.0", "end")
            contenido_texto.insert("1.0", contenido or "Sin contenido registrado.")
            contenido_texto.config(state="disabled")

        def seleccionar_objeto():
            clave = mobiliario_var.get().strip()
            datos = productos_por_nombre.get(clave)
            if not datos:
                messagebox.showwarning(
                    "Sin selección",
                    "Seleccione un mobiliario de la lista desplegable.",
                    parent=ventana_sel,
                )
                return
            if str(combo_objetos.cget("state")) == "disabled":
                messagebox.showwarning(
                    "Sin objetos",
                    "El mobiliario seleccionado no tiene objetos para prestar.",
                    parent=ventana_sel,
                )
                return
            objeto_elegido = objeto_var.get().strip()
            if not objeto_elegido:
                messagebox.showwarning(
                    "Sin selección",
                    "Seleccione un objeto del mobiliario.",
                    parent=ventana_sel,
                )
                return
            seleccion["producto"] = datos
            seleccion["objeto"] = objeto_elegido
            _cerrar_ventana()

        acciones_sel = ttk.Frame(frame_sel, style="Card.TFrame")
        acciones_sel.grid(row=4, column=0, sticky="e", pady=(12, 0))
        self._crear_boton(
            acciones_sel,
            text="Cancelar",
            command=_cerrar_ventana,
            variant="secondary",
            width=120,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 8))
        self._crear_boton(
            acciones_sel,
            text="Seleccionar",
            command=seleccionar_objeto,
            variant="primary",
            width=140,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1)

        combo_mobiliario.bind("<<ComboboxSelected>>", lambda _e: actualizar_contenido_sel())
        ventana_sel.bind("<Return>", lambda _e: seleccionar_objeto())
        ventana_sel.bind("<Escape>", lambda _e: ventana_sel.destroy())

        actualizar_contenido_sel()
        combo_mobiliario.focus_set()
        self.wait_window(ventana_sel)

        if not seleccion["producto"]:
            return

        producto_id, nombre_producto, _contenido, _objetos = seleccion["producto"]
        objeto_prestado = seleccion.get("objeto", "")

        solicitante = simpledialog.askstring(
            "Registro de préstamo",
            f"¿Quién pidió el contenido '{objeto_prestado}' del mobiliario '{nombre_producto}'?",
            parent=self,
        )
        if solicitante is None:
            return

        solicitante = " ".join(solicitante.split())
        if len(solicitante) < 2:
            messagebox.showwarning("Dato requerido", "Ingrese el nombre de quien pidió el contenido seleccionado.")
            return

        hoy = datetime.now().strftime("%d/%m/%Y")
        fecha_prestamo = simpledialog.askstring(
            "Fecha de préstamo",
            "Ingrese la fecha de préstamo (dd/mm/aaaa):",
            initialvalue=hoy,
            parent=self,
        )
        if fecha_prestamo is None:
            return

        fecha_prestamo = fecha_prestamo.strip()
        if not self._validar_fecha_corta(fecha_prestamo):
            messagebox.showwarning("Fecha inválida", "La fecha de préstamo debe tener formato dd/mm/aaaa.")
            return

        fecha_devolucion = simpledialog.askstring(
            "Fecha de devolución",
            "Ingrese la fecha de devolución (dd/mm/aaaa) o deje vacío:",
            initialvalue="",
            parent=self,
        )
        if fecha_devolucion is None:
            return

        fecha_devolucion = fecha_devolucion.strip()
        if fecha_devolucion and not self._validar_fecha_corta(fecha_devolucion):
            messagebox.showwarning("Fecha inválida", "La fecha de devolución debe tener formato dd/mm/aaaa.")
            return

        objeto_limpio = objeto_prestado
        if " (x" in objeto_limpio and objeto_limpio.endswith(")"):
            objeto_limpio = objeto_limpio.rsplit(" (x", 1)[0].strip()

        cantidad_prestada = simpledialog.askinteger(
            "Cantidad prestada",
            f"¿Cuántos '{objeto_limpio}' se prestaron?",
            initialvalue=1,
            minvalue=1,
            parent=self,
        )

        if cantidad_prestada is None:
            return

        try:
            restante = self.db.descontar_item_contenido(
                producto_id,
                objeto_limpio,
                cantidad_prestada,
            )
        except ValueError as error:
            messagebox.showwarning("Cantidad no disponible", str(error))
            return


        self.db.registrar_prestamo(
            producto_id,
            objeto_limpio,
            cantidad_prestada,
            solicitante,
            fecha_prestamo,
            fecha_devolucion,
        )
        
        self.productos_seleccionados = {producto_id}
        self._cargar_productos()
        self._mostrar_detalles_seleccionados()

        detalle_devolucion = fecha_devolucion if fecha_devolucion else "pendiente"
        self.db.registrar_historial(
            self.usuario_actual,
            "PRÉSTAMO",
            "OPCIÓN",
            (
                f"Mobiliario: '{nombre_producto}' | Objeto: '{objeto_limpio}' | Cantidad: {cantidad_prestada} | Restante: {restante} | Quién pidió: {solicitante} | "
                f"Préstamo: {fecha_prestamo} | Devolución: {detalle_devolucion}"
            ),
        )

        messagebox.showinfo("Préstamo registrado", "El préstamo se registró correctamente.")

    def _ver_prestamos_categoria(self):
        if not self.categoria_actual_id:
            return

        ventana = tk.Toplevel(self)
        ventana.title(f"Registro de préstamos - {self.categoria_actual_nombre}")
        ventana.geometry("980x520")
        ventana.minsize(760, 420)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.grab_set()
        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(0, weight=1)
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        panel_base = RoundedCard(
            ventana,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=18,
            fill_height=True,
        )
        panel_base.grid(row=0, column=0, sticky="nsew", padx=18, pady=18)
        frame = panel_base.contenido
        frame.columnconfigure(0, weight=1)
        frame.rowconfigure(1, weight=1)

        encabezado = ttk.Frame(frame, style="Card.TFrame")
        encabezado.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        encabezado.columnconfigure(0, weight=1)

        tk.Label(
            encabezado,
            text="Registro de préstamos",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 20, "bold"),
        ).grid(row=0, column=0, sticky="w")

        self._crear_boton(
            encabezado,
            text="Marcar entrega",
            command=lambda: marcar_entrega(),
            variant="primary",
            width=170,
            height=38,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, sticky="e")

        tabla_base = RoundedCard(
            frame,
            bg=COLOR_BLANCO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=20,
            padding=10,
            fill_height=True,
        )
        tabla_base.grid(row=1, column=0, sticky="nsew")
        tabla_frame = tabla_base.contenido
        tabla_frame.columnconfigure(0, weight=1)
        tabla_frame.rowconfigure(0, weight=1)

        columnas = ("mobiliario", "objeto", "cantidad", "solicitante", "prestamo", "devolucion", "registro")
        tabla = ttk.Treeview(
            tabla_frame,
            columns=columnas,
            show="headings",
            height=12,
            style="History.Treeview",
        )
        tabla_scroll = ttk.Scrollbar(
            tabla_frame,
            orient="vertical",
            command=tabla.yview,
            style="Category.Vertical.TScrollbar",
        )
        tabla.configure(yscrollcommand=tabla_scroll.set)

        tabla.heading("mobiliario", text="Mobiliario")
        tabla.heading("objeto", text="Objeto")
        tabla.heading("cantidad", text="Cant.")
        tabla.heading("solicitante", text="Quién pidió")
        tabla.heading("prestamo", text="Fecha préstamo")
        tabla.heading("devolucion", text="Fecha devolución")
        tabla.heading("registro", text="Registrado")

        tabla.column("mobiliario", width=180, anchor="w")
        tabla.column("objeto", width=190, anchor="w")
        tabla.column("cantidad", width=70, anchor="center")
        tabla.column("solicitante", width=180, anchor="w")
        tabla.column("prestamo", width=135, anchor="center")
        tabla.column("devolucion", width=145, anchor="center")
        tabla.column("registro", width=170, anchor="center")

        tabla.tag_configure("fila_par", background=COLOR_BLANCO)
        tabla.tag_configure("fila_impar", background=COLOR_INPUT)

        tabla.grid(row=0, column=0, sticky="nsew")
        tabla_scroll.grid(row=0, column=1, sticky="ns", padx=(8, 0))

        prestamo_ids = {}

        def marcar_entrega():
            seleccion = tabla.selection()
            if not seleccion:
                messagebox.showwarning(
                    "Sin selección",
                    "Seleccione un préstamo pendiente para marcar la entrega.",
                    parent=ventana,
                )
                return
            

            item_id = seleccion[0]
            prestamo_id = prestamo_ids.get(item_id)
            if not prestamo_id:
                messagebox.showwarning(
                    "Sin registro",
                    "Seleccione un registro válido de préstamo.",
                    parent=ventana,
                )
                return

            (
                mobiliario,
                objeto,
                cantidad_visual,
                solicitante,
                fecha_prestamo,
                fecha_devolucion,
                fecha_registro,
            ) = tabla.item(
                item_id,
                "values",
            )
            if fecha_devolucion and fecha_devolucion != "Pendiente":
                confirmar = messagebox.askyesno(
                    "Cambiar fecha",
                    "Este préstamo ya tiene fecha de entrega. ¿Desea actualizarla?",
                    parent=ventana,
                )
                if not confirmar:
                    return

            hoy = datetime.now().strftime("%d/%m/%Y")
            fecha_entrega = simpledialog.askstring(
                "Fecha de entrega",
                "Ingrese la fecha en que se entregó (dd/mm/aaaa):",
                initialvalue=hoy,
                parent=ventana,
            )
            if fecha_entrega is None:
                return

            fecha_entrega = fecha_entrega.strip()
            if not self._validar_fecha_corta(fecha_entrega):
                messagebox.showwarning(
                    "Fecha inválida",
                    "La fecha de entrega debe tener formato dd/mm/aaaa.",
                    parent=ventana,
                )
                return
            
            datos = self.db.obtener_prestamo(prestamo_id)

            if not datos:
                messagebox.showerror("Error", "No se encontró el préstamo.")
                return

            producto_id, objeto, cantidad = datos
            
            
            self.db.devolver_item_contenido(producto_id, objeto, cantidad)
            self.db.actualizar_devolucion_prestamo(prestamo_id, fecha_entrega)

            self.db.actualizar_devolucion_prestamo(prestamo_id, fecha_entrega)
            
            self.db.registrar_historial(
                self.usuario_actual,
                "ENTREGA",
                "PRÉSTAMO",
                (
                    f"Mobiliario: '{mobiliario}' | Objeto: '{objeto}' | Cantidad: {cantidad_visual} | Quién pidió: {solicitante} | "
                    f"Préstamo: {fecha_prestamo} | Entregado: {fecha_entrega}"
                ),
            )
            tabla.item(
                item_id,
                values=(mobiliario, objeto, cantidad_visual, solicitante, fecha_prestamo, fecha_entrega, fecha_registro),
            )
            
            self.productos_seleccionados = {producto_id}
            self._cargar_productos()
            self._mostrar_detalles_seleccionados()
            self.update_idletasks()
            
            messagebox.showinfo(
                "Entrega actualizada",
                "La fecha de entrega se actualizó correctamente.",
                parent=ventana,
            )

        self._vincular_atajos_ventana(ventana, cerrar=_cerrar_ventana)

        prestamos = self.db.obtener_prestamos_categoria(self.categoria_actual_id)
        if not prestamos:
            tabla.insert(
                "",
                "end",
                values=("Sin registros", "", "", "", "", "", ""),
                tags=("fila_par",),
            )
            return

        for indice, (
            prestamo_id,
            mobiliario,
            objeto,
            cantidad,
            solicitante,
            fecha_prestamo,
            fecha_devolucion,
            fecha_registro,
        ) in enumerate(prestamos):
            item_id = tabla.insert(
                "",
                "end",
                values=(
                    mobiliario,
                    objeto,
                    cantidad,
                    solicitante,
                    fecha_prestamo,
                    fecha_devolucion or "Pendiente",
                    fecha_registro,
                ),
                tags=("fila_par" if indice % 2 == 0 else "fila_impar",),
            )
            prestamo_ids[item_id] = prestamo_id

