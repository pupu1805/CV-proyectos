"""Clase principal de la aplicacion de inventario."""

import sys
import tkinter as tk
from tkinter import ttk

import app_categories as categories_module
import app_core as core_module
import app_exports as exports_module
import app_inventory as inventory_module
import app_loans as loans_module
import app_profile as profile_module
import app_views as views_module
import widgets as widgets_module
from app_categories import AppCategoriesMixin
from app_core import AppCoreMixin
from app_exports import AppExportsMixin
from app_inventory import AppInventoryMixin
from app_loans import AppLoansMixin
from app_profile import AppProfileMixin
from app_views import AppViewsMixin
from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from theme_runtime import registrar_modulos_tema

registrar_modulos_tema(
    sys.modules[__name__],
    widgets_module,
    core_module,
    profile_module,
    categories_module,
    views_module,
    exports_module,
    inventory_module,
    loans_module,
)


class InventarioApp(
    AppProfileMixin,
    AppCoreMixin,
    AppCategoriesMixin,
    AppViewsMixin,
    AppExportsMixin,
    AppInventoryMixin,
    AppLoansMixin,
    tk.Tk,
):
    def __init__(self):
        super().__init__()
        self.tema_actual = "claro"
        _aplicar_paleta_visual(self.tema_actual)
        self.title("Sistema de Inventario")
        self.geometry("1120x680")
        self.minsize(930, 580)
        self.configure(bg=COLOR_FONDO)

        self.db = InventarioDB(DB_PATH)
        self.categorias = []
        self.categoria_actual_id = None
        self.categoria_actual_nombre = ""
        self.producto_editando_id = None
        self.productos_en_pantalla = {}
        self.check_vars = {}
        self.productos_seleccionados = set()
        self.nombre_entry = None
        self.imagen_actual = ""
        self.imagen_preview = None
        self.galeria_refs = []
        self.imagen_grande_ref = None
        self.logo_ref = None
        self.image_preview_cache = {}
        self.categoria_imagen_refs = []
        self.usuario_actual_id = None
        self.usuario_cargo = ""
        self.usuario_imagen = ""
        self.usuario_avatar_ref = None
        self.vista_actual = "inicio"
        self.theme_switch = None
        self.papelera_boton = None
        self.historial_ventana = None
        self.historial_vars = {}
        self.historial_estado = {}
        self._categoria_search_after_id = None
        self.duracion_bienvenida_ms = 450
        self.ventanas_modales_abiertas = 0
        
        self.usuario_actual = self._pedir_usuario()
        
        try:
            self.state("zoomed")  # Abre la app maximizada en Windows
        except tk.TclError:
            self.geometry("1120x680")

        try:
            if not self.winfo_exists():
                return
        except tk.TclError:
            return

        if self.usuario_actual == "Usuario sin identificar":
            self.destroy()
            return

        self._cargar_perfil_usuario(self.usuario_actual)

        self.lift()
        self.focus_force()
        self.after(100, self.lift)
        
        
        self.db.registrar_historial(
            self.usuario_actual,
            "ENTRADA",
            "SISTEMA",
            "Ingreso al sistema"
        )
        
        
        
        
        self.en_transicion = False

        self._configurar_estilos()

        self.contenedor = ttk.Frame(self, style="App.TFrame")
        self.contenedor.grid(row=0, column=0, sticky="nsew")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self._crear_toggle_tema()
        self._configurar_atajos()
        self._mostrar_inicio()


def main():
    app = InventarioApp()
    app.mainloop()


if __name__ == "__main__":
    main()
