"""Widgets reutilizables de Tkinter usados por la interfaz."""

import math
import tkinter as tk
from pathlib import Path
from tkinter import ttk

from config import *
from config import _mezclar_color

class RoundedButton(tk.Canvas):
    def __init__(
        self,
        parent,
        text,
        command,
        width=150,
        height=42,
        radius=18,
        bg=COLOR_BLANCO,
        fill=COLOR_CELESTE,
        hover_fill=COLOR_CELESTE_OSCURO,
        press_fill="#0369a1",
        text_fill=COLOR_BLANCO,
        border_fill=None,
        font=("Segoe UI", 10, "bold"),
        image_path=None,
        image_size=22,
    ):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.text = text
        self.command = command
        self.width_value = width
        self.height_value = height
        self.radius = radius
        self.fill = fill
        self.hover_fill = hover_fill
        self.press_fill = press_fill
        self.text_fill = text_fill
        self.border_fill = border_fill or fill
        self.font = font
        self.image_path = image_path
        self.image_size = image_size
        self.image_ref = None
        self._is_pressed = False
        self._hover = False
        self.current_fill = self.fill
        self._animacion_id = None

        self._cargar_icono()
        self._draw(self.current_fill)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
    def _cargar_icono(self):
        if not self.image_path:
            return

        ruta = Path(self.image_path)
        if not ruta.exists():
            return

        try:
            from PIL import Image, ImageTk

            imagen = Image.open(ruta)
            imagen.thumbnail((self.image_size, self.image_size))
            self.image_ref = ImageTk.PhotoImage(imagen)
        except Exception:
            try:
                foto = tk.PhotoImage(file=str(ruta))
                escala = max(
                    1,
                    math.ceil(
                        max(
                            foto.width() / self.image_size,
                            foto.height() / self.image_size,
                        )
                    ),
                )
                if escala > 1:
                    foto = foto.subsample(escala, escala)
                self.image_ref = foto
            except Exception:
                self.image_ref = None

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=18,
        )

    def _cancelar_animacion(self):
        if self._animacion_id is not None:
            self.after_cancel(self._animacion_id)
            self._animacion_id = None

    def _animar_color(self, destino, pasos=7, activo=False):
        self._cancelar_animacion()
        origen = self.current_fill

        def animar(paso=1):
            if not self.winfo_exists():
                return
            avance = paso / pasos
            self.current_fill = _mezclar_color(origen, destino, avance)
            self._draw(self.current_fill, active=activo)
            if paso < pasos:
                self._animacion_id = self.after(18, lambda: animar(paso + 1))
            else:
                self._animacion_id = None

        animar()

    def _draw(self, fill, offset=0, active=False):
        self.delete("all")
        if active:
            self._rounded_rectangle(
                2,
                4,
                self.width_value - 2,
                self.height_value - 1,
                self.radius,
                _mezclar_color(fill, COLOR_BLANCO, 0.62),
                "#9bdcff",
            )

        self._rounded_rectangle(
            1,
            1 + offset,
            self.width_value - 1,
            self.height_value - (3 if active else 1) + offset,
            self.radius,
            fill,
            "#7dd3fc" if active else self.border_fill,
        )

        if self.image_ref:
            icono_x = 24
            texto_x = self.width_value / 2 + 12
            self.create_image(
                icono_x,
                self.height_value / 2 + offset,
                image=self.image_ref,
            )
            self.create_text(
                texto_x,
                self.height_value / 2 + offset,
                text=self.text,
                fill=self.text_fill,
                font=self.font,
            )
        else:
            self.create_text(
                self.width_value / 2,
                self.height_value / 2 + offset,
                text=self.text,
                fill=self.text_fill,
                font=self.font,
            )

    def _on_enter(self, _event):
        self._hover = True
        self._animar_color(self.hover_fill, activo=True)

    def _on_leave(self, _event):
        self._is_pressed = False
        self._hover = False
        self._animar_color(self.fill, activo=False)

    def _on_press(self, _event):
        self._is_pressed = True
        self._cancelar_animacion()
        self.current_fill = self.press_fill
        self._draw(self.press_fill, offset=1, active=True)

    def _on_release(self, event):
        ejecutar = self._is_pressed and 0 <= event.x <= self.width_value and 0 <= event.y <= self.height_value
        self._is_pressed = False
        destino = self.hover_fill if ejecutar or self._hover else self.fill
        self._animar_color(destino, pasos=5, activo=ejecutar or self._hover)
        if ejecutar:
            self.command()


class ImageButton(tk.Canvas):
    def __init__(
        self,
        parent,
        image_path,
        command,
        size=54,
        bg=COLOR_BLANCO,
        fallback_text="PDF",
    ):
        super().__init__(
            parent,
            width=size,
            height=size,
            bg=bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.image_path = image_path
        self.command = command
        self.size = size
        self.fallback_text = fallback_text
        self.image_ref = None
        self._is_pressed = False
        self._hover = False

        self._cargar_imagen()
        self._draw()
        self.bind("<Enter>", self._on_enter)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<Leave>", self._on_leave)

    def _cargar_imagen(self):
        ruta = Path(self.image_path)
        if not ruta.exists():
            return

        try:
            from PIL import Image, ImageTk, ImageDraw

            imagen = Image.open(ruta).convert("RGBA")
            imagen.thumbnail((self.size - 6, self.size - 6))

            ancho, alto = imagen.size

            mascara = Image.new("L", (ancho, alto), 0)
            dibujo = ImageDraw.Draw(mascara)

            radio = 12  # mientras más alto, más redondeado
            dibujo.rounded_rectangle(
                (0, 0, ancho, alto),
                radius=radio,
                fill=255
            )

            imagen.putalpha(mascara)

            self.image_ref = ImageTk.PhotoImage(imagen)

        except Exception:
            try:
                foto = tk.PhotoImage(file=str(ruta))
                escala = max(
                    1,
                    math.ceil(
                        max(
                            foto.width() / (self.size - 4),
                            foto.height() / (self.size - 4),
                        )
                    ),
                )
                if escala > 1:
                    foto = foto.subsample(escala, escala)
                self.image_ref = foto
            except Exception:
                self.image_ref = None

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=16,
        )

    def _draw(self, offset=0, active=False):
        self.delete("all")
        if active:
            self._rounded_rectangle(
                2,
                3,
                self.size - 2,
                self.size - 2,
                15,
                COLOR_CELESTE_SUAVE,
                "#9bdcff",
            )

        if self.image_ref:
            self.create_image(
                self.size / 2,
                self.size / 2 + offset,
                image=self.image_ref,
            )
        else:
            self.create_text(
                self.size / 2,
                self.size / 2 + offset,
                text=self.fallback_text,
                fill=COLOR_CELESTE_OSCURO,
                font=("Segoe UI", 10, "bold"),
            )

    def _on_enter(self, _event):
        self._hover = True
        self._draw(offset=-1, active=True)

    def _on_press(self, _event):
        self._is_pressed = True
        self._draw(offset=1, active=True)

    def _on_leave(self, _event):
        self._is_pressed = False
        self._hover = False
        self._draw()

    def _on_release(self, event):
        ejecutar = self._is_pressed and 0 <= event.x <= self.size and 0 <= event.y <= self.size
        self._is_pressed = False
        self._draw(active=self._hover)
        if ejecutar:
            self.command()


class TrashIconButton(tk.Canvas):
    def __init__(
        self,
        parent,
        command,
        size=46,
        bg=COLOR_FONDO,
        fill=COLOR_CELESTE,
        hover_fill=COLOR_CELESTE_OSCURO,
        press_fill="#0369a1",
        icon_fill=COLOR_TEXTO_BOTON,
    ):
        super().__init__(
            parent,
            width=size,
            height=size,
            bg=bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.command = command
        self.size = size
        self.bg = bg
        self.fill = fill
        self.hover_fill = hover_fill
        self.press_fill = press_fill
        self.icon_fill = icon_fill
        self.current_fill = self.fill
        self._is_pressed = False
        self._hover = False
        self._animacion_id = None

        self._draw(self.current_fill)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=16,
        )

    def _cancelar_animacion(self):
        if self._animacion_id is not None:
            self.after_cancel(self._animacion_id)
            self._animacion_id = None

    def _animar_color(self, destino, pasos=7):
        self._cancelar_animacion()
        origen = self.current_fill

        def animar(paso=1):
            if not self.winfo_exists():
                return
            avance = paso / pasos
            self.current_fill = _mezclar_color(origen, destino, avance)
            self._draw(self.current_fill)
            if paso < pasos:
                self._animacion_id = self.after(18, lambda: animar(paso + 1))
            else:
                self._animacion_id = None

        animar()

    def _draw(self, fill, offset=0):
        self.delete("all")
        if self._hover:
            self._rounded_rectangle(
                2,
                4,
                self.size - 2,
                self.size - 1,
                14,
                _mezclar_color(fill, COLOR_BLANCO, 0.62),
                "#9bdcff",
            )
        self._rounded_rectangle(
            1,
            1,
            self.size - 1,
            self.size - 1,
            14,
            fill,
            fill,
        )

        y = offset
        self.create_line(
            16,
            17 + y,
            30,
            17 + y,
            fill=self.icon_fill,
            width=3,
            capstyle="round",
        )
        self.create_line(
            20,
            13 + y,
            26,
            13 + y,
            fill=self.icon_fill,
            width=3,
            capstyle="round",
        )
        self.create_line(
            18,
            20 + y,
            28,
            20 + y,
            27,
            34 + y,
            19,
            34 + y,
            18,
            20 + y,
            fill=self.icon_fill,
            width=3,
            capstyle="round",
            joinstyle="round",
        )
        self.create_line(21, 23 + y, 21, 31 + y, fill=self.icon_fill, width=2, capstyle="round")
        self.create_line(24, 23 + y, 24, 31 + y, fill=self.icon_fill, width=2, capstyle="round")
        self.create_line(27, 23 + y, 27, 31 + y, fill=self.icon_fill, width=2, capstyle="round")

    def actualizar_tema(self, bg=None):
        self.bg = bg or COLOR_FONDO
        self.configure(bg=self.bg)
        self.fill = COLOR_CELESTE
        self.hover_fill = COLOR_CELESTE_OSCURO
        self.icon_fill = COLOR_TEXTO_BOTON
        self.current_fill = self.hover_fill if self._hover else self.fill
        self._draw(self.current_fill)

    def _on_enter(self, _event):
        self._hover = True
        self._animar_color(self.hover_fill)

    def _on_leave(self, _event):
        self._is_pressed = False
        self._hover = False
        self._animar_color(self.fill)

    def _on_press(self, _event):
        self._is_pressed = True
        self._cancelar_animacion()
        self.current_fill = self.press_fill
        self._draw(self.press_fill, offset=1)

    def _on_release(self, event):
        ejecutar = self._is_pressed and 0 <= event.x <= self.size and 0 <= event.y <= self.size
        self._is_pressed = False
        destino = self.hover_fill if ejecutar or self._hover else self.fill
        self._animar_color(destino, pasos=5)
        if ejecutar:
            self.command()


class PencilIconButton(tk.Canvas):
    def __init__(
        self,
        parent,
        command,
        width=44,
        height=42,
        radius=13,
        bg=COLOR_BLANCO,
        fill=COLOR_CELESTE,
        hover_fill=COLOR_CELESTE_OSCURO,
        press_fill="#0369a1",
        icon_fill=COLOR_BLANCO,
    ):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=bg,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.command = command
        self.width_value = width
        self.height_value = height
        self.radius = radius
        self.fill = fill
        self.hover_fill = hover_fill
        self.press_fill = press_fill
        self.icon_fill = icon_fill
        self._is_pressed = False
        self._hover = False
        self.current_fill = self.fill
        self._animacion_id = None

        self._draw(self.current_fill)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<ButtonPress-1>", self._on_press)
        self.bind("<ButtonRelease-1>", self._on_release)

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=fill,
            smooth=True,
            splinesteps=16,
        )

    def _cancelar_animacion(self):
        if self._animacion_id is not None:
            self.after_cancel(self._animacion_id)
            self._animacion_id = None

    def _animar_color(self, destino, pasos=7):
        self._cancelar_animacion()
        origen = self.current_fill

        def animar(paso=1):
            if not self.winfo_exists():
                return
            avance = paso / pasos
            self.current_fill = _mezclar_color(origen, destino, avance)
            self._draw(self.current_fill)
            if paso < pasos:
                self._animacion_id = self.after(18, lambda: animar(paso + 1))
            else:
                self._animacion_id = None

        animar()

    def _draw(self, fill):
        self.delete("all")
        if self._hover:
            self._rounded_rectangle(
                2,
                4,
                self.width_value - 2,
                self.height_value - 1,
                self.radius,
                _mezclar_color(fill, COLOR_BLANCO, 0.62),
                "#9bdcff",
            )
        self._rounded_rectangle(
            1,
            1,
            self.width_value - 1,
            self.height_value - 1,
            self.radius,
            fill,
            fill,
        )

        self.create_polygon(
            16,
            27,
            27,
            16,
            30,
            19,
            19,
            30,
            fill=self.icon_fill,
            outline=self.icon_fill,
        )
        self.create_polygon(
            28,
            15,
            31,
            12,
            34,
            15,
            32,
            18,
            fill=self.icon_fill,
            outline=self.icon_fill,
        )
        self.create_line(
            27,
            16,
            32,
            21,
            fill=fill,
            width=1,
            capstyle="round",
        )
        self.create_line(
            26,
            17,
            30,
            21,
            fill=fill,
            width=1,
            capstyle="round",
        )
        self.create_polygon(
            13,
            34,
            16,
            27,
            19,
            30,
            fill=self.icon_fill,
            outline=self.icon_fill,
        )
        self.create_polygon(
            11,
            36,
            13,
            34,
            16,
            37,
            fill=self.icon_fill,
            outline=self.icon_fill,
        )
        self.create_polygon(
            11,
            36,
            12,
            34,
            13,
            35,
            fill=fill,
            outline=fill,
        )

    def _on_enter(self, _event):
        self._hover = True
        self._animar_color(self.hover_fill)

    def _on_leave(self, _event):
        self._is_pressed = False
        self._hover = False
        self._animar_color(self.fill)

    def _on_press(self, _event):
        self._is_pressed = True
        self._cancelar_animacion()
        self.current_fill = self.press_fill
        self._draw(self.press_fill)

    def _on_release(self, event):
        ejecutar = self._is_pressed and 0 <= event.x <= self.width_value and 0 <= event.y <= self.height_value
        self._is_pressed = False
        destino = self.hover_fill if ejecutar or self._hover else self.fill
        self._animar_color(destino, pasos=5)
        if ejecutar:
            self.command()


class RoundedCard(tk.Frame):
    def __init__(
        self,
        parent,
        bg=COLOR_FONDO,
        fill=COLOR_BLANCO,
        outline=COLOR_BORDE,
        radius=22,
        padding=18,
        min_width=0,
        min_height=0,
        fill_height=False,
    ):
        super().__init__(parent, bg=bg)
        self.bg = bg
        self.fill = fill
        self.outline = outline
        self.radius = radius
        self.padding = padding
        self.min_width = min_width
        self.min_height = min_height
        self.fill_height = fill_height

        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        if min_width or min_height:
            self.canvas.configure(width=min_width, height=min_height)

        self.contenido = tk.Frame(self.canvas, bg=fill)
        self.ventana = self.canvas.create_window(
            padding,
            padding,
            anchor="nw",
            window=self.contenido,
        )
        self.canvas.bind("<Configure>", self._dibujar)
        self.contenido.bind("<Configure>", self._actualizar_tamano)

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.canvas.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=18,
            tags="card",
        )

    def _actualizar_tamano(self, _event=None):
        ancho = max(self.min_width, self.winfo_width(), self.contenido.winfo_reqwidth() + self.padding * 2)
        alto = max(self.min_height, self.contenido.winfo_reqheight() + self.padding * 2)
        self.canvas.configure(width=ancho, height=alto)
        self.canvas.itemconfigure(self.ventana, width=max(1, ancho - self.padding * 2))
        if self.fill_height:
            self.canvas.itemconfigure(self.ventana, height=max(1, alto - self.padding * 2))
        self._dibujar()

    def _dibujar(self, _event=None):
        ancho = max(1, self.canvas.winfo_width())
        alto = max(1, self.canvas.winfo_height())
        self.canvas.itemconfigure(self.ventana, width=max(1, ancho - self.padding * 2))
        if self.fill_height:
            self.canvas.itemconfigure(self.ventana, height=max(1, alto - self.padding * 2))
        self.canvas.delete("card")
        self._rounded_rectangle(
            1,
            1,
            ancho - 2,
            alto - 2,
            self.radius,
            self.fill,
            self.outline,
        )
        self.canvas.tag_lower("card")


class ChecklistItem(tk.Canvas):
    def __init__(self, parent, text, variable, command, width=260, height=42):
        super().__init__(
            parent,
            width=width,
            height=height,
            bg=COLOR_BLANCO,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.text = text
        self.variable = variable
        self.command = command
        self.height_value = height
        self.hover = False
        self.current_fondo = COLOR_CELESTE_SUAVE if self.variable.get() else COLOR_BLANCO
        self.current_borde = "#9bdcff" if self.variable.get() else "#eef6fb"
        self._animacion_id = None
        self._pulso_id = None
        self.pulso = 0

        self.bind("<Configure>", lambda _event: self._draw())
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self.bind("<Button-1>", self._toggle)
        self._draw()

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=14,
        )

    def _colores_estado(self):
        seleccionado = self.variable.get()
        fondo = COLOR_CELESTE_SUAVE if seleccionado else (COLOR_FILA_HOVER if self.hover else COLOR_BLANCO)
        borde = "#9bdcff" if seleccionado or self.hover else "#eef6fb"
        return fondo, borde

    def _cancelar_animacion(self):
        if self._animacion_id is not None:
            self.after_cancel(self._animacion_id)
            self._animacion_id = None

    def _animar_estado(self, pasos=7):
        self._cancelar_animacion()
        fondo_inicio = self.current_fondo
        borde_inicio = self.current_borde
        fondo_fin, borde_fin = self._colores_estado()

        def animar(paso=1):
            if not self.winfo_exists():
                return
            avance = paso / pasos
            self.current_fondo = _mezclar_color(fondo_inicio, fondo_fin, avance)
            self.current_borde = _mezclar_color(borde_inicio, borde_fin, avance)
            self._draw()
            if paso < pasos:
                self._animacion_id = self.after(16, lambda: animar(paso + 1))
            else:
                self._animacion_id = None

        animar()

    def _animar_pulso(self, paso=0):
        if not self.winfo_exists():
            return
        self.pulso = paso
        self._draw()
        if paso < 5:
            self._pulso_id = self.after(28, lambda: self._animar_pulso(paso + 1))
        else:
            self.pulso = 0
            self._pulso_id = None
            self._draw()

    def _draw(self):
        self.delete("all")
        ancho = max(220, self.winfo_width())
        seleccionado = self.variable.get()
        self._rounded_rectangle(2, 3, ancho - 3, self.height_value - 3, 14, self.current_fondo, self.current_borde)

        if self.pulso:
            margen = max(1, 6 - self.pulso)
            self._rounded_rectangle(
                margen,
                margen + 1,
                ancho - margen,
                self.height_value - margen,
                16,
                "",
                "#7dd3fc",
            )

        caja_fill = COLOR_CELESTE if seleccionado else COLOR_BLANCO
        caja_outline = COLOR_CELESTE if seleccionado else "#a9bdd0"
        self._rounded_rectangle(14, 12, 32, 30, 5, caja_fill, caja_outline)
        if seleccionado:
            self.create_line(18, 21, 22, 25, 29, 16, fill=COLOR_TEXTO_BOTON, width=2, capstyle="round", joinstyle="round")

        self.create_text(
            44,
            self.height_value / 2,
            anchor="w",
            text=self.text,
            fill=COLOR_TEXTO,
            font=("Segoe UI", 10, "bold"),
        )

    def _on_enter(self, _event):
        self.hover = True
        self._animar_estado()

    def _on_leave(self, _event):
        self.hover = False
        self._animar_estado()

    def _toggle(self, _event):
        self.variable.set(not self.variable.get())
        self._animar_estado(pasos=5)
        self._animar_pulso()
        self.command()


class ScrollFrame(ttk.Frame):
    def __init__(
        self,
        parent,
        canvas_bg=COLOR_BLANCO,
        content_style="Card.TFrame",
        scrollbar_style="Vertical.TScrollbar",
        auto_hide=True,
    ):
        super().__init__(parent, style=content_style)
        self.auto_hide = auto_hide
        self.canvas = tk.Canvas(self, bg=canvas_bg, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(
            self,
            orient="vertical",
            command=self.canvas.yview,
            style=scrollbar_style,
        )
        self.contenido = ttk.Frame(self.canvas, style=content_style)

        self.ventana = self.canvas.create_window((0, 0), window=self.contenido, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=1)

        self.contenido.bind("<Configure>", self._actualizar_scroll)
        self.canvas.bind("<Configure>", self._ajustar_ancho)
        self.canvas.bind("<Enter>", self._activar_rueda)
        self.canvas.bind("<Leave>", self._desactivar_rueda)

    def _actualizar_scroll(self, _event=None):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return

        alto_contenido = bbox[3] - bbox[1]
        alto_canvas = self.canvas.winfo_height()
        if self.auto_hide and alto_canvas > 1 and alto_contenido <= alto_canvas:
            self.canvas.yview_moveto(0)
            self.canvas.configure(scrollregion=(0, 0, bbox[2], alto_canvas))
            self.scrollbar.grid_remove()
            return

        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.canvas.configure(scrollregion=bbox)

    def _ajustar_ancho(self, event):
        self.canvas.itemconfigure(self.ventana, width=event.width)
        self._actualizar_scroll()

    def _activar_rueda(self, _event=None):
        self.canvas.bind_all("<MouseWheel>", self._mover_rueda)

    def _desactivar_rueda(self, _event=None):
        self.canvas.unbind_all("<MouseWheel>")

    def _mover_rueda(self, event):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return

        alto_contenido = bbox[3] - bbox[1]
        alto_canvas = self.canvas.winfo_height()
        if alto_contenido <= alto_canvas:
            self.canvas.yview_moveto(0)
            return

        self.canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")


class HorizontalScrollFrame(ttk.Frame):
    def __init__(
        self,
        parent,
        canvas_bg=COLOR_BLANCO,
        content_style="Card.TFrame",
        scrollbar_style="Category.Horizontal.TScrollbar",
        height=58,
        auto_hide=True,
    ):
        super().__init__(parent, style=content_style)
        self.auto_hide = auto_hide
        self.canvas = tk.Canvas(self, bg=canvas_bg, height=height, highlightthickness=0)
        self.scrollbar = ttk.Scrollbar(
            self,
            orient="horizontal",
            command=self.canvas.xview,
            style=scrollbar_style,
        )
        self.contenido = ttk.Frame(self.canvas, style=content_style)
        self.ventana = self.canvas.create_window((0, 0), window=self.contenido, anchor="nw")
        self.canvas.configure(xscrollcommand=self.scrollbar.set)

        self.canvas.grid(row=0, column=0, sticky="ew")
        self.scrollbar.grid(row=1, column=0, sticky="ew", pady=(4, 0))
        self.columnconfigure(0, weight=1)

        self.contenido.bind("<Configure>", self._actualizar_scroll)
        self.canvas.bind("<Configure>", self._ajustar_alto)
        self.canvas.bind("<Enter>", self._activar_rueda)
        self.canvas.bind("<Leave>", self._desactivar_rueda)

    def _actualizar_scroll(self, _event=None):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return

        ancho_contenido = bbox[2] - bbox[0]
        ancho_canvas = self.canvas.winfo_width()
        alto = max(self.canvas.winfo_height(), bbox[3] - bbox[1])
        self.canvas.configure(scrollregion=(0, 0, bbox[2], alto))

        if self.auto_hide and ancho_canvas > 1 and ancho_contenido <= ancho_canvas:
            self.canvas.xview_moveto(0)
            self.scrollbar.grid_remove()
            return

        self.scrollbar.grid(row=1, column=0, sticky="ew", pady=(4, 0))

    def _ajustar_alto(self, event):
        self.canvas.itemconfigure(self.ventana, height=event.height)
        self._actualizar_scroll()

    def _activar_rueda(self, _event=None):
        self.canvas.bind_all("<Shift-MouseWheel>", self._mover_rueda)

    def _desactivar_rueda(self, _event=None):
        self.canvas.unbind_all("<Shift-MouseWheel>")

    def _mover_rueda(self, event):
        bbox = self.canvas.bbox("all")
        if not bbox:
            return

        ancho_contenido = bbox[2] - bbox[0]
        ancho_canvas = self.canvas.winfo_width()
        if ancho_contenido <= ancho_canvas:
            self.canvas.xview_moveto(0)
            return

        self.canvas.xview_scroll(int(-1 * (event.delta / 120)), "units")


class ThemeSwitch(tk.Canvas):
    def __init__(self, parent, command, activo=False):
        super().__init__(
            parent,
            width=118,
            height=42,
            bg=COLOR_FONDO,
            highlightthickness=0,
            bd=0,
            cursor="hand2",
        )
        self.command = command
        self.activo = activo
        self.knob_x = 88 if activo else 30
        self._animacion_id = None
        self.disabled = False
        self.bind("<Button-1>", lambda _event: self._click_handler())
        self._draw()

    def _click_handler(self):
        if not self.disabled:
            self.command()

    def set_disabled(self, disabled):
        self.disabled = disabled
        if disabled:
            self.config(cursor="arrow")
        else:
            self.config(cursor="hand2")
        self._draw()

    def _rounded_rectangle(self, x1, y1, x2, y2, radius, fill, outline):
        puntos = [
            x1 + radius, y1,
            x2 - radius, y1,
            x2, y1,
            x2, y1 + radius,
            x2, y2 - radius,
            x2, y2,
            x2 - radius, y2,
            x1 + radius, y2,
            x1, y2,
            x1, y2 - radius,
            x1, y1 + radius,
            x1, y1,
        ]
        self.create_polygon(
            puntos,
            fill=fill,
            outline=outline,
            smooth=True,
            splinesteps=18,
        )

    def _draw(self):
        self.configure(bg=COLOR_FONDO)
        self.delete("all")
        track_fill = COLOR_CELESTE if self.activo else COLOR_CELESTE_SUAVE
        track_outline = COLOR_CELESTE_OSCURO if self.activo else COLOR_BORDE
        
        # Si está deshabilitado, hacer más opaco
        if self.disabled:
            track_fill = COLOR_CELESTE_SUAVE
            track_outline = COLOR_BORDE

        self._rounded_rectangle(4, 6, 114, 38, 17, track_fill, track_outline)
        self.create_text(
            58,
            22,
            text="Oscuro" if self.activo else "Claro",
            fill=COLOR_TEXTO_BOTON if (self.activo and not self.disabled) else (COLOR_TEXTO_SUAVE if self.disabled else COLOR_CELESTE_OSCURO),
            font=("Segoe UI", 8, "bold"),
        )
        self.create_oval(
            self.knob_x - 13,
            9,
            self.knob_x + 13,
            35,
            fill=COLOR_TEXTO_BOTON,
            outline=COLOR_TEXTO_BOTON,
        )
        self.create_oval(
            self.knob_x - 5,
            17,
            self.knob_x + 5,
            27,
            fill=COLOR_CELESTE if self.activo else COLOR_CELESTE_SUAVE,
            outline=COLOR_CELESTE if self.activo else COLOR_CELESTE_SUAVE,
        )

    def set_activo(self, activo, animar=True):
        self.activo = activo
        destino = 88 if activo else 30
        if self._animacion_id is not None:
            self.after_cancel(self._animacion_id)
            self._animacion_id = None

        if not animar:
            self.knob_x = destino
            self._draw()
            return

        inicio = self.knob_x

        def mover(paso=1, pasos=8):
            avance = paso / pasos
            self.knob_x = inicio + (destino - inicio) * avance
            self._draw()
            if paso < pasos:
                self._animacion_id = self.after(16, lambda: mover(paso + 1, pasos))
            else:
                self._animacion_id = None

        mover()
