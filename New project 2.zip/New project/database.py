"""Capa de persistencia SQLite del sistema de inventario."""

import csv
import hashlib
import shutil
import sqlite3
import uuid
from datetime import datetime
from pathlib import Path

from config import APP_DIR, IMAGE_DIR

class InventarioDB:
    
    
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._crear_tablas()
        self._crear_indices()
        self._migrar_tabla_usuarios()
        self._migrar_tabla_categorias()
        self._migrar_tabla_productos()
        self._migrar_tabla_prestamos()
        self._crear_datos_iniciales()
        
        
    def _migrar_tabla_prestamos(self):
        with self.conectar() as conn:
            columnas = {
                columna[1]
                for columna in conn.execute("PRAGMA table_info(prestamos)").fetchall()
            }

            if not columnas:
                return

            if "objeto" not in columnas:
                conn.execute("ALTER TABLE prestamos ADD COLUMN objeto TEXT DEFAULT ''")

            if "cantidad" not in columnas:
                conn.execute("ALTER TABLE prestamos ADD COLUMN cantidad INTEGER DEFAULT 1")    

    def conectar(self):
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def _crear_tablas(self):
        with self.conectar() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS categorias (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL UNIQUE,
                    imagen TEXT DEFAULT '',
                    eliminado_en TEXT DEFAULT ''
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS productos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    categoria_id INTEGER NOT NULL,
                    nombre TEXT NOT NULL,
                    contenido TEXT,
                    imagen TEXT,
                    eliminado_en TEXT DEFAULT '',
                    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
                        ON DELETE CASCADE
                )
                """
            )
            
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS historial (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    usuario TEXT NOT NULL,
                    accion TEXT NOT NULL,
                    entidad TEXT NOT NULL,
                    detalle TEXT,
                    fecha TEXT NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS usuarios (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nombre TEXT NOT NULL UNIQUE,
                    cargo TEXT DEFAULT '',
                    imagen TEXT DEFAULT ''
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS prestamos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    producto_id INTEGER NOT NULL,
                    objeto TEXT NOT NULL,
                    cantidad INTEGER NOT NULL,
                    solicitante TEXT NOT NULL,
                    fecha_prestamo TEXT NOT NULL,
                    fecha_devolucion TEXT DEFAULT '',
                    fecha_registro TEXT NOT NULL,
                    FOREIGN KEY (producto_id) REFERENCES productos(id)
                        ON DELETE CASCADE
                )
                """
            )

    def _crear_indices(self):
        with self.conectar() as conn:
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_productos_categoria_id ON productos(categoria_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_prestamos_producto_id ON prestamos(producto_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_usuarios_nombre_nocase ON usuarios(nombre COLLATE NOCASE)"
            )

    def _migrar_tabla_usuarios(self):
        with self.conectar() as conn:
            columnas = {
                columna[1]
                    for columna in conn.execute("PRAGMA table_info(usuarios)").fetchall()
            }
            if not columnas:
                return
            if "cargo" not in columnas:
                conn.execute("ALTER TABLE usuarios ADD COLUMN cargo TEXT DEFAULT ''")
            if "imagen" not in columnas:
                conn.execute("ALTER TABLE usuarios ADD COLUMN imagen TEXT DEFAULT ''")
            if "password_hash" not in columnas:
                conn.execute("ALTER TABLE usuarios ADD COLUMN password_hash TEXT DEFAULT ''")
            if "password_salt" not in columnas:
                conn.execute("ALTER TABLE usuarios ADD COLUMN password_salt TEXT DEFAULT ''")

    def _migrar_tabla_categorias(self):
        with self.conectar() as conn:
            columnas = {
                columna[1]
                for columna in conn.execute("PRAGMA table_info(categorias)").fetchall()
            }
            if "imagen" not in columnas:
                conn.execute("ALTER TABLE categorias ADD COLUMN imagen TEXT DEFAULT ''")
            if "eliminado_en" not in columnas:
                conn.execute("ALTER TABLE categorias ADD COLUMN eliminado_en TEXT DEFAULT ''")

    def _migrar_tabla_productos(self):
        with self.conectar() as conn:
            columnas = {
                columna[1]
                for columna in conn.execute("PRAGMA table_info(productos)").fetchall()
            }
            if "contenido" not in columnas:
                conn.execute("ALTER TABLE productos ADD COLUMN contenido TEXT")
            if "imagen" not in columnas:
                conn.execute("ALTER TABLE productos ADD COLUMN imagen TEXT")
            if "eliminado_en" not in columnas:
                conn.execute("ALTER TABLE productos ADD COLUMN eliminado_en TEXT DEFAULT ''")
            if "descripcion" in columnas:
                conn.execute(
                    """
                    UPDATE productos
                    SET contenido = descripcion
                    WHERE (contenido IS NULL OR contenido = '')
                      AND descripcion IS NOT NULL
                    """
                )
    #ya quiero irme
    def _crear_datos_iniciales(self):
        with self.conectar() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO categorias (nombre) VALUES (?)",
                ("Suministros de oficina",),
            )
            categoria_id = conn.execute(
                "SELECT id FROM categorias WHERE nombre = ?",
                ("Suministros de oficina",),
            ).fetchone()[0]
            total = conn.execute(
                "SELECT COUNT(*) FROM productos WHERE categoria_id = ?",
                (categoria_id,),
            ).fetchone()[0]

            if total == 0:
                ejemplos = [
                    ("Casillero", "Zapatos\nCuaderno\nLapiz\nBorrador"),
                    ("Archivador", "Carpetas\nFacturas\nHojas A4\nSobres"),
                    ("Caja de utiles", "Grapadora\nClips\nCinta adhesiva\nMarcadores"),
                ]
                conn.executemany(
                    """
                    INSERT INTO productos (categoria_id, nombre, contenido, imagen)
                    VALUES (?, ?, ?, '')
                    """,
                    [(categoria_id, nombre, contenido) for nombre, contenido in ejemplos],
                )

    def obtener_categorias(self):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT id, nombre, COALESCE(imagen, '')
                FROM categorias
                WHERE TRIM(COALESCE(eliminado_en, '')) = ''
                ORDER BY nombre
                """
            ).fetchall()

    def obtener_categorias_con_totales(self):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT
                    c.id,
                    c.nombre,
                    COALESCE(c.imagen, ''),
                    (
                        SELECT COUNT(*)
                        FROM productos p
                        WHERE p.categoria_id = c.id
                          AND TRIM(COALESCE(p.eliminado_en, '')) = ''
                    ) AS total_productos,
                    (
                        SELECT COUNT(*)
                        FROM prestamos pr
                        INNER JOIN productos pp ON pp.id = pr.producto_id
                        WHERE pp.categoria_id = c.id
                          AND TRIM(COALESCE(pp.eliminado_en, '')) = ''
                          AND TRIM(COALESCE(pr.fecha_devolucion, '')) = ''
                    ) AS prestamos_pendientes
                FROM categorias c
                WHERE TRIM(COALESCE(c.eliminado_en, '')) = ''
                ORDER BY c.nombre
                """
            ).fetchall()

    def buscar_categorias_por_producto(self, texto, max_detalles=2):
        texto = (texto or "").strip()
        if not texto:
            return {}

        patron = f"%{texto}%"
        termino = texto.lower()
        coincidencias = {}
        with self.conectar() as conn:
            filas = conn.execute(
                """
                SELECT c.id, p.nombre, COALESCE(p.contenido, '')
                FROM categorias c
                INNER JOIN productos p ON p.categoria_id = c.id
                WHERE (p.nombre LIKE ? OR COALESCE(p.contenido, '') LIKE ?)
                  AND TRIM(COALESCE(c.eliminado_en, '')) = ''
                  AND TRIM(COALESCE(p.eliminado_en, '')) = ''
                ORDER BY c.nombre, p.nombre
                """,
                (patron, patron),
            ).fetchall()

        for categoria_id, nombre_mobiliario, contenido in filas:
            detalles = coincidencias.setdefault(categoria_id, [])
            if len(detalles) >= max_detalles:
                continue

            detalle = ""
            if termino in (nombre_mobiliario or "").lower():
                detalle = f"Mobiliario: {nombre_mobiliario}"
            else:
                for linea in (contenido or "").splitlines():
                    linea_limpia = linea.strip()
                    if linea_limpia and termino in linea_limpia.lower():
                        detalle = f"{nombre_mobiliario} -> {linea_limpia}"
                        break

            if not detalle:
                detalle = f"Mobiliario: {nombre_mobiliario}"

            if detalle not in detalles:
                detalles.append(detalle)

        return coincidencias

    def contar_productos_por_categoria(self, categoria_id):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT COUNT(*)
                FROM productos
                WHERE categoria_id = ?
                  AND TRIM(COALESCE(eliminado_en, '')) = ''
                """,
                (categoria_id,),
            ).fetchone()[0]
            
    def registrar_historial(self, usuario, accion, entidad, detalle=""):
        fecha = datetime.now().strftime("%d/%m/%Y %H:%M:%S")

        with self.conectar() as conn:
            conn.execute(
                """
                INSERT INTO historial (usuario, accion, entidad, detalle, fecha)
                VALUES (?, ?, ?, ?, ?)
                """,
                (usuario, accion, entidad, detalle, fecha),
            )

    def obtener_usuario_por_nombre(self, nombre):
        nombre = (nombre or "").strip()
        if not nombre:
            return None
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT id, nombre, COALESCE(cargo, ''), COALESCE(imagen, '')
                FROM usuarios
                WHERE LOWER(nombre) = LOWER(?)
                """,
                (nombre,),
            ).fetchone()
            
            
    def _generar_hash_password(self, password, salt=None):
        if salt is None:
            salt = uuid.uuid4().hex

        texto = f"{salt}{password}".encode("utf-8")
        password_hash = hashlib.sha256(texto).hexdigest()
        return password_hash, salt


    def registrar_usuario_login(self, nombre, password):
        nombre = " ".join((nombre or "").split())
        password = password or ""

        if len(nombre) < 2:
            raise ValueError("El usuario debe tener al menos 2 caracteres.")

        if len(password) < 4:
            raise ValueError("La contraseña debe tener al menos 4 caracteres.")

        existente = self.obtener_usuario_por_nombre(nombre)
        password_hash, salt = self._generar_hash_password(password)

        with self.conectar() as conn:
            if existente:
                usuario_id = existente[0]

                datos = conn.execute(
                    """
                    SELECT COALESCE(password_hash, '')
                    FROM usuarios
                    WHERE id = ?
                    """,
                    (usuario_id,),
                ).fetchone()

                if datos and datos[0]:
                    raise ValueError("Ese usuario ya existe. Inicie sesión.")

                conn.execute(
                    """
                    UPDATE usuarios
                    SET password_hash = ?, password_salt = ?
                    WHERE id = ?
                    """,
                    (password_hash, salt, usuario_id),
                )
                return self.obtener_usuario_por_nombre(nombre)

            conn.execute(
                """
                INSERT INTO usuarios (nombre, cargo, imagen, password_hash, password_salt)
                VALUES (?, '', '', ?, ?)
                """,
                (nombre, password_hash, salt),
            )

        return self.obtener_usuario_por_nombre(nombre)


    def validar_login(self, nombre, password):
        nombre = " ".join((nombre or "").split())
        password = password or ""

        if not nombre or not password:
            return None

        with self.conectar() as conn:
            usuario = conn.execute(
                """
                SELECT id, nombre, COALESCE(cargo, ''), COALESCE(imagen, ''),
                    COALESCE(password_hash, ''), COALESCE(password_salt, '')
                FROM usuarios
                WHERE LOWER(nombre) = LOWER(?)
                """,
                (nombre,),
            ).fetchone()

        if not usuario:
            return None

        usuario_id, nombre_db, cargo, imagen, password_hash_db, salt = usuario

        if not password_hash_db or not salt:
            return None

        password_hash, _salt = self._generar_hash_password(password, salt)

        if password_hash != password_hash_db:
            return None

        return usuario_id, nombre_db, cargo, imagen       

    def actualizar_password_usuario(self, usuario_id, password_actual, password_nuevo):
        password_actual = password_actual or ""
        password_nuevo = password_nuevo or ""

        if len(password_nuevo) < 4:
            raise ValueError("La nueva contraseña debe tener al menos 4 caracteres.")

        with self.conectar() as conn:
            usuario = conn.execute(
                """
                SELECT COALESCE(password_hash, ''), COALESCE(password_salt, '')
                FROM usuarios
                WHERE id = ?
                """,
                (usuario_id,),
            ).fetchone()

            if not usuario:
                raise ValueError("No se encontró el usuario.")

            password_hash_db, salt = usuario
            if password_hash_db and salt:
                password_hash_actual, _salt = self._generar_hash_password(password_actual, salt)
                if password_hash_actual != password_hash_db:
                    raise ValueError("La contraseña actual no es correcta.")

            nuevo_hash, nuevo_salt = self._generar_hash_password(password_nuevo)
            conn.execute(
                """
                UPDATE usuarios
                SET password_hash = ?, password_salt = ?
                WHERE id = ?
                """,
                (nuevo_hash, nuevo_salt, usuario_id),
            )

    def obtener_o_crear_usuario(self, nombre):
        nombre = (nombre or "").strip()
        if not nombre:
            raise ValueError("El nombre de usuario no puede estar vacio.")
        with self.conectar() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO usuarios (nombre, cargo, imagen) VALUES (?, '', '')",
                (nombre,),
            )
        return self.obtener_usuario_por_nombre(nombre)

    def actualizar_usuario(self, usuario_id, nombre, cargo, imagen):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE usuarios
                SET nombre = ?, cargo = ?, imagen = ?
                WHERE id = ?
                """,
                (nombre, cargo, imagen, usuario_id),
            )

    def obtener_historial(self):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT usuario, accion, entidad, detalle, fecha
                FROM historial
                ORDER BY id DESC
                LIMIT 100
                """
            ).fetchall()

    def obtener_respaldo_completo(self):
        with self.conectar() as conn:
            return {
                "categorias": conn.execute(
                    """
                    SELECT id, nombre, COALESCE(imagen, '')
                    FROM categorias
                    ORDER BY id
                    """
                ).fetchall(),
                "productos": conn.execute(
                    """
                    SELECT id, categoria_id, nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                    FROM productos
                    ORDER BY id
                    """
                ).fetchall(),
                "prestamos": conn.execute(
                    """
                      SELECT id, producto_id, COALESCE(objeto, ''),
                          COALESCE(cantidad, 1), solicitante, fecha_prestamo,
                          COALESCE(fecha_devolucion, ''), fecha_registro
                    FROM prestamos
                    ORDER BY id
                    """
                ).fetchall(),
                "historial": conn.execute(
                    """
                    SELECT id, usuario, accion, entidad, COALESCE(detalle, ''), fecha
                    FROM historial
                    ORDER BY id
                    """
                ).fetchall(),
                "usuarios": conn.execute(
                    """
                    SELECT id, nombre, COALESCE(cargo, ''), COALESCE(imagen, ''),
                           COALESCE(password_hash, ''), COALESCE(password_salt, '')
                    FROM usuarios
                    ORDER BY id
                    """
                ).fetchall(),
            }

    def importar_respaldo_completo(self, datos):
        with self.conectar() as conn:
            conn.execute("DELETE FROM prestamos")
            conn.execute("DELETE FROM productos")
            conn.execute("DELETE FROM categorias")
            conn.execute("DELETE FROM historial")
            conn.execute("DELETE FROM usuarios")

            conn.executemany(
                """
                INSERT INTO categorias (id, nombre, imagen)
                VALUES (?, ?, ?)
                """,
                datos.get("categorias", []),
            )
            conn.executemany(
                """
                INSERT INTO productos (id, categoria_id, nombre, contenido, imagen)
                VALUES (?, ?, ?, ?, ?)
                """,
                datos.get("productos", []),
            )
            conn.executemany(
                """
                INSERT INTO prestamos (
                    id, producto_id, objeto, cantidad,
                    solicitante, fecha_prestamo, fecha_devolucion, fecha_registro
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                datos.get("prestamos", []),
            )
            conn.executemany(
                """
                INSERT INTO historial (id, usuario, accion, entidad, detalle, fecha)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                datos.get("historial", []),
            )
            conn.executemany(
                """
                INSERT INTO usuarios (
                    id, nombre, cargo, imagen, password_hash, password_salt
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                datos.get("usuarios", []),
            )

    def registrar_prestamo(self, producto_id, objeto, cantidad, solicitante, fecha_prestamo, fecha_devolucion=""):
        fecha_registro = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        with self.conectar() as conn:
            conn.execute(
                """
                INSERT INTO prestamos (
                    producto_id,
                    objeto,
                    cantidad,
                    solicitante,
                    fecha_prestamo,
                    fecha_devolucion,
                    fecha_registro
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    producto_id,
                    objeto,
                    cantidad,
                    solicitante,
                    fecha_prestamo,
                    fecha_devolucion,
                    fecha_registro,
                ),
            )

    def descontar_item_contenido(self, producto_id, objeto, cantidad_prestada):
        objeto = (objeto or "").strip()
        cantidad_prestada = int(cantidad_prestada)

        if cantidad_prestada <= 0:
            raise ValueError("La cantidad debe ser mayor a cero.")

        with self.conectar() as conn:
            fila = conn.execute(
                """
                SELECT COALESCE(contenido, '')
                FROM productos
                WHERE id = ?
                """,
                (producto_id,),
            ).fetchone()

            if not fila:
                raise ValueError("No se encontró el mobiliario.")

            contenido = fila[0]
            nuevas_lineas = []
            encontrado = False
            restante_final = 0

            for linea in contenido.splitlines():
                texto = linea.strip()
                if not texto:
                    continue

                descripcion = texto
                cantidad = 1

                if "|" in texto:
                    posible_descripcion, posible_cantidad = texto.rsplit("|", 1)
                    posible_descripcion = posible_descripcion.strip()
                    posible_cantidad = posible_cantidad.strip()

                    if posible_descripcion and posible_cantidad.isdigit():
                        descripcion = posible_descripcion
                        cantidad = int(posible_cantidad)

                if descripcion.strip().lower() == objeto.lower():
                    encontrado = True

                    if cantidad_prestada > cantidad:
                        raise ValueError(
                            f"No hay suficiente cantidad. Disponible: {cantidad}."
                        )

                    restante_final = cantidad - cantidad_prestada

                    if restante_final > 0:
                        nuevas_lineas.append(f"{descripcion} | {restante_final}")
                else:
                    nuevas_lineas.append(f"{descripcion} | {cantidad}")

            if not encontrado:
                raise ValueError("No se encontró ese objeto en el contenido.")

            conn.execute(
                """
                UPDATE productos
                SET contenido = ?
                WHERE id = ?
                """,
                ("\n".join(nuevas_lineas), producto_id),
            )

            return restante_final
    
    def actualizar_devolucion_prestamo(self, prestamo_id, fecha_devolucion):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE prestamos
                SET fecha_devolucion = ?
                WHERE id = ?
                """,
                (fecha_devolucion, prestamo_id),
            )
            
    def devolver_item_contenido(self, producto_id, objeto, cantidad_devuelta):
        objeto = (objeto or "").strip()
        cantidad_devuelta = int(cantidad_devuelta)

        if cantidad_devuelta <= 0:
            raise ValueError("Cantidad inválida.")

        with self.conectar() as conn:
            fila = conn.execute(
                "SELECT COALESCE(contenido, '') FROM productos WHERE id = ?",
                (producto_id,),
            ).fetchone()

            if not fila:
                raise ValueError("Producto no encontrado.")

            contenido = fila[0]
            nuevas_lineas = []
            encontrado = False

            for linea in contenido.splitlines():
                texto = linea.strip()
                if not texto:
                    continue

                descripcion = texto
                cantidad = 1

                if "|" in texto:
                    desc, cant = texto.rsplit("|", 1)
                    desc = desc.strip()
                    cant = cant.strip()

                    if cant.isdigit():
                        descripcion = desc
                        cantidad = int(cant)

                if descripcion.lower() == objeto.lower():
                    encontrado = True
                    nueva_cantidad = cantidad + cantidad_devuelta
                    nuevas_lineas.append(f"{descripcion} | {nueva_cantidad}")
                else:
                    nuevas_lineas.append(f"{descripcion} | {cantidad}")

            if not encontrado:
                # si no existía, lo agrega
                nuevas_lineas.append(f"{objeto} | {cantidad_devuelta}")

            conn.execute(
                "UPDATE productos SET contenido = ? WHERE id = ?",
                ("\n".join(nuevas_lineas), producto_id),
            )        
            
            
            
    def obtener_prestamo(self, prestamo_id):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT producto_id, objeto, cantidad
                FROM prestamos
                WHERE id = ?
                """,
                (prestamo_id,),
            ).fetchone()

    def obtener_prestamos_categoria(self, categoria_id, limite=300):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT
                    pr.id,
                    COALESCE(p.nombre, ''),
                    COALESCE(pr.objeto, ''),
                    COALESCE(pr.cantidad, 1),
                    COALESCE(pr.solicitante, ''),
                    COALESCE(pr.fecha_prestamo, ''),
                    COALESCE(pr.fecha_devolucion, ''),
                    COALESCE(pr.fecha_registro, '')
                FROM prestamos pr
                INNER JOIN productos p ON p.id = pr.producto_id
                WHERE p.categoria_id = ?
                  AND TRIM(COALESCE(p.eliminado_en, '')) = ''
                ORDER BY pr.id DESC
                LIMIT ?
                """,
                (categoria_id, limite),
            ).fetchall()
            


    def obtener_todo_inventario(self):
        with self.conectar() as conn:
            categorias = conn.execute(
                """
                SELECT id, nombre
                FROM categorias
                WHERE TRIM(COALESCE(eliminado_en, '')) = ''
                ORDER BY nombre
                """
            ).fetchall()

            resultado = []
            for categoria_id, categoria_nombre in categorias:
                productos = conn.execute(
                    """
                    SELECT nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                    FROM productos
                    WHERE categoria_id = ?
                      AND TRIM(COALESCE(eliminado_en, '')) = ''
                    ORDER BY nombre
                    """,
                    (categoria_id,),
                ).fetchall()

                resultado.append((categoria_nombre, productos))

            return resultado

    def obtener_productos_categoria_pdf(self, categoria_id):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                FROM productos
                WHERE categoria_id = ?
                  AND TRIM(COALESCE(eliminado_en, '')) = ''
                ORDER BY nombre
                """,
                (categoria_id,),
            ).fetchall()

    def obtener_inventario_csv(self, categoria_id=None):
        filtros = []
        parametros = []
        filtros.append("TRIM(COALESCE(c.eliminado_en, '')) = ''")
        if categoria_id is not None:
            filtros.append("c.id = ?")
            parametros.append(categoria_id)

        where = f"WHERE {' AND '.join(filtros)}" if filtros else ""
        with self.conectar() as conn:
            return conn.execute(
                f"""
                SELECT
                    c.nombre,
                    COALESCE(c.imagen, ''),
                    COALESCE(p.nombre, ''),
                    COALESCE(p.contenido, ''),
                    COALESCE(p.imagen, '')
                FROM categorias c
                LEFT JOIN productos p
                    ON p.categoria_id = c.id
                   AND TRIM(COALESCE(p.eliminado_en, '')) = ''
                {where}
                ORDER BY c.nombre, p.nombre
                """,
                parametros,
            ).fetchall()

    def agregar_categoria(self, nombre, imagen=""):
        with self.conectar() as conn:
            cursor = conn.execute(
                "INSERT INTO categorias (nombre, imagen) VALUES (?, ?)",
                (nombre, imagen or ""),
            )
            return cursor.lastrowid

    def actualizar_categoria(self, categoria_id, nombre, imagen=""):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE categorias
                SET nombre = ?, imagen = ?
                WHERE id = ?
                """,
                (nombre, imagen or "", categoria_id),
            )

    def eliminar_categoria(self, categoria_id):
        fecha = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE categorias
                SET eliminado_en = ?
                WHERE id = ?
                """,
                (fecha, categoria_id),
            )

    def eliminar_categoria_definitivo(self, categoria_id):
        with self.conectar() as conn:
            conn.execute("DELETE FROM categorias WHERE id = ?", (categoria_id,))

    def restaurar_categoria(self, categoria_id):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE categorias
                SET eliminado_en = ''
                WHERE id = ?
                """,
                (categoria_id,),
            )

    def buscar_productos(self, categoria_id, texto=""):
        patron = f"%{texto.strip()}%"
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT id, nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                FROM productos
                WHERE categoria_id = ?
                  AND (nombre LIKE ? OR contenido LIKE ?)
                  AND TRIM(COALESCE(eliminado_en, '')) = ''
                ORDER BY nombre
                """,
                (categoria_id, patron, patron),
            ).fetchall()

    def obtener_producto(self, producto_id):
        with self.conectar() as conn:
            return conn.execute(
                """
                SELECT id, categoria_id, nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                FROM productos
                WHERE id = ?
                  AND TRIM(COALESCE(eliminado_en, '')) = ''
                """,
                (producto_id,),
            ).fetchone()
    def obtener_productos_por_ids(self, producto_ids):
        ids = list(producto_ids)
        if not ids:
            return []

        marcadores = ",".join("?" for _id in ids)
        with self.conectar() as conn:
            return conn.execute(
                f"""
                SELECT id, categoria_id, nombre, COALESCE(contenido, ''), COALESCE(imagen, '')
                FROM productos
                WHERE id IN ({marcadores})
                  AND TRIM(COALESCE(eliminado_en, '')) = ''
                ORDER BY nombre
                """,
                ids,
            ).fetchall()

    def agregar_producto(self, categoria_id, datos):
        with self.conectar() as conn:
            cursor = conn.execute(
                """
                INSERT INTO productos (categoria_id, nombre, contenido, imagen)
                VALUES (?, ?, ?, ?)
                """,
                (categoria_id, datos["nombre"], datos["contenido"], datos["imagen"]),
            )
            return cursor.lastrowid

    def actualizar_producto(self, producto_id, datos):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE productos
                SET nombre = ?, contenido = ?, imagen = ?
                WHERE id = ?
                """,
                (datos["nombre"], datos["contenido"], datos["imagen"], producto_id),
            )

    def eliminar_productos(self, producto_ids):
        ids = list(producto_ids)
        if not ids:
            return

        marcadores = ",".join("?" for _id in ids)
        fecha = datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        with self.conectar() as conn:
            conn.execute(
                f"""
                UPDATE productos
                SET eliminado_en = ?
                WHERE id IN ({marcadores})
                """,
                [fecha] + ids,
            )

    def eliminar_productos_definitivo(self, producto_ids):
        ids = list(producto_ids)
        if not ids:
            return

        marcadores = ",".join("?" for _id in ids)
        with self.conectar() as conn:
            conn.execute(
                f"DELETE FROM productos WHERE id IN ({marcadores})",
                ids,
            )

    def restaurar_producto(self, producto_id):
        with self.conectar() as conn:
            conn.execute(
                """
                UPDATE productos
                SET eliminado_en = ''
                WHERE id = ?
                """,
                (producto_id,),
            )
            conn.execute(
                """
                UPDATE categorias
                SET eliminado_en = ''
                WHERE id = (
                    SELECT categoria_id
                    FROM productos
                    WHERE id = ?
                )
                """,
                (producto_id,),
            )

    def obtener_papelera(self):
        with self.conectar() as conn:
            categorias = conn.execute(
                """
                SELECT
                    c.id,
                    c.nombre,
                    COALESCE(c.eliminado_en, ''),
                    (
                        SELECT COUNT(*)
                        FROM productos p
                        WHERE p.categoria_id = c.id
                    ) AS total_productos
                FROM categorias c
                WHERE TRIM(COALESCE(c.eliminado_en, '')) <> ''
                ORDER BY c.eliminado_en DESC
                """
            ).fetchall()
            productos = conn.execute(
                """
                SELECT
                    p.id,
                    p.nombre,
                    COALESCE(c.nombre, ''),
                    COALESCE(p.eliminado_en, '')
                FROM productos p
                LEFT JOIN categorias c ON c.id = p.categoria_id
                WHERE TRIM(COALESCE(p.eliminado_en, '')) <> ''
                ORDER BY p.eliminado_en DESC
                """
            ).fetchall()
            return categorias, productos

    def obtener_o_crear_categoria(self, nombre):
        nombre = nombre.strip()
        if not nombre:
            raise ValueError("El nombre de la categoria no puede estar vacio.")

        with self.conectar() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO categorias (nombre) VALUES (?)",
                (nombre,),
            )
            return conn.execute(
                "SELECT id FROM categorias WHERE nombre = ?",
                (nombre,),
            ).fetchone()[0]

    def _preparar_imagen_importada(self, valor, carpeta_csv):
        valor = (valor or "").strip()
        if not valor:
            return ""

        ruta_original = Path(valor)
        posibles_rutas = []
        if ruta_original.is_absolute():
            posibles_rutas.append(ruta_original)
        else:
            posibles_rutas.append(carpeta_csv / ruta_original)
            posibles_rutas.append(APP_DIR / ruta_original)

        origen = next((ruta for ruta in posibles_rutas if ruta.exists() and ruta.is_file()), None)
        if origen is None:
            return valor

        try:
            return str(origen.resolve().relative_to(APP_DIR.resolve()))
        except ValueError:
            pass

        IMAGE_DIR.mkdir(exist_ok=True)
        destino = IMAGE_DIR / f"{uuid.uuid4().hex}{origen.suffix.lower()}"
        shutil.copy2(origen, destino)
        return str(destino.relative_to(APP_DIR))

    def importar_productos_csv(self, ruta_csv, categoria_por_defecto=None):
        insertados = 0
        actualizados = 0
        omitidos = 0
        carpeta_csv = Path(ruta_csv).resolve().parent

        with open(ruta_csv, "r", encoding="utf-8-sig", newline="") as archivo:
            lector = csv.DictReader(archivo)
            if not lector.fieldnames:
                raise ValueError("El archivo CSV no tiene encabezados.")

            encabezados = {nombre.strip().lower(): nombre for nombre in lector.fieldnames}
            campo_categoria = encabezados.get("categoria") or encabezados.get("categoría")
            campo_nombre = encabezados.get("nombre") or encabezados.get("opcion") or encabezados.get("opción")
            campo_contenido = encabezados.get("contenido") or encabezados.get("items") or encabezados.get("lista")
            campo_imagen = encabezados.get("imagen")
            campo_categoria_imagen = (
                encabezados.get("categoria_imagen")
                or encabezados.get("imagen_categoria")
                or encabezados.get("categoría_imagen")
            )

            if not campo_nombre or not campo_contenido:
                raise ValueError(
                    "El CSV debe tener al menos las columnas: nombre y contenido. "
                    "Opcionalmente puede incluir categoria, categoria_imagen e imagen."
                )

            with self.conectar() as conn:
                for fila in lector:
                    nombre = (fila.get(campo_nombre) or "").strip()
                    contenido = (fila.get(campo_contenido) or "").strip()
                    imagen = (
                        self._preparar_imagen_importada(fila.get(campo_imagen), carpeta_csv)
                        if campo_imagen
                        else ""
                    )
                    categoria_imagen = (
                        self._preparar_imagen_importada(fila.get(campo_categoria_imagen), carpeta_csv)
                        if campo_categoria_imagen
                        else ""
                    )

                    if campo_categoria:
                        categoria_nombre = (fila.get(campo_categoria) or "").strip()
                    else:
                        categoria_nombre = categoria_por_defecto or ""

                    if not categoria_nombre:
                        omitidos += 1
                        continue

                    conn.execute(
                        "INSERT OR IGNORE INTO categorias (nombre) VALUES (?)",
                        (categoria_nombre,),
                    )
                    categoria_id = conn.execute(
                        "SELECT id FROM categorias WHERE nombre = ?",
                        (categoria_nombre,),
                    ).fetchone()[0]

                    if categoria_imagen:
                        conn.execute(
                            """
                            UPDATE categorias
                            SET imagen = ?
                            WHERE id = ?
                            """,
                            (categoria_imagen, categoria_id),
                        )

                    if not nombre:
                        omitidos += 1
                        continue

                    existente = conn.execute(
                        """
                        SELECT id FROM productos
                        WHERE categoria_id = ? AND LOWER(nombre) = LOWER(?)
                        """,
                        (categoria_id, nombre),
                    ).fetchone()

                    if existente:
                        conn.execute(
                            """
                            UPDATE productos
                            SET contenido = ?, imagen = ?
                            WHERE id = ?
                            """,
                            (contenido, imagen, existente[0]),
                        )
                        actualizados += 1
                    else:
                        conn.execute(
                            """
                            INSERT INTO productos (categoria_id, nombre, contenido, imagen)
                            VALUES (?, ?, ?, ?)
                            """,
                            (categoria_id, nombre, contenido, imagen),
                        )
                        insertados += 1

        return insertados, actualizados, omitidos
