"""Funciones centrales: tema, atajos, estilos y fabricas de controles."""

import csv
import io
import math
import shutil
import sqlite3
import time
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppCoreMixin:
    def _crear_toggle_tema(self):
        self.theme_switch = ThemeSwitch(
            self,
            command=self._alternar_tema,
            activo=self.tema_actual == "oscuro",
        )
        self._crear_boton_papelera()
        self._reposicionar_toggle_tema()

    def _crear_boton_papelera(self):
        if self.papelera_boton:
            try:
                self.papelera_boton.destroy()
            except tk.TclError:
                pass
        self.papelera_boton = TrashIconButton(
            self,
            command=self._ver_papelera,
            size=46,
            bg=COLOR_FONDO,
        )

    def _reposicionar_toggle_tema(self):
        if not self.theme_switch:
            return
        if self.papelera_boton:
            if hasattr(self.papelera_boton, "actualizar_tema"):
                self.papelera_boton.actualizar_tema(bg=COLOR_FONDO)
            self.papelera_boton.place(relx=1.0, rely=1.0, x=-148, y=-18, anchor="se")
            self.tk.call("raise", self.papelera_boton._w)
        self.theme_switch.place(relx=1.0, rely=1.0, x=-18, y=-18, anchor="se")
        self.tk.call("raise", self.theme_switch._w)

    def _configurar_atajos(self):
        for secuencia in ("<Control-n>", "<Control-N>"):
            self.bind(secuencia, self._atajo_agregar_opcion)
        for secuencia in ("<Control-s>", "<Control-S>"):
            self.bind(secuencia, self._atajo_guardar)
        self.bind("<Escape>", self._atajo_escape)

    def _vincular_atajos_ventana(self, ventana, guardar=None, cerrar=None):
        if guardar:
            def ejecutar_guardar(_event=None):
                guardar()
                return "break"

            for secuencia in ("<Control-s>", "<Control-S>"):
                ventana.bind(secuencia, ejecutar_guardar)

        if cerrar:
            def ejecutar_cerrar(_event=None):
                cerrar()
                return "break"

            ventana.bind("<Escape>", ejecutar_cerrar)

    def _evento_en_ventana_principal(self, event):
        if event is None:
            return True
        try:
            return event.widget.winfo_toplevel() == self
        except tk.TclError:
            return False

    def _atajo_agregar_opcion(self, event=None):
        if not self._evento_en_ventana_principal(event):
            return None
        if self.vista_actual != "inventario" or not self.categoria_actual_id:
            return None

        self._nuevo_producto()
        return "break"

    def _atajo_guardar(self, event=None):
        if not self._evento_en_ventana_principal(event):
            return None
        if self.vista_actual != "inventario" or not self.categoria_actual_id:
            return None
        if not hasattr(self, "nombre_var"):
            return None

        self._guardar_producto()
        return "break"

    def _atajo_escape(self, event=None):
        if not self._evento_en_ventana_principal(event):
            return None
        if self.vista_actual == "inventario":
            self.transicion(self._mostrar_inicio, "derecha")
            return "break"
        return None

    def _historial_abierto(self):
        try:
            return self.historial_ventana is not None and self.historial_ventana.winfo_exists()
        except tk.TclError:
            return False

    def _obtener_estado_historial(self):
        if not self.historial_vars:
            return dict(self.historial_estado)
        return {
            "busqueda": self.historial_vars.get("busqueda", tk.StringVar()).get(),
            "usuario": self.historial_vars.get("usuario", tk.StringVar(value="Todos")).get(),
            "accion": self.historial_vars.get("accion", tk.StringVar(value="Todas")).get(),
            "fecha": self.historial_vars.get("fecha", tk.StringVar()).get(),
        }

    def _alternar_tema(self):
        historial_estado = None
        historial_geometry = None
        if self._historial_abierto():
            historial_estado = self._obtener_estado_historial()
            historial_geometry = self.historial_ventana.geometry()
            self.historial_ventana.destroy()
            self.historial_ventana = None
            self.historial_vars = {}

        self.tema_actual = "oscuro" if self.tema_actual == "claro" else "claro"
        _aplicar_paleta_visual(self.tema_actual)
        self.configure(bg=COLOR_FONDO)
        self._configurar_estilos()

        if self.theme_switch:
            self.theme_switch.set_activo(self.tema_actual == "oscuro")

        if self.vista_actual == "inventario" and self.categoria_actual_id:
            self._mostrar_inventario()
            self._cargar_productos()
        else:
            self._mostrar_inicio()

        self._reposicionar_toggle_tema()

        if historial_estado is not None:
            self._ver_historial(estado=historial_estado, geometry=historial_geometry)

    def _deshabilitar_tema(self):
        """Deshabilita el botón de cambio de tema cuando hay ventanas modales abiertas."""
        self.ventanas_modales_abiertas += 1
        if self.theme_switch and self.ventanas_modales_abiertas > 0:
            self.theme_switch.set_disabled(True)

    def _habilitar_tema(self):
        """Habilita el botón de cambio de tema cuando no hay ventanas modales abiertas."""
        self.ventanas_modales_abiertas = max(0, self.ventanas_modales_abiertas - 1)
        if self.theme_switch and self.ventanas_modales_abiertas == 0:
            self.theme_switch.set_disabled(False)

    def _cargar_logo(self, max_ancho=1180, max_alto=1180):
        if not LOGO_PATH.exists():
            return None

        try:
            from PIL import Image, ImageTk

            imagen = Image.open(LOGO_PATH)
            imagen.thumbnail((max_ancho, max_alto))
            self.logo_ref = ImageTk.PhotoImage(imagen)
            return self.logo_ref
        except Exception:
            try:
                foto = tk.PhotoImage(file=str(LOGO_PATH))
                escala = max(1, math.ceil(max(foto.width() / max_ancho, foto.height() / max_alto)))
                if escala > 1:
                    foto = foto.subsample(escala, escala)
                self.logo_ref = foto
                return self.logo_ref
            except Exception:
                return None

    def _poner_logo(self, parent, bg=COLOR_FONDO, max_ancho=1180, max_alto=1180):
        logo = self._cargar_logo(max_ancho, max_alto)
        if not logo:
            return None

        label = tk.Label(
            parent,
            image=logo,
            bg=bg,
            borderwidth=0,
            highlightthickness=0,
        )
        label.image = logo
        return label

    def _animar_entrada(self, widget, pasos=12, distancia=18, delay=12):
        widget.update_idletasks()

        info = widget.grid_info()
        if not info:
            return

        pady_original = info.get("pady", 0)

        if isinstance(pady_original, tuple):
            pady_top, pady_bottom = pady_original
        else:
            pady_top = pady_bottom = int(pady_original)

        def animar(paso=0):
            if paso > pasos:
                widget.grid_configure(pady=(pady_top, pady_bottom))
                return

            avance = paso / pasos
            desplazamiento = int(distancia * (1 - avance))

            widget.grid_configure(pady=(pady_top + desplazamiento, pady_bottom))
            widget.after(delay, lambda: animar(paso + 1))

        animar()

    def transicion(self, accion, direccion="izquierda"):
        if self.en_transicion:
            return

        self.en_transicion = True
        self.update_idletasks()

        ancho = max(1, self.winfo_width())
        alto = max(1, self.winfo_height())

        overlay = tk.Frame(self, bg=COLOR_FONDO)
        entrada_desde_derecha = direccion == "izquierda"
        x_entrada = ancho if entrada_desde_derecha else -ancho
        x_salida = -ancho if entrada_desde_derecha else ancho
        ultimo_x = {"valor": None}

        overlay.place(x=x_entrada, y=0, width=ancho, height=alto)
        overlay.lift()

        def ease_out_cubic(progreso):
            return 1 - pow(1 - progreso, 3)

        def mover(desde, hasta, duracion_ms, terminado):
            inicio = time.perf_counter()

            def frame():
                try:
                    if not overlay.winfo_exists():
                        self.en_transicion = False
                        return
                except tk.TclError:
                    self.en_transicion = False
                    return

                transcurrido = (time.perf_counter() - inicio) * 1000
                progreso = min(1.0, transcurrido / duracion_ms)
                x = int(desde + (hasta - desde) * ease_out_cubic(progreso))

                if x != ultimo_x["valor"]:
                    overlay.place_configure(x=x)
                    ultimo_x["valor"] = x

                if progreso >= 1.0:
                    terminado()
                    return

                self.after(16, frame)

            frame()

        def cambiar():
            try:
                overlay.place_configure(x=0)
                accion()
                overlay.lift()
                self.after_idle(lambda: mover(0, x_salida, 130, finalizar))
            except Exception:
                self.en_transicion = False
                try:
                    overlay.destroy()
                finally:
                    raise

        def finalizar():
            try:
                overlay.destroy()
            finally:
                self.en_transicion = False

        def cubrir():
            try:
                if overlay.winfo_exists():
                    self.after_idle(cambiar)
            except tk.TclError:
                self.en_transicion = False
                return

        mover(x_entrada, 0, 150, cubrir)

    def _configurar_estilos(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        self.option_add("*Font", ("Segoe UI", 10))

        style.configure("App.TFrame", background=COLOR_FONDO)
        style.configure("Card.TFrame", background=COLOR_BLANCO, relief="flat", borderwidth=0)
        style.configure("Soft.TFrame", background=COLOR_CELESTE_SUAVE)
        style.configure("Header.TFrame", background=COLOR_CELESTE)

        style.configure("TLabel", background=COLOR_FONDO, foreground=COLOR_TEXTO, font=("Segoe UI", 10))
        style.configure("Title.TLabel", background=COLOR_FONDO, foreground=COLOR_TEXTO, font=("Segoe UI", 25, "bold"))
        style.configure("HeaderTitle.TLabel", background=COLOR_CELESTE, foreground=COLOR_TEXTO_BOTON, font=("Segoe UI", 18, "bold"))
        style.configure("CardTitle.TLabel", background=COLOR_BLANCO, foreground=COLOR_TEXTO, font=("Segoe UI", 14, "bold"))
        style.configure("Card.TLabel", background=COLOR_BLANCO, foreground=COLOR_TEXTO, font=("Segoe UI", 10, "bold"))
        style.configure("Muted.TLabel", background=COLOR_BLANCO, foreground=COLOR_TEXTO_SUAVE, font=("Segoe UI", 9))
        style.configure("Soft.TLabel", background=COLOR_CELESTE_SUAVE, foreground=COLOR_TEXTO, font=("Segoe UI", 10))
        style.configure("SoftTitle.TLabel", background=COLOR_CELESTE_SUAVE, foreground=COLOR_TEXTO, font=("Segoe UI", 12, "bold"))
        style.configure("ImageTitle.TLabel", background=COLOR_INPUT, foreground=COLOR_TEXTO, font=("Segoe UI", 12, "bold"))
        style.configure("Gallery.TFrame", background=COLOR_INPUT)
        style.configure("Gallery.TLabel", background=COLOR_INPUT, foreground=COLOR_TEXTO, font=("Segoe UI", 10, "bold"))
        style.configure("GalleryMuted.TLabel", background=COLOR_INPUT, foreground=COLOR_TEXTO_SUAVE, font=("Segoe UI", 9))

        style.configure(
            "TEntry",
            padding=8,
            fieldbackground=COLOR_INPUT,
            foreground=COLOR_TEXTO,
            bordercolor=COLOR_BORDE,
            lightcolor=COLOR_BORDE,
            darkcolor=COLOR_BORDE,
        )
        style.configure(
            "TCombobox",
            padding=6,
            fieldbackground=COLOR_INPUT,
            background=COLOR_INPUT,
            foreground=COLOR_TEXTO,
            bordercolor=COLOR_BORDE,
            lightcolor=COLOR_BORDE,
            darkcolor=COLOR_BORDE,
            arrowcolor=COLOR_CELESTE,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", COLOR_INPUT)],
            foreground=[("readonly", COLOR_TEXTO)],
            selectbackground=[("readonly", COLOR_INPUT)],
            selectforeground=[("readonly", COLOR_TEXTO)],
        )
        style.configure(
            "TSpinbox",
            padding=6,
            fieldbackground=COLOR_INPUT,
            foreground=COLOR_TEXTO,
            bordercolor=COLOR_BORDE,
            lightcolor=COLOR_BORDE,
            darkcolor=COLOR_BORDE,
        )
        style.configure(
            "Vertical.TScrollbar",
            gripcount=0,
            background=COLOR_CELESTE_SUAVE,
            darkcolor=COLOR_CELESTE_SUAVE,
            lightcolor=COLOR_CELESTE_SUAVE,
            troughcolor=COLOR_BLANCO,
            bordercolor=COLOR_BLANCO,
            arrowcolor=COLOR_CELESTE,
        )
        style.configure(
            "Category.Vertical.TScrollbar",
            gripcount=0,
            width=12,
            background="#9bdcff",
            darkcolor="#9bdcff",
            lightcolor="#9bdcff",
            troughcolor=COLOR_FONDO,
            bordercolor=COLOR_FONDO,
            arrowcolor=COLOR_CELESTE_OSCURO,
            relief="flat",
        )
        style.configure(
            "Category.Horizontal.TScrollbar",
            gripcount=0,
            width=12,
            background="#9bdcff",
            darkcolor="#9bdcff",
            lightcolor="#9bdcff",
            troughcolor=COLOR_FONDO,
            bordercolor=COLOR_FONDO,
            arrowcolor=COLOR_CELESTE_OSCURO,
            relief="flat",
        )
        style.configure(
            "History.Treeview",
            background=COLOR_BLANCO,
            fieldbackground=COLOR_BLANCO,
            foreground=COLOR_TEXTO,
            rowheight=32,
            borderwidth=0,
            font=("Segoe UI", 9),
        )
        style.configure(
            "History.Treeview.Heading",
            background=COLOR_CELESTE_SUAVE,
            foreground=COLOR_TEXTO,
            font=("Segoe UI", 9, "bold"),
            relief="flat",
            padding=(8, 8),
        )
        style.map(
            "History.Treeview",
            background=[("selected", COLOR_CELESTE)],
            foreground=[("selected", COLOR_TEXTO_BOTON)],
        )

    def _crear_boton(self, parent, text, command, variant="primary", width=150, height=42, bg=None, image_path=None, image_size=22):
        bg = bg or COLOR_BLANCO
        temas = {
            "primary": {
                "fill": COLOR_CELESTE,
                "hover": COLOR_CELESTE_OSCURO,
                "press": "#0369a1",
                "text": COLOR_TEXTO_BOTON,
                "border": COLOR_CELESTE,
            },
            "secondary": {
                "fill": COLOR_CELESTE_SUAVE,
                "hover": "#c7ecff",
                "press": "#b5e4fb",
                "text": COLOR_CELESTE_OSCURO,
                "border": "#b8e5fb",
            },
            "danger": {
                "fill": COLOR_ROJO,
                "hover": COLOR_ROJO_OSCURO,
                "press": "#b91c1c",
                "text": COLOR_TEXTO_BOTON,
                "border": COLOR_ROJO,
            },
            "light": {
                "fill": COLOR_ROJO,
                "hover": COLOR_ROJO_OSCURO,
                "press": "#b91c1c",
                "text": COLOR_TEXTO_BOTON,
                "border": COLOR_ROJO,
            },
        }
        tema = temas[variant]
        return RoundedButton(
            parent,
            text=text,
            command=command,
            width=width,
            height=height,
            bg=bg,
            fill=tema["fill"],
            hover_fill=tema["hover"],
            press_fill=tema["press"],
            text_fill=tema["text"],
            border_fill=tema["border"],
            image_path=image_path,
            image_size=image_size,
        )

    def _crear_boton_imagen(self, parent, image_path, command, size=54, bg=None, fallback_text="PDF"):
        bg = bg or COLOR_BLANCO
        return ImageButton(
            parent,
            image_path=image_path,
            command=command,
            size=size,
            bg=bg,
            fallback_text=fallback_text,
        )

    def _crear_boton_lapiz(self, parent, command, bg=None):
        bg = bg or COLOR_BLANCO
        return PencilIconButton(
            parent,
            command=command,
            width=44,
            height=42,
            radius=13,
            bg=bg,
            fill=COLOR_CELESTE,
            hover_fill=COLOR_CELESTE_OSCURO,
            press_fill="#0369a1",
            icon_fill=COLOR_TEXTO_BOTON,
        )

    def _cargar_avatar_circular_desde_ruta(self, ruta, size=74):
        if not ruta or not ruta.exists():
            return None

        try:
            from PIL import Image, ImageDraw, ImageOps, ImageTk

            imagen = Image.open(ruta).convert("RGBA")
            imagen = ImageOps.fit(imagen, (size, size), method=Image.LANCZOS)

            mascara = Image.new("L", (size, size), 0)
            dibujo = ImageDraw.Draw(mascara)
            dibujo.ellipse((0, 0, size - 1, size - 1), fill=255)
            imagen.putalpha(mascara)

            return ImageTk.PhotoImage(imagen)
        except Exception:
            return None

    def _cargar_avatar_usuario(self, size=74):
        ruta = self._resolver_ruta_imagen(self.usuario_imagen)
        if not ruta or not ruta.exists():
            self.usuario_avatar_ref = None
            return None

        avatar = self._cargar_avatar_circular_desde_ruta(ruta, size=size)
        if avatar is not None:
            self.usuario_avatar_ref = avatar
            return avatar

        try:
            avatar = self._cargar_preview_imagen(ruta, size, size)
            self.usuario_avatar_ref = avatar
            return avatar
        except Exception:
            self.usuario_avatar_ref = None
            return None
