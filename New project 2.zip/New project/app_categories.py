"""Gestion de categorias y sus imagenes."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppCategoriesMixin:
    def _copiar_imagen_a_proyecto(self, archivo):
        origen = Path(archivo)
        if not origen.exists():
            messagebox.showwarning("Imagen no encontrada", "No se pudo encontrar la imagen seleccionada.")
            return ""

        IMAGE_DIR.mkdir(exist_ok=True)
        destino = IMAGE_DIR / f"{uuid.uuid4().hex}{origen.suffix.lower()}"
        try:
            shutil.copy2(origen, destino)
        except OSError:
            messagebox.showwarning("No se pudo copiar", "No se pudo guardar la imagen dentro del proyecto.")
            return ""

        return str(destino.relative_to(APP_DIR))

    def _seleccionar_imagen_categoria(self):
        archivo = filedialog.askopenfilename(
            title="Seleccionar imagen de categoria",
            filetypes=[
                ("Imagenes", "*.png *.gif *.jpg *.jpeg *.bmp"),
                ("PNG", "*.png"),
                ("GIF", "*.gif"),
                ("Todos los archivos", "*.*"),
            ],
        )
        if not archivo:
            return ""
        return self._copiar_imagen_a_proyecto(archivo)

    def _crear_imagen_categoria_expandible(self, parent, ruta_imagen):
        ruta = self._resolver_ruta_imagen(ruta_imagen)
        if not ruta or not ruta.exists():
            return None

        try:
            imagen_pequena = self._cargar_preview_imagen(ruta, 88, 60)
            imagen_grande = self._cargar_preview_imagen(ruta, 250, 170)
        except Exception:
            return None

        estado = {"grande": False}
        etiqueta = tk.Label(
            parent,
            image=imagen_pequena,
            bg=COLOR_BLANCO,
            cursor="hand2",
            borderwidth=1,
            relief="solid",
        )
        etiqueta.image = imagen_pequena
        self.categoria_imagen_refs.extend([imagen_pequena, imagen_grande])

        def alternar(_event=None):
            estado["grande"] = not estado["grande"]
            imagen_actual = imagen_grande if estado["grande"] else imagen_pequena
            etiqueta.configure(image=imagen_actual)
            etiqueta.image = imagen_actual

        etiqueta.bind("<Button-1>", alternar)
        return etiqueta

    def _editar_categoria(self, categoria_id, nombre_actual, imagen_actual):
        ventana = tk.Toplevel(self)
        ventana.title("Editar ubicación")
        ventana.geometry("470x360")
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.grab_set()
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        contenedor = ttk.Frame(ventana, style="Card.TFrame", padding=16)
        contenedor.pack(fill="both", expand=True, padx=16, pady=16)
        contenedor.columnconfigure(0, weight=1)

        ttk.Label(
            contenedor,
            text="Editar ubicación",
            style="CardTitle.TLabel",
        ).grid(row=0, column=0, sticky="w", pady=(0, 12))

        ttk.Label(
            contenedor,
            text="Nombre:",
            style="Card.TLabel",
        ).grid(row=1, column=0, sticky="w")

        nombre_var = tk.StringVar(value=nombre_actual)
        entrada_nombre = ttk.Entry(contenedor, textvariable=nombre_var)
        entrada_nombre.grid(row=2, column=0, sticky="ew", pady=(6, 12))

        ttk.Label(
            contenedor,
            text="Imagen:",
            style="Card.TLabel",
        ).grid(row=3, column=0, sticky="w")

        preview_label = tk.Label(
            contenedor,
            text="Sin imagen",
            bg=COLOR_INPUT,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10, "bold"),
            relief="solid",
            borderwidth=1,
            anchor="center",
            padx=8,
            pady=8,
        )
        preview_label.grid(row=4, column=0, sticky="w", pady=(8, 10))

        imagen_data = {"valor": imagen_actual or ""}
        preview_data = {"imagen": None}
        guardado_programado = {"id": None}
        estado = {
            "nombre": " ".join((nombre_actual or "").split()),
            "imagen": imagen_actual or "",
        }

        def render_preview():
            ruta = self._resolver_ruta_imagen(imagen_data["valor"])
            if not ruta or not ruta.exists():
                preview_data["imagen"] = None
                preview_label.configure(image="", text="Sin imagen")
                preview_label.image = None
                return

            try:
                preview_data["imagen"] = self._cargar_preview_imagen(ruta, 230, 140)
                preview_label.configure(image=preview_data["imagen"], text="")
                preview_label.image = preview_data["imagen"]
            except Exception:
                preview_data["imagen"] = None
                preview_label.configure(image="", text="No se pudo mostrar")
                preview_label.image = None

        def cancelar_guardado_programado():
            if guardado_programado["id"] is None:
                return
            try:
                ventana.after_cancel(guardado_programado["id"])
            except Exception:
                pass
            guardado_programado["id"] = None

        def guardar_cambios_auto(forzar_nombre=False):
            nombre_digitado = " ".join(nombre_var.get().split())
            nombre_valido = 2 <= len(nombre_digitado) <= 60

            if forzar_nombre and not nombre_valido:
                nombre_var.set(estado["nombre"])
                nombre_digitado = estado["nombre"]
                nombre_valido = True

            nombre_a_guardar = nombre_digitado if nombre_valido else estado["nombre"]
            imagen_a_guardar = imagen_data["valor"] or ""

            if nombre_a_guardar == estado["nombre"] and imagen_a_guardar == estado["imagen"]:
                return True

            try:
                self.db.actualizar_categoria(categoria_id, nombre_a_guardar, imagen_a_guardar)
            except sqlite3.IntegrityError:
                messagebox.showwarning("Ubicación repetida", "Esa ubicación ya existe.")
                nombre_var.set(estado["nombre"])
                return False

            cambios = []
            if nombre_a_guardar != estado["nombre"]:
                cambios.append(f"nombre: '{estado['nombre']}' -> '{nombre_a_guardar}'")
            if imagen_a_guardar != estado["imagen"]:
                if imagen_a_guardar and not estado["imagen"]:
                    cambios.append("agregó imagen")
                elif not imagen_a_guardar and estado["imagen"]:
                    cambios.append("quitó imagen")
                else:
                    cambios.append("cambió imagen")

            estado["nombre"] = nombre_a_guardar
            estado["imagen"] = imagen_a_guardar

            if cambios:
                self.db.registrar_historial(
                    self.usuario_actual,
                    "EDITÓ",
                    "CATEGORÍA",
                    f"Categoría '{nombre_a_guardar}': {', '.join(cambios)}",
                )

            self._mostrar_inicio()
            return True

        def programar_guardado_nombre(_event=None):
            cancelar_guardado_programado()
            guardado_programado["id"] = ventana.after(520, guardar_cambios_auto)

        def guardar_nombre_ahora(_event=None):
            cancelar_guardado_programado()
            guardar_cambios_auto(forzar_nombre=True)
            return "break"

        acciones_imagen = ttk.Frame(contenedor, style="Card.TFrame")
        acciones_imagen.grid(row=5, column=0, sticky="w", pady=(0, 14))

        def subir_o_cambiar_imagen():
            nueva = self._seleccionar_imagen_categoria()
            if not nueva:
                return
            imagen_data["valor"] = nueva
            render_preview()
            cancelar_guardado_programado()
            guardar_cambios_auto()

        def quitar_imagen():
            if not imagen_data["valor"]:
                return
            imagen_data["valor"] = ""
            render_preview()
            cancelar_guardado_programado()
            guardar_cambios_auto()

        self._crear_boton(
            acciones_imagen,
            text="Subir/Cambiar",
            command=subir_o_cambiar_imagen,
            width=150,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, padx=(0, 8))

        self._crear_boton(
            acciones_imagen,
            text="Quitar imagen",
            command=quitar_imagen,
            variant="danger",
            width=140,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1)

        entrada_nombre.bind("<KeyRelease>", programar_guardado_nombre)
        entrada_nombre.bind("<FocusOut>", guardar_nombre_ahora)
        entrada_nombre.bind("<Return>", guardar_nombre_ahora)

        def cerrar_ventana_interna():
            cancelar_guardado_programado()
            guardar_cambios_auto(forzar_nombre=True)
            _cerrar_ventana()

        ventana.protocol("WM_DELETE_WINDOW", cerrar_ventana_interna)
        self._vincular_atajos_ventana(ventana, guardar=guardar_nombre_ahora, cerrar=cerrar_ventana_interna)

        render_preview()
        entrada_nombre.focus_set()

    def _agregar_categoria(self):
        nombre = simpledialog.askstring("Agregar ubicación", "Nombre de la nueva ubicación:")
        if not nombre:
            return

        nombre = nombre.strip()
        if not nombre:
            messagebox.showwarning("Dato requerido", "Ingrese un nombre para la ubicación.")
            return

        nombre = " ".join(nombre.split())
        if len(nombre) < 2:
            messagebox.showwarning("Nombre inválido", "La ubicación debe tener al menos 2 caracteres.")
            return

        if len(nombre) > 60:
            messagebox.showwarning("Nombre inválido", "La ubicación no puede superar 60 caracteres.")

        imagen_categoria = ""
        if messagebox.askyesno(
            "Imagen de categoria",
            "Desea subir una imagen para esta categoria?",
        ):
            imagen_categoria = self._seleccionar_imagen_categoria()

        try:
            nueva_id = self.db.agregar_categoria(nombre, imagen_categoria)
        except sqlite3.IntegrityError:
            messagebox.showwarning("Ubicación repetida", "Esa ubicación ya existe.")
            return
        
        self.db.registrar_historial(
        self.usuario_actual,
            "AGREGÓ",
            "CATEGORÍA",
            f"Agregó la categoría: {nombre}"
        )

        self._abrir_categoria(nueva_id, nombre)

    def _eliminar_categoria(self, categoria_id, nombre):
        confirmar = messagebox.askyesno(
            "Eliminar categoria",
            f"Desea eliminar '{nombre}' y todo su contenido?",
        )
        if not confirmar:
            return

        self.db.eliminar_categoria(categoria_id)

        self.db.registrar_historial(
            self.usuario_actual,
            "ELIMINÓ",
            "CATEGORÍA",
            f"Eliminó la categoría: {nombre}"
        )

        self._mostrar_inicio()

    def _abrir_categoria(self, categoria_id, nombre):
        self.categoria_actual_id = categoria_id
        self.categoria_actual_nombre = nombre
        self.producto_editando_id = None
        self.productos_en_pantalla = {}
        self.check_vars = {}
        self.productos_seleccionados.clear()
        self._mostrar_inventario()
        self._cargar_productos()

