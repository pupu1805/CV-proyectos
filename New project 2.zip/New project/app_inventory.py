"""Vista de inventario, formulario de mobiliario e imagenes de productos."""

import csv
import io
import math
import shutil
import sqlite3
import tkinter as tk
import uuid
import zipfile
from datetime import datetime, timedelta
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from config import *
from database import InventarioDB
from theme_runtime import aplicar_paleta_visual as _aplicar_paleta_visual
from widgets import (
    ChecklistItem,
    HorizontalScrollFrame,
    ImageButton,
    PencilIconButton,
    RoundedButton,
    RoundedCard,
    ScrollFrame,
    ThemeSwitch,
    TrashIconButton,
)

class AppInventoryMixin:
    def _mostrar_inventario(self):
        self.vista_actual = "inventario"
        self._limpiar_pantalla()

        pagina = ttk.Frame(self.contenedor, style="App.TFrame")
        pagina.grid(row=0, column=0, sticky="nsew")
        pagina.columnconfigure(0, weight=1)
        pagina.rowconfigure(1, weight=1)

        encabezado_banda = ttk.Frame(pagina, style="Header.TFrame", padding=(18, 12))
        encabezado_banda.grid(row=0, column=0, sticky="ew")
        encabezado_banda.columnconfigure(0, weight=1)

        encabezado_base = RoundedCard(
            encabezado_banda,
            bg=COLOR_CELESTE,
            fill=COLOR_BLANCO,
            outline="#9bdcff",
            radius=24,
            padding=14,
            min_height=92,
        )
        encabezado_base.grid(row=0, column=0, sticky="ew")

        encabezado = encabezado_base.contenido
        encabezado.columnconfigure(2, weight=1)

        self._crear_boton(
            encabezado,
            text="Volver",
            command=lambda: self.transicion(self._mostrar_inicio, "derecha"),
            variant="light",
            width=110,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, sticky="w", padx=(0, 16))

        logo = self._poner_logo(encabezado, bg=COLOR_BLANCO, max_ancho=86, max_alto=64)
        if logo:
            logo.grid(row=0, column=1, sticky="w", padx=(0, 12))

        tk.Label(
            encabezado,
            text=self.categoria_actual_nombre,
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 18, "bold"),
        ).grid(row=0, column=2, sticky="w")

        cuerpo = ttk.Frame(pagina, style="App.TFrame", padding=18)
        cuerpo.grid(row=1, column=0, sticky="nsew")
        cuerpo.columnconfigure(0, weight=1, minsize=320)
        cuerpo.columnconfigure(1, weight=2, minsize=540)
        cuerpo.rowconfigure(0, weight=1)

        self._crear_panel_checklist(cuerpo)
        self._crear_panel_contenido(cuerpo)

    def _crear_panel_checklist(self, parent):
        panel_base = RoundedCard(
            parent,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=16,
            min_width=760,
            fill_height=True,
        )
        panel_base.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        panel = panel_base.contenido
        panel.columnconfigure(0, weight=1)
        panel.rowconfigure(3, weight=1)

        ttk.Label(panel, text="Buscar mobiliario", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w")

        self.busqueda_var = tk.StringVar()
        self.entrada_busqueda = ttk.Entry(panel, textvariable=self.busqueda_var)
        self.entrada_busqueda.grid(row=1, column=0, sticky="ew", pady=(10, 12))
        self.entrada_busqueda.bind("<Return>", lambda _event: self._cargar_productos())

        self._crear_boton(
            panel,
            text="Buscar",
            command=self._cargar_productos,
            width=105,
            bg=COLOR_BLANCO,
        ).grid(row=1, column=1, sticky="e", padx=(8, 0), pady=(10, 12))

        ttk.Label(panel, text="Checklist", style="Muted.TLabel").grid(row=2, column=0, columnspan=2, sticky="w", pady=(0, 8))

        self.check_scroll = ScrollFrame(panel, canvas_bg=COLOR_BLANCO, content_style="Card.TFrame")
        self.check_scroll.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self.checks_contenedor = self.check_scroll.contenido
        self.checks_contenedor.columnconfigure(0, weight=1)

        acciones_scroll = HorizontalScrollFrame(
            panel,
            canvas_bg=COLOR_BLANCO,
            content_style="Card.TFrame",
            height=60,
        )
        acciones_scroll.grid(row=4, column=0, columnspan=2, sticky="ew", pady=(12, 0))
        acciones = acciones_scroll.contenido

        self._crear_boton(
            acciones,
            text="Agregar mobiliario",
            command=self._nuevo_producto,
            width=150,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Importar CSV",
            command=self._importar_csv,
            width=135,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Eliminar seleccion",
            command=self._eliminar_productos,
            variant="danger",
            width=170,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=2, sticky="w")

        self._crear_boton(
            acciones,
            text="Registrar prestamo",
            command=self._registrar_prestamo_producto,
            variant="secondary",
            width=170,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=3, sticky="w", padx=(8, 0))

        self._crear_boton(
            acciones,
            text="Ver prestamos",
            command=self._ver_prestamos_categoria,
            variant="secondary",
            width=145,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=4, sticky="w", padx=(8, 0))

        self._crear_boton_imagen(
            acciones,
            image_path=CSV_ICON_PATH,
            command=self._exportar_csv_categoria,
            size=46,
            bg=COLOR_BLANCO,
            fallback_text="CSV",
        ).grid(row=0, column=5, sticky="w", padx=(8, 0))

        self._crear_boton_imagen(
            acciones,
            image_path=PDF_ICON_PATH,
            command=self._exportar_pdf_categoria,
            size=46,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=6, sticky="w", padx=(8, 0))

    def _crear_panel_contenido(self, parent):
        panel_base = RoundedCard(
            parent,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=16,
            fill_height=True,
        )
        panel_base.grid(row=0, column=1, sticky="nsew", padx=(10, 0))
        panel = panel_base.contenido
        panel.columnconfigure(0, weight=1)
        panel.rowconfigure(0, weight=1)

        self.detalle_scroll = ScrollFrame(panel, canvas_bg=COLOR_BLANCO, content_style="Card.TFrame")
        self.detalle_scroll.grid(row=0, column=0, sticky="nsew")
        contenido = self.detalle_scroll.contenido
        contenido.columnconfigure(0, weight=1)

        self.editor_area = ttk.Frame(contenido, style="Card.TFrame")
        self.editor_area.grid(row=0, column=0, sticky="ew")
        self.editor_area.columnconfigure(0, weight=1)
        self.editor_area.columnconfigure(1, weight=1)

        self.formulario_frame = ttk.Frame(self.editor_area, style="Card.TFrame")
        self.formulario_frame.grid(row=0, column=0, columnspan=2, sticky="ew")
        self.formulario_frame.columnconfigure(1, weight=1)

        ttk.Label(self.formulario_frame, text="Editar o agregar", style="CardTitle.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))

        self.nombre_var = tk.StringVar()
        ttk.Label(self.formulario_frame, text="Nombre:", style="Card.TLabel").grid(row=1, column=0, sticky="w", padx=(0, 10), pady=8)
        self.nombre_entry = ttk.Entry(self.formulario_frame, textvariable=self.nombre_var)
        self.nombre_entry.grid(row=1, column=1, sticky="ew", pady=8)

        ttk.Label(self.formulario_frame, text="Objetos:", style="Card.TLabel").grid(row=2, column=0, sticky="nw", padx=(0, 10), pady=8)
        self.filas_contenido = []
        self.filas_contenido_frame = ttk.Frame(self.formulario_frame, style="Card.TFrame")
        self.filas_contenido_frame.grid(row=2, column=1, sticky="ew", pady=8)
        self.filas_contenido_frame.columnconfigure(1, weight=1)

        ttk.Label(self.filas_contenido_frame, text="#", style="Muted.TLabel", width=4, anchor="center").grid(
            row=0,
            column=0,
            sticky="ew",
            padx=(0, 6),
            pady=(0, 4),
        )
        ttk.Label(self.filas_contenido_frame, text="Item", style="Muted.TLabel").grid(
            row=0,
            column=1,
            sticky="w",
            padx=(0, 6),
            pady=(0, 4),
        )
        ttk.Label(self.filas_contenido_frame, text="Cant.", style="Muted.TLabel", anchor="center").grid(
            row=0,
            column=2,
            sticky="ew",
            padx=(0, 6),
            pady=(0, 4),
        )
        self._crear_boton(
            self.filas_contenido_frame,
            text="+ Agregar fila",
            command=self._agregar_fila_contenido,
            width=135,
            bg=COLOR_BLANCO,
        ).grid(row=999, column=0, columnspan=4, sticky="w", pady=(8, 0))


        acciones = ttk.Frame(self.formulario_frame, style="Card.TFrame")
        acciones.grid(row=3, column=1, sticky="ew", pady=(6, 18))

        self._crear_boton(
            acciones,
            text="Guardar",
            command=self._guardar_producto,
            width=140,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=0, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Limpiar",
            command=self._limpiar_formulario,
            variant="light",
            width=130,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=1, sticky="w", padx=(0, 8))

        self._crear_boton(
            acciones,
            text="Subir imagen",
            command=self._subir_imagen,
            width=145,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=2, sticky="w")

        self.imagen_card = RoundedCard(
            self.editor_area,
            bg=COLOR_BLANCO,
            fill=COLOR_INPUT,
            outline=COLOR_BORDE,
            radius=20,
            padding=14,
            min_height=245,
        )
        imagen_contenido = self.imagen_card.contenido
        imagen_contenido.columnconfigure(0, weight=1)
        self.imagen_titulo = ttk.Label(imagen_contenido, text="Imagen", style="ImageTitle.TLabel")
        self.imagen_titulo.grid(row=0, column=0, sticky="w", pady=(0, 10))
        self.imagen_label = tk.Label(
            imagen_contenido,
            text="",
            bg=COLOR_INPUT,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10, "bold"),
            compound="top",
        )
        self.imagen_label.grid(row=1, column=0, sticky="nsew")

        self.galeria_scroll = ScrollFrame(
            imagen_contenido,
            canvas_bg=COLOR_INPUT,
            content_style="Gallery.TFrame",
        )
        self.galeria_scroll.grid(row=1, column=0, sticky="ew")
        self.galeria_scroll.canvas.configure(height=230)
        self.galeria_grid = self.galeria_scroll.contenido
        self.galeria_grid.columnconfigure(0, weight=1)
        self.galeria_scroll.grid_remove()
        self.imagen_card.grid_remove()

        ttk.Separator(contenido, orient="horizontal").grid(row=1, column=0, sticky="ew", pady=(18, 16))
        ttk.Label(contenido, text="Objetos seleccionados", style="CardTitle.TLabel").grid(row=2, column=0, sticky="w", pady=(0, 10))

        self.seleccionados_contenedor = ttk.Frame(contenido, style="Card.TFrame")
        self.seleccionados_contenedor.grid(row=3, column=0, sticky="ew")
        self.seleccionados_contenedor.columnconfigure(0, weight=1)
        
        for _ in range(3):
            self._agregar_fila_contenido()

    def _cargar_productos(self):
        for widget in self.checks_contenedor.winfo_children():
            widget.destroy()

        self.productos_en_pantalla = {}
        self.check_vars = {}

        productos = self.db.buscar_productos(self.categoria_actual_id, self.busqueda_var.get())
        if not productos:
            ttk.Label(
                self.checks_contenedor,
                text="No hay mobiliario en esta lista.",
                style="Muted.TLabel",
            ).grid(row=0, column=0, sticky="w", pady=8)
            self._mostrar_detalles_seleccionados()
            return

        for fila, (producto_id, nombre, contenido, imagen) in enumerate(productos):
            self.productos_en_pantalla[producto_id] = {
                "nombre": nombre,
                "contenido": contenido,
                "imagen": imagen,
            }
            variable = tk.BooleanVar(value=producto_id in self.productos_seleccionados)
            self.check_vars[producto_id] = variable

            check = ChecklistItem(
                self.checks_contenedor,
                text=nombre,
                variable=variable,
                command=lambda item_id=producto_id: self._alternar_producto(item_id),
            )
            check.grid(row=fila, column=0, sticky="ew", padx=0, pady=4)
            self._animar_widget_entrada(check, distancia=10, delay=min(fila * 18, 120))

        self._mostrar_detalles_seleccionados()

    def _alternar_producto(self, producto_id):
        variable = self.check_vars[producto_id]
        if variable.get():
            self.productos_seleccionados.add(producto_id)
            self._cargar_producto_en_formulario(producto_id)
        else:
            self.productos_seleccionados.discard(producto_id)
            if self.producto_editando_id == producto_id:
                self._limpiar_formulario()

        self._mostrar_detalles_seleccionados()

    def _parsear_contenido_a_filas(self, contenido):
        filas = []
        for linea in contenido.splitlines():
            texto = linea.strip()
            if not texto:
                continue
            descripcion = texto
            cantidad = 1
            if "|" in texto:
                posible_descripcion, posible_cantidad = texto.rsplit("|", 1)
                posible_descripcion = posible_descripcion.strip()
                posible_cantidad = posible_cantidad.strip()
                if posible_descripcion and posible_cantidad.isdigit():
                    descripcion = posible_descripcion
                    cantidad = max(1, int(posible_cantidad))
            filas.append({"descripcion": descripcion, "cantidad": cantidad})
        return filas

    def _serializar_filas_contenido(self, filas):
        lineas = []
        for fila in filas:
            descripcion = fila["descripcion"].strip()
            cantidad = max(1, int(fila["cantidad"]))
            if descripcion:
                lineas.append(f"{descripcion} | {cantidad}")
        return "\n".join(lineas)

    def _limpiar_filas_contenido(self):
        for fila in self.filas_contenido:
            fila["frame"].destroy()
        self.filas_contenido = []

    def _animar_widget_entrada(self, widget, distancia=14, pasos=6, delay=0):
        def animar(paso=0):
            if not widget.winfo_exists():
                return

            avance = paso / pasos
            desplazamiento = int(distancia * (1 - avance))
            widget.grid_configure(padx=(desplazamiento, 0))

            if paso < pasos:
                widget.after(16, lambda: animar(paso + 1))
            else:
                widget.grid_configure(padx=(0, 0))

        widget.after(delay, animar)

    def _animar_fila_salida(self, fila, pasos=6):
        frame = fila["frame"]

        def animar(paso=0):
            if not frame.winfo_exists():
                return

            desplazamiento = int(18 * (paso / pasos))
            frame.grid_configure(padx=(desplazamiento, 0))

            if paso < pasos:
                frame.after(18, lambda: animar(paso + 1))
                return

            if fila in self.filas_contenido:
                self.filas_contenido.remove(fila)
            frame.destroy()
            self._refrescar_filas_contenido()

        animar()

    def _refrescar_filas_contenido(self):
        for indice, fila in enumerate(self.filas_contenido, start=1):
            fila["frame"].grid(row=indice, column=0, columnspan=4, sticky="ew", pady=3)
            fila["indice"].configure(text=str(indice))
        if not self.filas_contenido:
            self._agregar_fila_contenido()

    def _agregar_fila_contenido(self, descripcion="", cantidad="1"):
        fila_frame = ttk.Frame(self.filas_contenido_frame, style="Card.TFrame")
        fila_frame.columnconfigure(1, weight=1)

        indice_label = ttk.Label(
            fila_frame,
            text=str(len(self.filas_contenido) + 1),
            style="Muted.TLabel",
            width=4,
            anchor="center",
        )
        indice_label.grid(row=0, column=0, sticky="ew", padx=(0, 6))

        descripcion_var = tk.StringVar(value=descripcion)
        descripcion_entry = ttk.Entry(fila_frame, textvariable=descripcion_var)
        descripcion_entry.grid(row=0, column=1, sticky="ew", padx=(0, 6))

        cantidad_var = tk.StringVar(value=str(cantidad or "1"))
        cantidad_entry = ttk.Spinbox(
            fila_frame,
            from_=1,
            to=9999,
            textvariable=cantidad_var,
            width=8,
            justify="center",
        )
        cantidad_entry.grid(row=0, column=2, sticky="ew", padx=(0, 6))

        fila = {
            "frame": fila_frame,
            "indice": indice_label,
            "descripcion_var": descripcion_var,
            "descripcion_entry": descripcion_entry,
            "cantidad_var": cantidad_var,
        }

        self._crear_boton(
            fila_frame,
            text="Quitar",
            command=lambda datos=fila: self._eliminar_fila_contenido(datos),
            variant="danger",
            width=90,
            bg=COLOR_BLANCO,
        ).grid(row=0, column=3, sticky="e")

        self.filas_contenido.append(fila)
        self._refrescar_filas_contenido()
        self._animar_widget_entrada(fila_frame, distancia=16)
        return fila

    def _eliminar_fila_contenido(self, fila):
        if fila not in self.filas_contenido:
            return
        if fila.get("eliminando"):
            return
        fila["eliminando"] = True
        self._animar_fila_salida(fila)

    def _cargar_filas_contenido_en_editor(self, contenido):
        filas = self._parsear_contenido_a_filas(contenido)
        self._limpiar_filas_contenido()
        if not filas:
            for _ in range(3):
                self._agregar_fila_contenido()
            return
        for fila in filas:
            self._agregar_fila_contenido(fila["descripcion"], fila["cantidad"])

    def _obtener_filas_contenido_desde_editor(self):
        filas = []
        for fila in self.filas_contenido:
            descripcion = fila["descripcion_var"].get().strip()
            cantidad_texto = fila["cantidad_var"].get().strip()
            if not descripcion and not cantidad_texto:
                continue
            if not descripcion:
                messagebox.showwarning("Dato requerido", "Cada fila con cantidad debe tener un item.")
                fila["descripcion_entry"].focus_set()
                return None
            if not cantidad_texto.isdigit() or int(cantidad_texto) <= 0:
                messagebox.showwarning("Cantidad invalida", "Ingrese una cantidad numerica mayor a cero.")
                return None
            filas.append({"descripcion": descripcion, "cantidad": int(cantidad_texto)})
        return filas

    def _crear_tabla_contenido_resumen(self, parent, contenido):
        filas = self._parsear_contenido_a_filas(contenido)
        if not filas:
            ttk.Label(
                parent,
                text="Sin objetos registrados.",
                style="Soft.TLabel",
            ).grid(row=0, column=0, sticky="w", pady=(8, 0))
            return

        tabla = ttk.Frame(parent, style="Card.TFrame")
        tabla.grid(row=0, column=0, sticky="ew", pady=(8, 0))
        tabla.columnconfigure(1, weight=1)

        ttk.Label(tabla, text="#", style="Muted.TLabel", width=4, anchor="center").grid(row=0, column=0, sticky="ew", padx=(0, 6))
        ttk.Label(tabla, text="Item", style="Muted.TLabel").grid(row=0, column=1, sticky="w", padx=(0, 6))
        ttk.Label(tabla, text="Cantidad", style="Muted.TLabel", anchor="center").grid(row=0, column=2, sticky="ew")

        for indice, fila in enumerate(filas, start=1):
            ttk.Label(tabla, text=str(indice), style="Soft.TLabel", anchor="center").grid(row=indice, column=0, sticky="ew", padx=(0, 6), pady=(6, 0))
            ttk.Label(tabla, text=fila["descripcion"], style="Soft.TLabel", wraplength=520, justify="left").grid(row=indice, column=1, sticky="w", padx=(0, 6), pady=(6, 0))
            ttk.Label(tabla, text=str(fila["cantidad"]), style="Soft.TLabel", anchor="center").grid(row=indice, column=2, sticky="ew", pady=(6, 0))

    def _formatear_contenido_con_indice(self, contenido):
        filas = self._parsear_contenido_a_filas(contenido)
        if not filas:
            return "Sin contenido registrado."
        resultado = []
        for indice, fila in enumerate(filas, start=1):
            resultado.append(f"{indice}. {fila['descripcion']} (x{fila['cantidad']})")
        return "\n".join(resultado)

    def _mostrar_detalles_seleccionados(self):
        for widget in self.seleccionados_contenedor.winfo_children():
            widget.destroy()

        productos = self.db.obtener_productos_por_ids(self.productos_seleccionados)
        self._mostrar_galeria_imagenes(productos)
        if not productos:
            ttk.Label(
                self.seleccionados_contenedor,
                text="Marque uno o varios del checklist.",
                style="Muted.TLabel",
            ).grid(row=0, column=0, sticky="w", pady=8)
            self.detalle_scroll.canvas.yview_moveto(0)
            self.detalle_scroll._actualizar_scroll()
            return

        for fila, (producto_id, _categoria_id, nombre, contenido, imagen) in enumerate(productos):
            tarjeta_base = RoundedCard(
                self.seleccionados_contenedor,
                bg=COLOR_BLANCO,
                fill=COLOR_CELESTE_SUAVE,
                outline="#bae6fd",
                radius=18,
                padding=12,
            )
            tarjeta_base.grid(row=fila, column=0, sticky="ew", pady=7)
            self._animar_widget_entrada(tarjeta_base, distancia=10, delay=min(fila * 20, 100))
            tarjeta = tarjeta_base.contenido
            tarjeta.columnconfigure(0, weight=1)

            ttk.Label(tarjeta, text=nombre, style="SoftTitle.TLabel").grid(row=0, column=0, sticky="w")
            if imagen:
                ttk.Label(tarjeta, text="Con imagen", style="Soft.TLabel").grid(row=0, column=1, sticky="e", padx=(8, 10))

            self._crear_boton(
                tarjeta,
                text="Abrir ventana",
                command=lambda item_id=producto_id: self._abrir_detalle_producto(item_id),
                width=120,
                bg=COLOR_CELESTE_SUAVE,
            ).grid(row=0, column=3, sticky="e", padx=(4, 0))

            
            tabla_contenido = ttk.Frame(tarjeta, style="Card.TFrame")
            tabla_contenido.grid(row=1, column=0, columnspan=4, sticky="ew")
            tabla_contenido.columnconfigure(0, weight=1)
            self._crear_tabla_contenido_resumen(tabla_contenido, contenido)
        self.detalle_scroll.canvas.yview_moveto(0)
        self.detalle_scroll._actualizar_scroll()

    def _abrir_detalle_producto(self, producto_id):
        producto = self.db.obtener_producto(producto_id)
        if not producto:
            return

        _id, _categoria_id, nombre_prod, contenido_prod, imagen_prod = producto

        ventana = tk.Toplevel(self)
        ventana.title(f"Detalle — {nombre_prod}")
        ventana.geometry("720x640")
        ventana.minsize(540, 460)
        ventana.configure(bg=COLOR_FONDO)
        ventana.transient(self)
        ventana.grab_set()
        
        self._deshabilitar_tema()
        
        def _cerrar_ventana():
            ventana.destroy()
            self._habilitar_tema()

        ventana.columnconfigure(0, weight=1)
        ventana.rowconfigure(0, weight=1)

        panel_base = RoundedCard(
            ventana,
            bg=COLOR_FONDO,
            fill=COLOR_BLANCO,
            outline=COLOR_BORDE,
            radius=24,
            padding=18,
            fill_height=True,
        )
        panel_base.pack(fill="both", expand=True, padx=18, pady=18)

        panel_scroll = ScrollFrame(panel_base.contenido, canvas_bg=COLOR_BLANCO, content_style="Card.TFrame")
        panel_scroll.pack(fill="both", expand=True)
        panel = panel_scroll.contenido
        panel.columnconfigure(1, weight=1)

        # Encabezado
        tk.Label(
            panel,
            text="Detalle del artículo",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO,
            font=("Segoe UI", 17, "bold"),
        ).grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 4))

        tk.Label(
            panel,
            text=f"Ubicación: {self.categoria_actual_nombre}",
            bg=COLOR_BLANCO,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 9),
        ).grid(row=1, column=0, columnspan=2, sticky="w", pady=(0, 14))

        # Nombre
        ttk.Label(panel, text="Nombre:", style="Card.TLabel").grid(row=2, column=0, sticky="w", padx=(0, 10), pady=(0, 6))
        nombre_var = tk.StringVar(value=nombre_prod)
        nombre_entry = ttk.Entry(panel, textvariable=nombre_var, font=("Segoe UI", 11))
        nombre_entry.grid(row=2, column=1, sticky="ew", pady=(0, 14))

        # Contenido — filas de ítems
        ttk.Label(panel, text="Objetos:", style="Card.TLabel").grid(row=3, column=0, sticky="nw", padx=(0, 10), pady=(0, 6))

        filas_popup = []

        filas_frame = ttk.Frame(panel, style="Card.TFrame")
        filas_frame.grid(row=3, column=1, sticky="ew", pady=(0, 6))
        filas_frame.columnconfigure(1, weight=1)

        ttk.Label(filas_frame, text="#", style="Muted.TLabel", width=4, anchor="center").grid(row=0, column=0, sticky="ew", padx=(0, 6), pady=(0, 4))
        ttk.Label(filas_frame, text="Ítem", style="Muted.TLabel").grid(row=0, column=1, sticky="w", padx=(0, 6), pady=(0, 4))
        ttk.Label(filas_frame, text="Cant.", style="Muted.TLabel", anchor="center").grid(row=0, column=2, sticky="ew", padx=(0, 6), pady=(0, 4))

        boton_agregar_ref = {"btn": None}

        def refrescar_filas_popup():
            for idx, fila in enumerate(filas_popup, start=1):
                fila["frame"].grid(row=idx, column=0, columnspan=4, sticky="ew", pady=3)
                fila["indice"].configure(text=str(idx))
            if boton_agregar_ref["btn"]:
                boton_agregar_ref["btn"].grid(row=len(filas_popup) + 1, column=0, columnspan=4, sticky="w", pady=(8, 0))
            if not filas_popup:
                agregar_fila_popup()
            panel_scroll._actualizar_scroll()

        def agregar_fila_popup(descripcion="", cantidad="1"):
            fila_frame = ttk.Frame(filas_frame, style="Card.TFrame")
            fila_frame.columnconfigure(1, weight=1)

            indice_label = ttk.Label(fila_frame, text=str(len(filas_popup) + 1), style="Muted.TLabel", width=4, anchor="center")
            indice_label.grid(row=0, column=0, sticky="ew", padx=(0, 6))

            descripcion_var = tk.StringVar(value=descripcion)
            descripcion_entry = ttk.Entry(fila_frame, textvariable=descripcion_var)
            descripcion_entry.grid(row=0, column=1, sticky="ew", padx=(0, 6))

            cantidad_var = tk.StringVar(value=str(cantidad or "1"))
            ttk.Spinbox(fila_frame, from_=1, to=9999, textvariable=cantidad_var, width=8, justify="center").grid(row=0, column=2, sticky="ew", padx=(0, 6))

            fila = {
                "frame": fila_frame,
                "indice": indice_label,
                "descripcion_var": descripcion_var,
                "descripcion_entry": descripcion_entry,
                "cantidad_var": cantidad_var,
            }

            def quitar(f=fila):
                if f in filas_popup:
                    filas_popup.remove(f)
                    f["frame"].destroy()
                    refrescar_filas_popup()

            self._crear_boton(fila_frame, text="Quitar", command=quitar, variant="danger", width=90, bg=COLOR_BLANCO).grid(row=0, column=3, sticky="e")
            filas_popup.append(fila)
            refrescar_filas_popup()

        boton_agregar_ref["btn"] = self._crear_boton(filas_frame, text="+ Agregar fila", command=agregar_fila_popup, width=135, bg=COLOR_BLANCO)

        # Cargar filas existentes
        filas_existentes = self._parsear_contenido_a_filas(contenido_prod)
        if filas_existentes:
            for f in filas_existentes:
                agregar_fila_popup(f["descripcion"], f["cantidad"])
        else:
            for _ in range(3):
                agregar_fila_popup()

        # Imagen
        ttk.Separator(panel, orient="horizontal").grid(row=4, column=0, columnspan=2, sticky="ew", pady=(14, 14))
        ttk.Label(panel, text="Imagen:", style="Card.TLabel").grid(row=5, column=0, sticky="nw", padx=(0, 10), pady=(0, 6))

        imagen_data = {"valor": imagen_prod or ""}
        preview_ref = {"img": None}

        preview_label = tk.Label(
            panel,
            text="Sin imagen",
            bg=COLOR_INPUT,
            fg=COLOR_TEXTO_SUAVE,
            font=("Segoe UI", 10, "bold"),
            relief="solid",
            borderwidth=1,
            padx=8,
            pady=8,
            anchor="center",
        )
        preview_label.grid(row=5, column=1, sticky="w", pady=(0, 8))

        def render_imagen_detalle():
            ruta = self._resolver_ruta_imagen(imagen_data["valor"])
            if not ruta or not ruta.exists():
                preview_ref["img"] = None
                preview_label.configure(image="", text="Sin imagen")
                preview_label.image = None
                return
            try:
                img = self._cargar_preview_imagen(ruta, 260, 160)
                preview_ref["img"] = img
                preview_label.configure(image=img, text="")
                preview_label.image = img
            except Exception:
                preview_label.configure(image="", text="No se pudo mostrar")

        def subir_imagen_detalle():
            archivo = filedialog.askopenfilename(
                title="Seleccionar imagen",
                filetypes=[("Imagenes", "*.png *.gif *.jpg *.jpeg *.bmp"), ("Todos", "*.*")],
            )
            if not archivo:
                return
            rel = self._copiar_imagen_a_proyecto(archivo)
            if rel:
                imagen_data["valor"] = rel
                render_imagen_detalle()

        def quitar_imagen_detalle():
            imagen_data["valor"] = ""
            render_imagen_detalle()

        fila_botones_img = ttk.Frame(panel, style="Card.TFrame")
        fila_botones_img.grid(row=6, column=1, sticky="w", pady=(0, 14))
        self._crear_boton(fila_botones_img, text="Subir/Cambiar", command=subir_imagen_detalle, width=130, bg=COLOR_BLANCO).grid(row=0, column=0, padx=(0, 8))
        self._crear_boton(fila_botones_img, text="Quitar imagen", command=quitar_imagen_detalle, variant="danger", width=120, bg=COLOR_BLANCO).grid(row=0, column=1)

        render_imagen_detalle()

        # Botones de acción
        ttk.Separator(panel, orient="horizontal").grid(row=7, column=0, columnspan=2, sticky="ew", pady=(6, 14))

        acciones = ttk.Frame(panel, style="Card.TFrame")
        acciones.grid(row=8, column=0, columnspan=2, sticky="w", pady=(0, 4))

        def guardar_detalle():
            nombre_nuevo = nombre_var.get().strip()
            if not nombre_nuevo:
                messagebox.showwarning("Dato requerido", "Ingrese el nombre del artículo.", parent=ventana)
                return

            filas = []
            for fila in filas_popup:
                desc = fila["descripcion_var"].get().strip()
                cant_texto = fila["cantidad_var"].get().strip()
                if not desc and not cant_texto:
                    continue
                if not desc:
                    messagebox.showwarning("Dato requerido", "Cada fila con cantidad debe tener un ítem.", parent=ventana)
                    return
                if not cant_texto.isdigit() or int(cant_texto) <= 0:
                    messagebox.showwarning("Cantidad inválida", "Ingrese una cantidad numérica mayor a cero.", parent=ventana)
                    return
                filas.append({"descripcion": desc, "cantidad": int(cant_texto)})

            contenido = self._serializar_filas_contenido(filas)
            self.db.actualizar_producto(producto_id, {"nombre": nombre_nuevo, "contenido": contenido, "imagen": imagen_data["valor"] or ""})
            self.db.registrar_historial(
                self.usuario_actual,
                "EDITÓ",
                "OPCIÓN",
                f"Editó '{nombre_nuevo}' en categoría '{self.categoria_actual_nombre}' (ventana detalle)",
            )
            ventana.title(f"Detalle — {nombre_nuevo}")
            self._cargar_productos()
            if producto_id in self.productos_seleccionados:
                self._mostrar_detalles_seleccionados()
            messagebox.showinfo("Guardado", "Los cambios se guardaron correctamente.", parent=ventana)

        self._crear_boton(acciones, text="Guardar", command=guardar_detalle, width=130, bg=COLOR_BLANCO).grid(row=0, column=0, padx=(0, 10))
        self._crear_boton(acciones, text="Cerrar", command=_cerrar_ventana, variant="secondary", width=110, bg=COLOR_BLANCO).grid(row=0, column=1)

        self._vincular_atajos_ventana(ventana, guardar=guardar_detalle, cerrar=_cerrar_ventana)
        nombre_entry.focus_set()

    def _productos_con_imagen(self, productos):
        resultado = []
        for producto in productos:
            producto_id, _categoria_id, nombre, contenido, imagen = producto
            ruta = self._resolver_ruta_imagen(imagen)
            if ruta and ruta.exists():
                resultado.append(
                    {
                        "id": producto_id,
                        "nombre": nombre,
                        "contenido": contenido,
                        "imagen": imagen,
                        "ruta": ruta,
                    }
                )
        return resultado

    def _limpiar_galeria(self):
        if not hasattr(self, "galeria_grid"):
            return

        for widget in self.galeria_grid.winfo_children():
            widget.destroy()
        self.galeria_refs = []
        self.imagen_grande_ref = None

    def _mostrar_panel_derecho(self):
        self.formulario_frame.grid_configure(columnspan=1, sticky="nsew", padx=(0, 12))
        self.imagen_card.grid(row=0, column=1, sticky="nsew", padx=(12, 0))

    def _ocultar_panel_derecho(self):
        self._limpiar_galeria()
        self.galeria_scroll.grid_remove()
        self.imagen_label.grid()
        self.imagen_label.configure(image="", text="")
        self.imagen_card.grid_remove()
        self.formulario_frame.grid_configure(columnspan=2, padx=(0, 0))

    def _mostrar_galeria_imagenes(self, productos):
        if not hasattr(self, "galeria_grid"):
            return

        self._limpiar_galeria()
        imagenes = self._productos_con_imagen(productos)
        if not imagenes:
            if self.imagen_actual:
                self._actualizar_panel_imagen()
            else:
                self._ocultar_panel_derecho()
            return

        self._mostrar_panel_derecho()
        self.imagen_label.grid_remove()
        self.galeria_scroll.grid(row=1, column=0, sticky="ew")
        self.imagen_titulo.configure(text="Imagenes seleccionadas")

        total = len(imagenes)
        columnas = 1 if total == 1 else 2
        thumb_ancho = 300 if total == 1 else 155
        thumb_alto = 185 if total == 1 else 105
        alto_scroll = 245 if total <= 4 else 310
        self.galeria_scroll.canvas.configure(height=alto_scroll)

        for columna in range(columnas):
            self.galeria_grid.columnconfigure(columna, weight=1)

        for indice, item in enumerate(imagenes):
            fila = indice // columnas
            columna = indice % columnas
            tarjeta = RoundedCard(
                self.galeria_grid,
                bg=COLOR_INPUT,
                fill=COLOR_BLANCO,
                outline=COLOR_BORDE,
                radius=16,
                padding=10,
                min_width=thumb_ancho + 28,
                min_height=thumb_alto + 58,
            )
            tarjeta.grid(row=fila, column=columna, sticky="nsew", padx=6, pady=6)
            tarjeta_contenido = tarjeta.contenido
            tarjeta_contenido.columnconfigure(0, weight=1)

            try:
                foto = self._cargar_preview_imagen(item["ruta"], thumb_ancho, thumb_alto)
                self.galeria_refs.append(foto)
                imagen_label = tk.Label(
                    tarjeta_contenido,
                    image=foto,
                    bg=COLOR_BLANCO,
                    cursor="hand2",
                )
                imagen_label.grid(row=0, column=0, sticky="nsew")
                imagen_label.bind("<Button-1>", lambda _event, datos=item: self._abrir_imagen_grande(datos))
            except Exception:
                imagen_label = tk.Label(
                    tarjeta_contenido,
                    text="No se pudo mostrar",
                    bg=COLOR_BLANCO,
                    fg=COLOR_TEXTO_SUAVE,
                    font=("Segoe UI", 9, "bold"),
                    width=18,
                    height=6,
                )
                imagen_label.grid(row=0, column=0, sticky="nsew")

            nombre_label = ttk.Label(
                tarjeta_contenido,
                text=item["nombre"],
                style="Card.TLabel",
                anchor="center",
            )
            nombre_label.grid(row=1, column=0, sticky="ew", pady=(8, 0))

        self.galeria_scroll.canvas.yview_moveto(0)
        self.galeria_scroll._actualizar_scroll()

    def _abrir_imagen_grande(self, item):
        if not hasattr(self, "galeria_grid"):
            return

        self._limpiar_galeria()
        self._mostrar_panel_derecho()
        self.imagen_label.grid_remove()
        self.galeria_scroll.grid(row=1, column=0, sticky="ew")
        self.galeria_scroll.canvas.configure(height=360)
        self.imagen_titulo.configure(text=item["nombre"])

        contenedor = ttk.Frame(self.galeria_grid, style="Gallery.TFrame")
        contenedor.grid(row=0, column=0, sticky="ew")
        contenedor.columnconfigure(0, weight=1)

        self._crear_boton(
            contenedor,
            text="Ver todas",
            command=lambda: self._mostrar_galeria_imagenes(
                self.db.obtener_productos_por_ids(self.productos_seleccionados)
            ),
            variant="light",
            width=120,
            bg=COLOR_INPUT,
        ).grid(row=0, column=0, sticky="w", pady=(0, 12))

        try:
            self.imagen_grande_ref = self._cargar_preview_imagen(item["ruta"], 330, 250)
            tk.Label(
                contenedor,
                image=self.imagen_grande_ref,
                bg=COLOR_INPUT,
            ).grid(row=1, column=0, sticky="nsew")
        except Exception:
            ttk.Label(
                contenedor,
                text="No se pudo mostrar esta imagen.",
                style="GalleryMuted.TLabel",
            ).grid(row=1, column=0, sticky="w", pady=20)

        ttk.Label(
            contenedor,
            text=self._formatear_contenido_con_indice(item["contenido"]),
            style="GalleryMuted.TLabel",
            wraplength=330,
            justify="left",
        ).grid(row=2, column=0, sticky="ew", pady=(12, 0))

        self.galeria_scroll.canvas.yview_moveto(0)
        self.galeria_scroll._actualizar_scroll()

    def _cargar_producto_en_formulario(self, producto_id):
        producto = self.db.obtener_producto(producto_id)
        if not producto:
            return

        self.producto_editando_id = producto_id
        _id, _categoria_id, nombre, contenido, imagen = producto
        self.nombre_var.set(nombre)
        self._cargar_filas_contenido_en_editor(contenido)
        self.imagen_actual = imagen or ""
        self._actualizar_panel_imagen()

    def _nuevo_producto(self):
        self._limpiar_formulario()
        self.nombre_var.set("Nueva opcion")
        if self.nombre_entry and self.nombre_entry.winfo_exists():
            self.nombre_entry.focus_set()
            self.nombre_entry.selection_range(0, tk.END)

    def _subir_imagen(self):
        archivo = filedialog.askopenfilename(
            title="Seleccionar imagen",
            filetypes=[
                ("Imagenes", "*.png *.gif *.jpg *.jpeg *.bmp"),
                ("PNG", "*.png"),
                ("GIF", "*.gif"),
                ("Todos los archivos", "*.*"),
            ],
        )
        if not archivo:
            return

        imagen_relativa = self._copiar_imagen_a_proyecto(archivo)
        if not imagen_relativa:
            return

        self.imagen_actual = imagen_relativa
        self._actualizar_panel_imagen()

    def _resolver_ruta_imagen(self, ruta):
        if not ruta:
            return None

        imagen = Path(ruta)
        if not imagen.is_absolute():
            imagen = APP_DIR / imagen
        return imagen

    def _cargar_preview_imagen(self, ruta, max_ancho=380, max_alto=220):
        cache_key = (str(ruta), int(max_ancho), int(max_alto))
        if cache_key in self.image_preview_cache:
            return self.image_preview_cache[cache_key]

        try:
            from PIL import Image, ImageTk

            imagen = Image.open(ruta)
            imagen.thumbnail((max_ancho, max_alto))
            preview = ImageTk.PhotoImage(imagen)
        except Exception:
            foto = tk.PhotoImage(file=str(ruta))
            escala = max(1, math.ceil(max(foto.width() / max_ancho, foto.height() / max_alto)))
            if escala > 1:
                foto = foto.subsample(escala, escala)
            preview = foto

        self.image_preview_cache[cache_key] = preview
        return preview

    def _actualizar_panel_imagen(self):
        if not hasattr(self, "imagen_card"):
            return

        ruta = self._resolver_ruta_imagen(self.imagen_actual)
        if not ruta or not ruta.exists():
            self.imagen_preview = None
            self._ocultar_panel_derecho()
            self.detalle_scroll.canvas.yview_moveto(0)
            self.detalle_scroll._actualizar_scroll()
            return

        self._limpiar_galeria()
        self.galeria_scroll.grid_remove()
        self.imagen_label.grid(row=1, column=0, sticky="nsew")
        self.imagen_titulo.configure(text="Imagen")
        self._mostrar_panel_derecho()

        try:
            self.imagen_preview = self._cargar_preview_imagen(ruta)
            self.imagen_label.configure(image=self.imagen_preview, text="")
        except Exception:
            self.imagen_preview = None
            self.imagen_label.configure(
                image="",
                text="No se pudo mostrar esta imagen.\nUse PNG, GIF o instale Pillow para JPG.",
            )

        self.detalle_scroll.canvas.yview_moveto(0)
        self.detalle_scroll._actualizar_scroll()

    def _guardar_producto(self):
        datos = self._leer_formulario()
        if datos is None:
            return

        if self.producto_editando_id is None:
            nuevo_id = self.db.agregar_producto(self.categoria_actual_id, datos)
            self.producto_editando_id = nuevo_id
            self.productos_seleccionados.add(nuevo_id)

            self.db.registrar_historial(
                self.usuario_actual,
                "AGREGÓ",
                "OPCIÓN",
                f"Agregó '{datos['nombre']}' en categoría '{self.categoria_actual_nombre}'"
            )
            
        else:
            self.db.actualizar_producto(self.producto_editando_id, datos)
            self.productos_seleccionados.add(self.producto_editando_id)

            self.db.registrar_historial(
                self.usuario_actual,
                "EDITÓ",
                "OPCIÓN",
                f"Editó '{datos['nombre']}' en categoría '{self.categoria_actual_nombre}'"
            )   

        self._cargar_productos()
        self._mostrar_detalles_seleccionados()
        messagebox.showinfo("Guardado", "La informacion se guardo correctamente.")

    def _leer_formulario(self):
        nombre = self.nombre_var.get().strip()
        

        if not nombre:
            messagebox.showwarning("Dato requerido", "Ingrese el nombre del mobiliario.")
            return None
        
        filas_contenido = self._obtener_filas_contenido_desde_editor()
        if filas_contenido is None:
            return None

        contenido = self._serializar_filas_contenido(filas_contenido)


        return {
            "nombre": nombre,
            "contenido": contenido,
            "imagen": self.imagen_actual,
        }

    def _eliminar_productos(self):
        if not self.productos_seleccionados:
            messagebox.showwarning("Sin selección", "Marque uno o varios mobiliarios para eliminar.")
            return

        total = len(self.productos_seleccionados)
        confirmar = messagebox.askyesno(
            "Eliminar seleccion",
            f"Desea eliminar {total} opcion(es) seleccionada(s)?",
        )
        if not confirmar:
            return

        productos_eliminados = self.db.obtener_productos_por_ids(self.productos_seleccionados)
        nombres = ", ".join(producto[2] for producto in productos_eliminados)

        self.db.eliminar_productos(self.productos_seleccionados)

        self.db.registrar_historial(
            self.usuario_actual,
            "ELIMINÓ",
            "OPCIÓN",
            f"Eliminó: {nombres} de categoría '{self.categoria_actual_nombre}'"
        )
        #cuando te caen 4 solo te queda ejecutar.      
        
        
        self.productos_seleccionados.clear()
        self._limpiar_formulario()
        self._cargar_productos()

    def _limpiar_formulario(self):
        self.producto_editando_id = None
        self.nombre_var.set("")
        self._limpiar_filas_contenido()
        for _ in range(3):
            self._agregar_fila_contenido()
        self.imagen_actual = ""
        self._actualizar_panel_imagen()

    def _validar_fecha_corta(self, valor):
        texto = (valor or "").strip()
        if not texto:
            return False
        try:
            datetime.strptime(texto, "%d/%m/%Y")
            return True
        except ValueError:
            return False

